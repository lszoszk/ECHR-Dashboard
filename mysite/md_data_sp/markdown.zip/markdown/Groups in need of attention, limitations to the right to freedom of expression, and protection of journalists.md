![](_page_0_Picture_2.jpeg)

20 April 2010 English Original: Spanish

**Human Rights Council Fourteenth session** Agenda item 3 **Promotion and protection of all human rights, civil, political, economic, social and cultural rights, including the right to development** 

# **Report of the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression, Mr. Frank La Rue**\*

*Summary*

 This report is submitted by the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression, Mr. Frank La Rue, pursuant to Human Rights Council resolution 7/36. This is the second annual report to be submitted by the current mandate holder, whose term began on 1 August 2008.

 Following an introduction (chapter I of the report), chapter II provides a brief account of the main activities undertaken by the Special Rapporteur, the communications and press releases that he issued and his participation in meetings and seminars between March 2009 and March 2010. Chapter III expands on four main themes: (a) general considerations on the freedom of opinion and expression; (b) freedom of expression for groups in need of particular attention and the role of freedom of expression in combating discrimination; (c) permissable restrictions and limitations on freedom of the expression; and (d) protection of journalists and freedom of the press. Chapter IV presents the Special Rapporteur's conclusions and general recommendations concerning these main subjects.

 The first addendum to this report contains a summary of communications sent by the Special Rapporteur between 1 January 2009 and 19 March 2010 and the replies received from Governments between 16 May 2009 and 14 May 2010. The second addendum contains the text of a joint declaration issued by the four rapporteurs holding mandates regarding freedom of expression in February 2010.

\* Late submission.

GE.10-13049 (E) 190510 270510

![](_page_0_Picture_12.jpeg)

# Contents

| | | Paragraphs | Page |
|------|---------------------------------------------------------------------------------------------------------------------------------------------|------------|------|
| I. | Introduction | 1–3 | 3 |
| II. | Activities of the Special Rapporteur | 4–23 | 3 |
| | A.<br>Communications | 4 | 3 |
| | B.<br>Participation in meetings and seminars | 5–19 | 3 |
| | C.<br>Country visits | 20–23 | 5 |
| III. | Main themes | 24–103 | 5 |
| | A.<br>General considerations on the right to freedom of opinion and expression | 24–39 | 5 |
| | B.<br>Freedom of expression for groups in need of particular attention and the<br>role of freedom of expression in combating discrimination | 40–71 | 8 |
| | C.<br>Permissible restrictions and limitations on freedom of expression | 72–87 | 12 |
| | D.<br>Protection of journalists and freedom of the press | 88–103 | 16 |
| IV. | Conclusions and recommendations | 104–133 | 18 |
| | A.<br>Conclusions | 104–118 | 18 |
| | B.<br>Recommendations | 119–133 | 19 |

# **I. Introduction**

1. This report is submitted to the Human Rights Council by the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression pursuant to Human Rights Council resolution 7/36. The addendum to the report (A/HRC/14/23/Add.1) contains a summary of the communications sent by the Special Rapporteur between 1 January 2009 and 19 March 2010 and the replies received from Governments between 16 May 2009 and 14 May 2010.

2. Since he took up his mandate on 1 August 2008, the Special Rapporteur has been working with various stakeholders in a spirit of transparency, openness and positive dialogue. The Special Rapporteur reaffirms his commitment to constructive engagement with all stakeholders in order to further promote and protect the right to freedom of opinion and expression worldwide.

3. In his first report to the Human Rights Council (A/HRC/11/4), the Special Rapporteur dealt with two priority issues: the right of access to information in situations of extreme poverty, and the protection of journalists and media professionals in conflict zones. In this report, the Special Rapporteur will examine the right to freedom of opinion and expression of groups in need of particular attention (women, children, those living in extreme poverty, minorities and indigenous peoples) and the role of freedom of expression in combating discrimination; permissible and impermissible limitations on the right to freedom of opinion and expression in international human rights law; and the protection of journalists and the freedom of the press.

# **II. Activities of the Special Rapporteur**

## **A. Communications**

4. Between 1 January 2009 and 19 March 2010, the Special Rapporteur sent 304 communications, 284 of which were signed jointly with other special procedures mandate holders. The geographical distribution of the communications was as follows: 32 per cent for Asia and the Pacific; 22 per cent for Latin America and the Caribbean; 19 per cent for Africa; 14 per cent for Europe, North America and Central Asia; and 12 per cent for the Middle East and North Africa.

## **B. Participation in meetings and seminars**

5. The Special Rapporteur attended many meetings with government authorities and civil society organizations to consider issues relating to the right to freedom of opinion and expression. He also participated in international academic seminars and global forums where topics related to the exercise of the right to freedom of opinion and expression were discussed.

6. From 20 to 24 April, the Special Rapporteur participated in the Durban Review Conference, held in Geneva. He also took part in a side event, along with the Special Rapporteur on contemporary forms of racism, racial discrimination, xenophobia and related intolerance and the Special Rapporteur on freedom of religion or belief, concerning freedom of expression and incitement to racial or religious hatred. At that event, which was organized by the Office of the United Nations High Commissioner for Human Rights (OHCHR), a joint statement was adopted on freedom of expression and incitement to racial and religious hatred.1

7. From 26 to 29 April, the Special Rapporteur participated in a seminar in Doha organized by the Al-Jazeera Media Training and Development Centre, in cooperation with the Geneva Institute for Human Rights, on the role of the media in the promotion and protection of human rights.

8. On the occasion of World Press Freedom Day, as proclaimed by the General Assembly, from 1 to 3 May the Special Rapporteur participated in a seminar organized by the United Nations Educational, Scientific and Cultural Organization (UNESCO) and the Doha Centre for Media Freedom. That seminar, which was entitled "The potential of the media: dialogue, mutual understanding and reconciliation", also served as the venue for the award of the UNESCO/Guillermo Cano World Press Freedom Prize for 2009.

9. From 1 to 6 June, he participated in the Global Forum on Freedom of Expression, organized by the Norwegian Ministry of Foreign Affairs.

10. From 29 June to 3 July, the Special Rapporteur participated in the sixteenth Annual Meeting of Special Rapporteurs, Representatives, Independent Experts and Chairpersons of Working Groups of the Human Rights Council in Geneva.

11. In July, at the invitation of the Civil Society Advisory Council, the Special Rapporteur travelled to Argentina to take part in various meetings and to support the adoption of the Audiovisual Communication Services Act, which was finally approved.

12. On 1 and 2 September, he participated in a meeting of the Working Party on Human Rights (COHOM) in Brussels which focused on freedom of expression on the Internet.

13. On 10 September, he participated in a workshop in Mexico on standards for regulating radio frequency allocation as a guarantee of diversity in broadcasting. He also took part in the sixth annual Transparency Week, held from 27 to 29 October 2009 by the Federal Institute for Access to Public Information, and in a dialogue on freedom of expression, held on 28 October 2009 at the Italian Cultural Institute, with the support of the Office of the High Commissioner for Human Rights in Mexico.

14. From 13 to 15 October, the Special Rapporteur participated in a conference in Seoul entitled "Freedom of Opinion and Expression in Cyberspace: the situation and challenges in East Asia". The conference was organized by the Asian Forum for Human Rights and Development, the Korean Network for International Human Rights and the Korean University Global Legal Clinic.

15. From 9 to 10 November, the Special Rapporteur took part in a seminar organized by the Latin American Association for Educational Radio (ALER) in Quito.

16. From 12 to 13 November, the Special Rapporteur attended a meeting of the Permanent Commission on Political and Municipal Affairs and Integration organized by the Latin American Parliament in Buenos Aires.

17. From 15 to 18 November, he participated in the fourth annual meeting of the Internet Governance Forum in Sharm el-Sheikh, Egypt, where he took part in a discussion on access and diversity.

18. From 2 to 5 December, the Second United Nations Regional Conference on Human Rights for Young People in Latin America and the Caribbean took place in Mexico City.

<sup>1</sup> See the English text of the declaration at http://www2.ohchr.org/english/issues/opinion/docs/ SRJointstatement22April09New.pdf.

The Special Rapporteur addressed the issue of freedom of expression and communication skills at the event, which was organized by the United Nations Information Centre OHCHR, the United Nations Children's Fund (UNICEF), UNESCO and the United Nations Population Fund.

19. From 8 to 9 December, he participated in a regional consultation in Washington D.C. entitled "Enhancing Cooperation between Regional and International Mechanisms for the Promotion and Protection of Human Rights". The event was organized by OHCHR in coordination with other organizations.

### **C. Country visits**

20. The Special Rapporteur notes that country visits will remain central to the activities of his mandate. Visits undertaken by the former Special Rapporteur, along with requests made to Governments for official country visits and the trends that emerge from an analysis of communications on freedom of expression and opinion, form the basis of requests sent to Governments for an invitation to visit their countries. Requests for invitations to visit a number of countries have been sent by the Special Rapporteur, taking into consideration the importance of achieving a geographical balance. The Special Rapporteur hopes that visit requests will be favourably received by the Governments concerned.

#### **1. Upcoming missions**

21. For 2010, the Special Rapporteur has received invitations from the following Governments: the Republic of Korea (visit scheduled for 6 to 14 May); Mexico (visit scheduled from 10 to 21 August, to be made in conjunction with the Special Rapporteur for Freedom of Expression for the Inter-American Commission on Human Rights, Ms. Catalina Botero); and Israel (visit scheduled for September).

22. The Special Rapporteur would also like to thank the Italian Government for inviting him to visit the country. The dates of the visit have yet to be agreed upon.

#### **2. Pending requests**

23. As of March 2010, the following requests from the Special Rapporteur were pending: the Islamic Republic of Iran (request made in February 2010), Sri Lanka (request made in June 2009), Tunisia (requested in 2009), and the Bolivarian Republic of Venezuela (requests made in 2003 and in 2009).

# **III. Main themes**

## **A. General considerations on the right to freedom of opinion and expression**

24. As provided for in article 19 of the International Covenant on Civil and Political Rights, the right to freedom of opinion and expression comprises three different elements: (a) the right to hold opinions without interference; (b) the right to seek and receive information and the right of access to information; and (c) the right to impart information and ideas of all kinds, regardless of frontiers, either orally, in writing or in print, in the form of art, or through any other media of one's choice.

25. The right to freedom of opinion and expression, like all rights, imposes legal obligations upon Governments: (a) to respect that right, or to refrain from interfering with the enjoyment of that right; (b) to protect that right or to exercise due diligence in order to prevent, punish, investigate and provide redress for harm caused by private persons or entities; and (c) to give effect to that right or to take positive or proactive measures to permit the realization of that right.

26. As stipulated in resolution 12/16 of the Human Rights Council, "the exercise of the right to freedom of opinion and expression is one of the essential foundations of a democratic society, is enabled by a democratic environment, which offers, inter alia, guarantees for its protection, is essential to full and effective participation in a free and democratic society, and is instrumental to the development and strengthening of effective democratic systems" (second preambular paragraph).

27. The importance of the right to freedom of opinion and expression for the development and reinforcement of truly democratic systems lies in the fact that this right is closely linked to the rights to freedom of association, assembly, thought, conscience and religion, and participation in public affairs. It symbolizes, more than any other right, the indivisibility and interdependence of all human rights. As such, the effective enjoyment of this right is an important indicator with respect to the protection of other human rights and fundamental freedoms.

28. Thus, the right to freedom of opinion and expression should also be understood to be an essential instrument for the promotion and protection of other human rights. It is an important tool for combating impunity and corruption, as well.

29. Furthermore, freedom of opinion and expression, although an individual right in the broadest sense of its enjoyment, is also a collective right. It endows social groups with the ability to seek and receive different types of information from a variety of sources and to voice their collective views. This freedom extends to mass demonstrations of various kinds, including the public expression of spiritual or religious beliefs or of cultural values. It is also a right of different peoples, who, by virtue of the effective exercise of this right, may develop, raise awareness of, and propagate their culture, language, traditions and values.

#### **1. Right of access to information**

30. As provided for in article 19 of the International Covenant on Civil and Political Rights, everyone has the right to seek information (which goes beyond simply being passive recipients of information); the exercise of this right may be subject to restrictions as specified in article 19, paragraph 3.

31. The Human Rights Committee has emphasized the importance of the right of citizens to be informed of the activities of public officials and to have access to information that will enable them to participate in political affairs. In a democracy, the right of access to public information is fundamental in ensuring transparency. In order for democratic procedures to be effective, people must have access to public information, defined as information related to all State activity. This allows them to take decisions; exercise their political right to elect and be elected; challenge or influence public policies; monitor the quality of public spending; and promote accountability. All of this, in turn, makes it possible to establish controls to prevent the abuse of power.

32. Governments should take the necessary legislative and administrative measures to improve access to public information for everyone. There are specific legislative and procedural characteristics that any access-to-information policy must have, including: observance of the principle of maximum disclosure; the presumption of the public nature of meetings and key documents; broad definitions of the type of information that is accessible; reasonable fees and time limits; independent review of refusals to disclose information; and sanctions for noncompliance.2

33. If mechanisms to promote the right of access to public information are lacking, then the members of society will not be informed or able to participate, and decision-making will not be democratic. Consequently, the Special Rapporteur urges Governments to adopt legislation to ensure access to public information and to establish specific mechanisms for that purpose. He therefore welcomes the initiative of the United Mexican States to set up the Federal Institute of Access to Public Information (IFAI) as an independent national body.

34. An important aspect of access to public information is access to historical information and archives and to information on current procedures that may shed light on human rights violations. Such access allows victims to exercise their right to truth, bearing in mind that the truth is the first step towards the right to justice and then the right to compensation, which are fundamental rights of victims. Victims not only have the right to establish the truth: why, how and who violated their human rights; they also have the right to make it public if they so wish, and this is particularly the case when they wish to honour the memory of those whose right to life has been violated.

### **2. Access to means of communication**

35. All the various outlets of the mass media have a social role to play. Electromagnetic frequencies are a public good, and the Government should therefore guarantee access to them and should use them and authorize their use in an equitable and fair way for all sectors of society. It is recommended that an independent, national (public) agency be in charge of administering and managing the allocation of broadcasting frequencies.

36. In recent years, the mass media have been viewed worldwide as a business, and this has paved the way for the concentration of media into large private or public consortia. This runs counter to the principle of pluralism and diversity that should underpin genuine freedom of expression. It also constitutes a concentration of political power that threatens democratic models.

37. Access to means of communication and, in particular, to electronic communications is now seen as necessary for achieving development and, therefore, should also be considered as an economic and social right. Governments should take responsibility for facilitating and subsidizing access to electronic media to ensure equitable enjoyment of this right, to combat poverty and to achieve their development goals.

38. Accordingly, the Special Rapporteur considers that, in order to achieve the Millennium Development Goals, the right of access to electronic communications and freedom of opinion and expression in general must be guaranteed. It is therefore necessary to reduce the digital divide and the gap in technological progress between developed and developing nations, in line with the recommendations contained in the Millennium Declaration (General Assembly resolution 55/2, para. 20). In particular, target 5 of goal 8 states: "in cooperation with the private sector, make available the benefits of new technologies, especially information and communications".3

39. The Special Rapporteur will focus primarily on the issue of access to electronic communications and freedom of expression on the Internet in his 2011 report.

<sup>2</sup> Annual Report of the Special Rapporteur for Freedom of Expression of the Organization of American States, 2003, Chapter IV, para. 32. 3

See text at http://www.un.org/millenniumgoals/global.shtml.

## **B. Freedom of expression for groups in need of particular attention and the role of freedom of expression in combating discrimination**

40. The Special Rapporteur considers that Governments should remove all barriers that impede the full exercise of the right to freedom of opinion and expression and that hinder development and decision-making.

41. In this context, the right to freedom of expression gains added value when it is used to protect groups or minorities in need of particular attention, such as women, children, those living in extreme poverty, minorities, indigenous peoples and migrant populations.

### **1. Women and children and the exercise of their right to freedom of opinion and expression**

 *(a) Women* 

42. In accordance with the Special Rapporteur's mandate to mainstream women's human rights and a gender perspective in all his activities, this report reiterates the undeniable link between freedom of expression and women's human rights, which include the right to express their opinions, to have access to their own means of communication and to work in the existing mass media. The following considerations should be taken into account in this regard.

43. General comment No. 28 of the Human Rights Committee on the equality of rights between men and women (article 3 of the Covenant) states that the causes of the inequality of women throughout the world include traditional, historical, cultural and even religious factors. This situation also influences the enjoyment of and respect for all the rights enshrined in the Covenant, including the right to freedom of opinion and expression and the right to access information in order to make informed decisions.

44. Everyone has the right to access the information needed to form opinions or to take decisions. However, women, in particular, have sometimes been denied full enjoyment of this right and, in extreme cases, this has led to them being denied information or the education they need. In cases where the State has failed to promote and ensure access to information and education, to means of expressing opinions, and to health and anti-violence programmes, this failure has had a negative impact on women's ability to make informed decisions freely. Therefore, the Special Rapporteur considers that Governments should prioritize women's education and access to information in their public policies.

45. General recommendation No. 19 of the Committee on the Elimination of Discrimination against Women (para. 11) states that the underlying consequences of violence contribute to maintaining women in subordinate roles, to their low level of political participation and to their lower level of education, skills and work opportunities, thereby exposing them to other risks such as the propagation of pornography and other forms of commercial exploitation.

46. Similarly, in its general recommendation No. 23, the Committee on the Elimination of Discrimination against Women (para. 20 (a)) states that one of the obstacles (in addition to illiteracy and a lack of knowledge and understanding of political systems) to the exercise of women's right to vote and to be elected is that their access to information about candidates, party political platforms and voting procedures is more restricted than men's. In this regard, the Special Rapporteur highlights shortcomings in civil registry systems that must be remedied.

47. It is, therefore, fitting to recall the important contribution made by the Beijing Platform for Action of 1995, in which particular concern was expressed about the continued projection of negative and degrading images of women and about their unequal access to information technology. Governments were therefore called upon to empower women by enhancing their skills, knowledge, access to information technology and role in the development of new technologies. The Special Rapporteur considers that the exercise of the freedom of expression necessarily implies an increase in women's participation in public affairs and in their involvement in decision-making on issues that may directly influence their development.

48. The existence of other effective means notwithstanding, electronic communication media are now available that allow women to disseminate information immediately and cheaply, as well as enabling them to establish contacts and networks and to organize, mobilize and inform themselves more effectively.

49. The fact that the possibility of reporting domestic violence, violence against women and child abuse now exists has a direct effect on the fight against impunity. Silence is also a form of impunity, and one way of breaking it is to ensure women's freedom of expression.

### *(b) Children*

50. The Convention on the Rights of the Child requires Governments to ensure that children are able to exercise their right to freedom of expression (art. 13). The Special Rapporteur considers that freedom of expression is the primary channel for participation and serves as a mechanism for inclusion; this right is therefore necessarily linked to the recognition of and respect for human dignity from childhood onward.

51. The evolution of one's own thinking, the ability to express one's thoughts clearly and the capacity to use alternative means of expression, such as art and electronic and audiovisual means of communication, begin to be developed in childhood. Therefore, child protection programmes should make a special effort to focus on respect for children's freedom of opinion and expression. Early stimulation and learning programmes should also be promoted, as should full access to schooling and participatory educational programmes that encourage critical thinking, the capacity for expression and a culture of peace.4

52. While upholding the right to freedom of expression, Governments have a duty to protect children from information that could undermine their dignity and development. They should therefore establish protective mechanisms and define their content, scope and implementation methods in their domestic human rights laws (see section C below on limitations).

53. Respecting children's freedom of expression and listening to them attentively are also an important factor in combating child abuse and domestic violence and in ensuring that these acts do not go unpunished.

#### **2. Persons living in extreme poverty: access to communication and freedom of expression**

54. As poverty is a multidimensional phenomenon that restricts the exercise of all human rights, its eradication would help to ensure the realization of these rights, including the right to freedom of opinion and expression and the right to have access to new communication technologies. The limitation of this right leads to social exclusion and obstructs human development.

<sup>4</sup> Declaration and Programme of Action on a Culture of Peace, General Assembly resolution 53/243. Article 1 stipulates that "[a] culture of peace is a set of values, attitudes, traditions and modes of behaviour and ways of life based on […] [r]espect for and promotion of the right of everyone to freedom of expression, opinion and information".

55. Persons living in poverty find it difficult to make their voices heard. Their circumstances prevent them from exercising their right to free speech; poverty restricts their access to information, to education and to the media. Illiteracy is particularly a problem among the poor, and Governments should therefore continue their efforts to eradicate it.

56. Freedom of opinion and expression and access to communication are tools that can contribute to the eradication of poverty. By exercising this right, poor social groups can obtain information, assert their rights and participate in the public debate concerning social and political changes that would improve their situation. Access to communication is also fundamental to economic and social development because it enables communities to obtain the information they need to run their own activities. Governments should therefore ensure access to communication, in general, and to electronic means of communications, in particular, in order to combat poverty.

57. Recalling the Colombo Declaration of 2006 on media, development and poverty eradication, which states in paragraph 1: "Freedom of expression should be made available to all. It requires effective local participation to empower individuals and groups to address poverty, hunger, disease, discrimination, vulnerability, social exclusion, environmental degradation and education." The Declaration also calls on Governments to "expand the reach of information and communication technologies especially to poor and marginalized populations".

58. In this context, the independent expert on the question of human rights and extreme poverty asserted that "[e]ffective and meaningful participation by people living in poverty requires that a broad set of rights are respected, protected and fulfilled, including freedom of expression […] In practice, this requires the establishment of specific mechanisms and arrangements at different levels to ensure that there are ways in which those living in poverty have a voice and play an effective part in the life of the community".5

### **3. Minorities and indigenous peoples**

59. The Special Rapporteur emphasizes the importance that exercising the right to freedom of opinion and expression has for minorities and indigenous peoples, as freedom of opinion and expression is a basic tool for ensuring the specific recognition of the rights demanded by these groups.

60. Article 16 of the United Nations Declaration on the Rights of Indigenous Peoples states that indigenous peoples have the right to establish their own media in their own languages and to have access to all forms of non-indigenous media without discrimination. Therefore, the Special Rapporteur considers that, in addition to fulfilling their duty to ensure freedom of opinion and expression, it is of paramount importance for Governments to honour their obligation to promote indigenous cultural diversity in the public and private media.

61. Consequently, the Special Rapporteur encourages the mass media to ensure that they have a representative and diverse staff. He also urges the press and mass media to provide coverage that creates an atmosphere of respect for cultural diversity and multiculturalism.

62. Governments should take into account the ethnic, cultural, religious and ideological diversity of the various social groups. They should also promote and protect the languages of minorities and indigenous peoples by, inter alia, upholding their right to speak their own language and to propagate their culture and traditions, both in private and in public. In no

<sup>5</sup> Report of the independent expert (A/63/274), para. 22.

case should restrictions on the freedom of expression be used to stifle minorities' and indigenous peoples' legitimate claims to their rights.

63. In accordance with general comment No. 23 of the Human Rights Committee on the rights of minorities (article 27 of the Covenant), the Special Rapporteur recalls that even when individuals are not citizens of the State where they live or happen to be, "a State party is required […] to ensure that the rights protected under the Covenant are available to all individuals within its territory and subject to its jurisdiction" (para. 5.1). The Special Rapporteur also reiterates that migrants and migrant communities, regardless of their legal migratory status, are fully entitled to exercise freedom of expression.

64. The Special Rapporteur reiterates the comments of the Human Rights Committee in noting that Governments should ensure that minorities exercise their freedom of opinion and expression so that they can enjoy their own culture, profess and practise their own religion and use their own language in accordance with article 27 of the Covenant.

65. The final declaration of the Durban Review Conference made an important contribution to our understanding of the role of freedom of expression in combating discrimination and racism, highlighting, in paragraph 58 of the outcome document, "that the right to freedom of opinion and expression constitutes one of the essential foundations of a democratic, pluralistic society and stresses further the role these rights can play in the fight against racism, racial discrimination, xenophobia and related intolerance worldwide". In this regard the Special Rapporteur encourages all Governments to develop a culture of peace based on information, the free exchange of ideas and knowledge, dialogue and tolerance between cultures in order to promote respectful intercultural relations and to break down existing stereotypes and prejudices.

#### **4. Community-based media**

66. The right to freedom of opinion and expression includes the freedom for minority and excluded groups to give, receive and transmit information. Community-based media are effective ways to accomplish that, and it is the duty of Governments to assist and support them in doing so and to ensure equitable access. The Special Rapporteur reiterates the call to Governments, made in paragraph 3 of the relevant section of the Colombo Declaration, to "develop national policies that address access to, and participation in, information and communication for people living in poverty, including access to licenses and fair spectrum allocation".

67. Protecting disadvantaged social groups' right to freedom of expression requires Governments to create a legal framework for telecommunications which is based on democratic principles and which seeks to provide access to all sectors of society. Community-based media should serve as a tool for local communities and should be representative of their diverse interests.

68. The Special Rapporteur defines community-based media as non-governmental, public interest radio stations and print media that are run by civil society institutions, organizations or associations and any type of non-profit organization run by indigenous peoples for educational, informative, cultural or communal goals purposes. These media work for the development of different sectors of a territorial, ethno-linguistic or other community. They share their communities' interests, challenges and concerns and seek to improve the quality of life of their community and to contribute to the well-being for all its members. They must not be used as instruments for political campaigning.

69. In order for all sectors of society to have access to information and the opportunity to participate in the national public debate, it is important to uphold the principle of media diversity and pluralism and to do away with monopolies and large media consortia. The concentration of the media leads to a concentration of political power and jeopardizes democracy and the ability of all sectors of society to exercise their right to freedom of opinion and expression.

70. The Special Rapporteur would like to highlight the joint work undertaken with the World Association of Community Radio Broadcasters (AMARC) through a series of regional consultations held for the purpose of identifying and endorsing the principles that should underlie a democratic regulatory framework for community radio and television. Information on these principles is included in the annex. These principles are:

- (a) Media diversity, content and perspectives;
- (b) Recognition and promotion;
- (c) Definition and characteristics;
- (d) Objectives and aims;
- (e) Technological access;
- (f) Universal access;
- (g) Reserved frequencies;
- (h) Competent authorities;
- (i) Licence and frequency allocation procedures;
- (j) Non-discriminatory conditions;
- (k) Evaluation criteria;
- (l) Financing;
- (m) Public funding;
- (n) Digital inclusion.

71. It is important for Governments to promote measures and adopt good practices oriented toward equity in telecommunications. In this regard, the Special Rapporteur welcomes the promulgation by Argentina of the Audio-visual Materials Distribution Act, which is a good example of such practices.

## **C. Permissible restrictions and limitations on freedom of expression**

72. Although the right to freedom of expression is important for democracy and the exercise of other rights, as highlighted in section A, this right is not absolute. International law, and most national constitutions, recognize that the exercise of the right to freedom of expression carries with it special duties and responsibilities and may be restricted in certain exceptional circumstances. The right to freedom of opinion, on the other hand, is a right to which the Covenant permits no exception or restriction, as stated, inter alia, in general comment No. 10 of the Human Rights Committee.

73. In accordance with resolution 7/36 of the Human Rights Council, the mandate of the Special Rapporteur includes reporting on instances in which the abuse of the right of freedom of expression constitutes an act of racial or religious discrimination, as well as formulating recommendations and making suggestions concerning methods of promoting and protecting the right to freedom of opinion and expression in all its forms. Accordingly, as a contribution to the consideration of this issue, in this report the Special Rapporteur proposes a series of principles that will help to determine what constitutes a legitimate restriction or limitation on the right of freedom of opinion and expression and what constitutes an "abuse" of that right.

74. Article 19, paragraph 3, of the International Covenant on Civil and Political Rights sets out three factors that should be taken into account when assessing whether restrictions are permissible: (a) they must be provided for by law; (b) they must be necessary; and (c) they must pursue one of the legitimate aims set forth in the article, i.e. (i) the respect of the rights or reputations of others; (ii) the protection of national security or public order (*ordre public*); or (iii) the protection of public health or morals. In addition, in its article 20, paragraph 2, the Covenant states that "any advocacy of national, racial or religious hatred that constitutes incitement to discrimination, hostility or violence shall be prohibited by law".

75. The Special Rapporteur notes that, despite the provisions of the Covenant, States frequently limit or restrict freedom of expression arbitrarily, sometimes by recourse to criminal legislation, in order to silence dissent or criticism. In view of such practices, the Special Rapporteur wishes to draw attention to some of the existing principles that may be used to determine whether or not a limitation or restriction to the right of freedom of expression is legitimate within the framework of existing standards.

76. The limitations and restrictions must be provided for by prior law within the framework of international human rights law and the principles deriving therefrom.

77. The general principle is that permissible limitations and restrictions must constitute an exception to the rule and must be kept to the minimum necessary to pursue the legitimate aim of safeguarding other human rights established in the Covenant or in other international human rights instruments.

78. The principles proposed in this document have been compiled by the Special Rapporteur from various public sources, including the Siracusa Principles on the Limitation and Derogation Provisions in the International Covenant on Civil and Political Rights (E/CN.4/1985/4, annex) and the general comments adopted by the Human Rights Committee, including No. 10 (article 19 of the Covenant),6 No. 11 (article 20 of the Covenant) and No. 27 (article 12 of the Covenant). Although general comment No. 27 concerns freedom of movement, it encapsulates the Human Rights Committee's position on permissible limitations on the rights established in the Covenant.

79. The Special Rapporteur proposes the following principles for determining the conditions that must be satisfied in order for a limitation or restriction on freedom of expression to be permissible:

 (a) The restriction or limitation must not undermine or jeopardize the essence of the right of freedom of expression;

 (b) The relationship between the right and the limitation/restriction or between the rule and the exception must not be reversed;

 (c) All restrictions must be provided for by pre-existing statutory laws issued by the legislative body of the State;

 (d) Laws imposing restrictions or limitations must be accessible, concrete, clear and unambiguous, such that they can be understood by everyone and applied to everyone. They must also be compatible with international human rights law, with the burden of proving this congruence lying with the State;

 (e) Laws imposing a restriction or limitation must set out the remedy against or mechanisms for challenging the illegal or abusive application of that limitation or

<sup>6</sup> The Special Rapporteur notes that the Human Rights Committee is drafting a general comment on article 19 of the Covenant.

restriction, which must include a prompt, comprehensive and efficient judicial review of the validity of the restriction by an independent court or tribunal;

 (f) Laws imposing restrictions or limitations must not be arbitrary or unreasonable and must not be used as a means of political censorship or of silencing criticism of public officials or public policies;

 (g) Any restrictions imposed on the exercise of a right must be "necessary", which means that the limitation or restriction must:

(i) Be based on one of the grounds for limitations recognized by the Covenant;

 (ii) Address a pressing public or social need which must be met in order to prevent the violation of a legal right that is protected to an even greater extent;

(iii) Pursue a legitimate aim;

 (iv) Be proportionate to that aim and be no more restrictive than is required for the achievement of the desired purpose. The burden of demonstrating the legitimacy and the necessity of the limitation or restriction shall lie with the State;

 (h) Certain very specific limitations are legitimate if they are necessary in order for the State to fulfil an obligation to prohibit certain expressions on the grounds that they cause serious injury to the human rights of others. These include the following:

 (i) Article 20 of the Covenant, which establishes that "any propaganda for war" and "any advocacy of national, racial or religious hatred that constitutes incitement to discrimination, hostility or violence shall be prohibited by law";

 (ii) Article 3, paragraph 1 (c), of the Optional Protocol to the Convention on the Rights of the Child on the sale of children, child prostitution and child pornography, which provides that States must ensure that their criminal law covers "producing, distributing, disseminating, importing, exporting, offering, selling or possessing [.] child pornography";

 (iii) Article 4 (a) of the International Convention on the Elimination of All Forms of Racial Discrimination, which establishes the requirement to "declare an offence punishable by law all dissemination of ideas based on racial superiority or hatred, incitement to racial discrimination, as well as all acts of violence or incitement to such acts against any race or group of persons of another colour or ethnic origin";

 (iv) Article III (c) of the Convention on the Prevention and Punishment of the Crime of Genocide, which states that "direct and public incitement to commit genocide" shall be punishable;

 (i) Restrictions already established must be reviewed and their continued relevance analysed periodically;

 (j) In states of emergency which threaten the life of the nation and which have been officially proclaimed, States are permitted to temporarily suspend certain rights, including the right to freedom of expression. However, such suspensions shall be legitimate only if the state of emergency is declared in accordance with article 4 of the Covenant and general comment No. 29 of the Human Rights Committee. A state of emergency may not under any circumstances be used for the sole aim of restricting freedom of expression and preventing criticism of those who hold power;

 (k) Any restriction or limitation must be consistent with other rights recognized in the Covenant and in other international human rights instruments, as well as with the fundamental principles of universality, interdependence, equality and non-discrimination as to race, colour, sex, language, religion, political or other belief, national or social origin, property, birth or any other status;

 (l) All restrictions and limitations shall be interpreted in the light and context of the particular right concerned. Wherever doubt exists as to the interpretation or scope of a law imposing limitations or restrictions, the protection of fundamental human rights shall be the prevailing consideration.

80. The principles set out herein should be understood to be of an exceptional nature. They are suggested as a means of ensuring that States do not abuse restrictions or limitations for political ends and that the application of such restrictions or limitations does not cause other rights to be violated. The principles should be applied in a comprehensive manner.

81. The Special Rapporteur also wishes to stress that, as provided in paragraph 5 (p) of Human Rights Council resolution 12/16, restrictions on the following aspects of the right to freedom of expression are not permissible:

 (i) Discussion of government policies and political debate; reporting on human rights, government activities and corruption in government; engaging in election campaigns, peaceful demonstrations or political activities, including for peace or democracy; and expression of opinion and dissent, religion or belief, including by persons belonging to minorities or vulnerable groups;

 (ii) The free flow of information and ideas, including practices such as the banning or closing of publications or other media and the abuse of administrative measures and censorship;

 (iii) Access to or use of information and communication technologies, including radio, television and the Internet.

82. With regard to limitations on freedom of expression justified on the basis of the protection of other rights or the reputation of others, the Special Rapporteur reiterates that this justification must not be used to protect the State and its officials from public opinion or criticism. The Special Rapporteur is of the view that no criminal or civil action for defamation should be admissible in respect of a civil servant or the performance of his or her duties. In addition, all *desacato* laws should be repealed.

83. The Special Rapporteur believes that any attempt to criminalize freedom of expression as a means of limiting or censuring that freedom must be resisted. He therefore encourages all efforts to decriminalize acts considered to be acts of defamation and to make civil liability proceedings the sole form of redress for complaints of damage to reputation. However, civil penalties for defamation should not be so heavy as to block freedom of expression and should be designed to restore the reputation harmed, not to compensate the plaintiff or to punish the defendant; in particular, pecuniary awards should be strictly proportionate to the actual harm caused, and the law should give preference to the use of non-pecuniary remedies, including, for example, apology, rectification and clarification.

84. In addition, criminal defamation laws may not be used to protect abstract or subjective notions or concepts, such as the State, national symbols, national identity, cultures, schools of thought, religions, ideologies or political doctrines. This is consistent with the view, sustained by the Special Rapporteur, that international human rights law protects individuals and groups of people, not abstract notions or institutions that are subject to scrutiny, comment or criticism.

85. On this basis, and recalling the Joint Declaration issued by the International Mechanisms for Promoting Freedom of Expression in 2008: "The concept of 'defamation of religions' does not accord with international standards regarding defamation, which refer to the protection of the reputation of individuals, while religions, like all beliefs, cannot be said to have a reputation of their own." The Special Rapporteur reiterates that, in his point of view, it is conceptually incorrect to present the issue of "defamation of religions" in an abstract manner as a conflict between the right to freedom of religion and belief and the right to freedom of opinion and expression.

86. The Special Rapporteur notes and deeply regrets the continuing existence in the world of stereotypes and prejudice against ethnic, racial, linguistic and religious groups that are the result of racism and discrimination or of the erroneous application of national security and anti-terrorism policies. It is essential that this problem be recognized and that it be countered by a developing culture of peace based on intercultural dialogue and tolerance which promotes respect in intercultural relationships.

87. The Durban Review Conference outcome document made an important contribution to our understanding of freedom of opinion and expression in the context of the effort to combat discrimination and racism in its paragraph 58, which: "Stresses that the right to freedom of opinion and expression constitutes one of the essential foundations of a democratic, pluralistic society, and stresses further the role that right can play in the fight against racism, racial discrimination, xenophobia and related intolerance worldwide."

## **D. Protection of journalists and freedom of the press**

88. The right to be informed and to receive information from various media is a key factor in the development of social groups. This right is a cornerstone of democracy and supports the construction of more democratic societies peopled by active citizens who hold informed opinions about the situation in their country and have the capacity and opportunity to propose and contribute to public policies and to demand transparency.

89. The Special Rapporteur is deeply concerned that providers of information have become targets for threats, assaults and even assassinations. It is deplorable that, between 2008 and 2009, there was an increase in the number of killings, assassinations, assaults and incidents of ill-treatment against persons associated with journalism and mass communication.

90. According to the NGO Reporters Without Borders, in 2009 around 76 journalists were killed in the exercise of their profession. This figure represents an increase of at least 26 per cent over the 2008 level.7

91. The Special Rapporteur calls on the Philippines, Somalia, Iraq, Pakistan, the Russian Federation and Mexico8 (the States accounting for the greatest number of journalists' deaths, in descending order) to adopt the measures necessary to guarantee the protection of journalists.

92. The high-risk conditions in which journalists carry out their work, as evidenced by the threats and assaults to which they constantly fall victim, are also a matter of concern.

93. A particular concern is the fact that a high percentage of the killings for which the motives have been confirmed were connected to investigations into corruption, organized crime and political crime that the journalists in question were conducting at the time.

<sup>7</sup> Reporters Without Borders, "Wars and disputed elections: the most dangerous stories for journalists", 30 December 2009, www.rsf.org/Wars-and-disputed-elections-The.html. 8

Committee to Protect Journalists, "71 Journalists Killed in 2009/Motive Confirmed", cpj.org/killed/2009/.

94. According to the Committee to Protect Journalists (CPJ), the perpetrators of these offences have enjoyed total impunity in 94 per cent of all cases, while the percentage of cases in which even some partial measure of justice has been obtained is minimal; in only 2 per cent of cases have the offences been tried before the competent authorities and the perpetrators and instigators prosecuted. Although the majority of the victims were male journalists, 11 per cent were women, which is also a matter for concern.

95. The States concerned maintain that violence against journalists has varied causes, which may be true. However, the Special Rapporteur believes that States have a duty to carry out exhaustive investigations into each case and to bring criminal charges against those responsible. Failure to perform this duty creates a culture of impunity which perpetuates the violence. Systematically allowing those responsible for killing journalists or social communicators to go unpunished could be interpreted as tolerance or acquiescence on the part of the State.

96. Furthermore, kidnappings of journalists and other persons with links to the media are a continuing practice which, in 2009, forced around 157 journalists to seek exile in other countries.9

97. The Special Rapporteur must also draw attention to the serious risk that exercising freedom of the press in a professional, objective and pluralistic manner constitutes in areas of conflict, where journalists have come to be seen by the parties to the conflict as just another target.

98. On this point, it should be noted that Security Council resolution 1738 (2006) condemns intentional attacks against journalists, media professionals and associated personnel in situations of armed conflict and calls upon all parties to put an end to such practices. It also urges all States to comply with the relevant obligations under international law to end impunity and to prosecute those responsible for serious violations of international humanitarian law.

99. In the aforementioned resolution, the Security Council also urges all parties involved in situations of conflict to respect the professional independence and rights of journalists, media professionals and associated personnel as civilians.

100. The Special Rapporteur considers it necessary to remind States of their obligation to ensure that both the national and the international press have access to all the facts and to all conflict zones and to provide members of the press with the protection due them in accordance with the aforementioned resolution.

101. The Special Rapporteur is concerned about the alarming and growing tendency to criminalize and institute legal proceedings against community-based communicators, who should also be considered journalists and media personnel, and should thus benefit from the same safeguards as all journalists, since a person's status as a journalist is determined by the work that he or she performs and is not subject to any job title or form of registration.

102. The Special Rapporteur also believes that, if a community-based medium has violated an administrative provision, it is within the administrative framework that a solution should be found; criminal law should not be applied, and community-based communicators should not be criminalized, since this severely limits freedom of expression.

103. The Special Rapporteur urges States to take steps to prevent violence against journalists and to improve the protection afforded to them. Drafting and implementing handbooks, guides and protocols on protection would constitute a good practice to this end.

<sup>9</sup> Ibid.

# **IV. Conclusions and recommendations**

## **A. Conclusions**

104. **The right to freedom of opinion and expression should be viewed as a key instrument for the promotion and protection of other human rights and an important tool in the effort to combat impunity and corruption**.

105. **Freedom of opinion and expression is an individual and collective right which affords people the opportunity to issue, seek, receive and impart pluralistic and diverse information that enables them to develop their own lines of reasoning and opinions and to express them in any way they see fit. Freedom of expression is therefore exercised through two routes: the right to access information and the right to self-expression through any medium**.

106. **Freedom of expression is also a right of peoples, in that, through its effective exercise, peoples can develop, impart and reproduce their culture, their language, their traditions and their values**.

107. **Freedom of opinion and expression should be viewed as a means of combating all forms of discrimination**.

108. **Lack of access to information in accordance with the principles of pluralism and diversity results in an ill-informed, non-participatory society in which political decision-making is not democratic**.

109. **Community-based media are effective instruments for ensuring the exercise of the right to freedom of opinion and expression in all social sectors, without any form of discrimination whatsoever, in accordance with the principles of pluralism and diversity that should guide the exercise of this right**.

110. **The Special Rapporteur is concerned about the growing digital divide and the disparity between developed and developing countries in terms of the development of electronic communications technologies**.

111. **Electronic communication is also an economic right, in that it is an essential factor for development. Accordingly, States should ensure that all sectors of society, and in particular the most disadvantaged among them, have access to electronic communications media**.

112. **Women continue to be denied the full exercise of their right to freedom of opinion and expression and, as a result, are also limited in the exercise of other fundamental rights, such as the rights to development, to education, to health, to participation and to a life free from violence**.

113. **Freedom of opinion and expression is an early form of participation for children and constitutes a mechanism for inclusion that necessarily entails recognition and respect of human dignity. Children's opinions should therefore be respected and taken into account**.

114. **The right to freedom of opinion is absolute and may not be limited in any way, whereas the right to freedom is not absolute and may thus be subject to exceptional restrictions and limitations as defined in article 19, paragraph 3, and article 20 of the International Covenant on Civil and Political Rights. Such restrictions and limitations must be interpreted in accordance with international human rights law and the principles deriving therefrom**.

115. **In exceptional circumstances, international human rights law permits certain limitations to freedom of expression. By establishing those limitations, the State is effectively fulfilling its obligation to prohibit certain expressions owing to the serious damage that they cause to the human rights of others, as provided for in article 20 of the Covenan**t.

116. **The Special Rapporteur reiterates his view that it is conceptually incorrect to present the issue of "defamation of religions" in the abstract as a conflict between the right to freedom of religion or belief and the right to freedom of opinion and expression**.

117. **The Special Rapporteur expresses concern about the violence to which journalists and media professionals continue to fall victim**.

118. **States have an obligation to guarantee to all individuals the full enjoyment of the right to freedom of opinion and expression through any medium, while ensuring that their human rights are respected and protected. In particular, they should guarantee the full enjoyment of this right to all persons engaged in journalistic activities in places of internal conflict or war, where the nature of their work places them in a position of greater vulnerability; all social communicators are considered to be journalists for this purpose**.

### **B. Recommendations**

 **1. General considerations concerning freedom of opinion and expression** 

119. **States should take the necessary steps to guarantee the effective exercise of the right to freedom of opinion and expression for all individuals and social sectors, without exception or discrimination of any kind**.

120. **States should refrain from criminalizing any manifestation of the freedom of expression as a means of limiting or censoring that freedom. Accordingly, any measure of this kind should be abolished, except for the permissible and legitimate restrictions established in international human rights law**.

121. **States should adopt the legislative and administrative measures necessary to facilitate access to public information and should establish specific mechanisms for that purpose.**

122. **It is recommended that States establish a legal framework that recognizes and regulates community-based communication within the framework of the 14 principles presented in this report and that a fair balance be struck in terms of frequency allocation among community-based media, commercial media and public-sector or State media**.

123. **It is recommended that frequency allocation should be overseen and managed by an independent State (public-sector) body**.

124. **It is recommended that States, the media and financial institutions implement the recommendations set forth in the Colombo Declaration, which are aimed at strengthening the freedom of expression of marginalized sectors of society and their access to media of their own, including electronic media, with a view not only to promoting freedom of expression and democracy but also to combating poverty and meeting the Millennium Development Goals. It is also recommended that States establish a special fund to subsidize access (which requires both connectivity and the necessary equipment) to electronic media for all sectors.**

125. **It is recommended that States facilitate technology transfer in the field of communications as a means of narrowing the digital and technological divide between the developed world and developing countries and thus contributing to the achievement of the Millennium Development Goals**.

126. **It is recommended that States respect the principles of pluralism and diversity, which are inherent in freedom of expression, in order to prevent and combat the concentration of media ownership in the hands of large-scale public and private consortia which contravene democratic models.** 

 **2. Freedom of expression for groups in need of particular attention and the role of freedom of expression in combating discrimination** 

> 127. **States should empower women by upgrading their theoretical knowledge and practical skills, improving their access to information technology and promoting their participation in the development of these technologies as a means of fostering and increasing their participation in public affairs and decision-making on issues likely to have a direct bearing on their development**.

> 128. **States are urged to prohibit and criminalize the production, distribution, dissemination, importation, exportation, offering, sale and possession of child pornography, which constitute acts of physical and psychological violence, as well as incitement to commit acts of violence against children, which constitutes, in addition, a failure to respect their human dignity**.

> 129. **States should take the necessary steps to support the expression of the cultural diversity of indigenous peoples and other minority groups in the public and private media. They should also promote policies on dialogue and education that foster understanding and respect in intercultural exchanges**.

> 130. **The Special Rapporteur also recommends that the mass media endeavour to employ a diverse workforce within which all sectors of society are represented and urges the press and mass media to voluntarily establish and adopt codes of professional conduct that help them to achieve this diversity**.

> 131. **The Special Rapporteur takes this opportunity to recommend that, in the implementation of anti-terrorism and national security measures, States act with absolute respect for human rights, applying articles 19 and 20 of the Covenant and other related provisions in order to ensure that such measures do not have a disproportionate effect on the exercise of freedom of expression**.

 **3. Protection of journalists and freedom of the press** 

132. **It is recommended that States take all actions necessary to ensure that representatives of the national and international press have access to all facts and to all places, including zones of internal or international armed conflict, while guaranteeing the protection necessary to safeguard their lives and their physical and mental integrity, together with the full exercise of their human rights in accordance with international human rights law and international humanitarian law**.

133. **With regard to the alarming number of journalists who have been killed, kidnapped or threatened, States are reminded of their duty to investigate and prosecute those responsible for planning and perpetrating such acts in order to eliminate the culture of impunity that perpetuates violence**.
![](_page_0_Picture_2.jpeg)

4 June 2012

Original: English

**Human Rights Council Twentieth session** Agenda item 3 **Promotion and protection of all human rights, civil, political, economic, social and cultural rights, including the right to development**

# **Report of the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression, Frank La Rue**\*

*Summary*

The present report builds on the previous work of the Special Rapporteur regarding the issue of the protection of journalists and media freedom, and focuses particularly on situations outside of armed conflict. A brief introduction is set out in Chapter I, noting that the majority of human rights violations against journalists take place outside of armed conflict situations. Chapter II provides a brief account of the main activities undertaken by the Special Rapporteur, including communications sent, participation in events, press releases issued and country visits undertaken and requested by the Special Rapporteur. Chapter III examines the challenges faced by journalists in carrying out their work, in particular when covering street protests and demonstrations or reporting on politically sensitive issues, such as human rights violations, environmental issues, corruption, organized crime, drug trafficking, public crises and emergencies. Particular challenges faced by journalists and media organizations when carrying out their work via the Internet is also highlighted. The increasing use of criminal laws to suppress media freedom is also examined, as well as the continuing problem of impunity. Emphasizing that the problem in ensuring the protection of journalists worldwide lies not in the lack of international standards, but in the inability or unwillingness of Governments to take effective measures, the report examines the issue of impunity and ways in which some States have attempted to combat this phenomenon. Chapter IV draws conclusions and provides relevant recommendations for different stakeholders, including States, United Nations agencies, regional actors and civil society.

\* Late submission.

GE.12-13787

![](_page_0_Picture_11.jpeg)

# Contents

| | | | Paragraphs | Page |
|------|-------------------------------------------------------------------------------------------------------|--------------------------------------------------------|------------|------|
| I. | Introduction | | 1–6 | 3 |
| II. | Activities of the Special Rapporteur | | 7–47 | 4 |
| | A. | Communications | 7 | 4 |
| | B. | Country visits | 8–12 | 4 |
| | C. | Press releases | 13–32 | 5 |
| | D. | Participation in meetings and seminars | 33–47 | 7 |
| III. | Challenges to the protection of journalists and media freedom<br>outside of armed conflict situations | | 48–91 | 9 |
| | A. | Overview | 48–60 | 9 |
| | B. | Safety and protection of online journalists | 61–64 | 11 |
| | C. | Impunity and prevention of attacks against journalists | 65–77 | 11 |
| | D. | Criminalization of expression | 78–91 | 14 |
| IV. | Conclusions and recommendations | | 92-117 | 16 |
| | A. | Conclusions | 92–99 | 16 |
| | B. | Recommendations | 100–117 | 17 |

# **I. Introduction**

1. The present report focuses on the protection of journalists and media freedom, an issue of central importance for the mandate of the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression. The Special Rapporteur previously considered the issue more comprehensively in his report to the General Assembly of 11 August 2010 (A/65/284), in which he examined trends with respect to violence against journalists in both conflict and non-conflict situations; the obligation of States under international human rights law and international humanitarian law and difficulties faced by so-called "citizen journalists." He also provided recommendations to enhance the protection of journalists and citizen journalists alike, in both conflict and nonconflict situations. The Special Rapporteur and previous mandate holders have also included a section on the protection of journalists and freedom of the press in their annual reports to the Human Rights Council. 1

2. Given the ongoing repression of journalists and media freedom worldwide, aimed at suppressing information deemed "inconvenient," and increasing restrictions placed on the work of journalists who also disseminate information through the Internet, the Special Rapporteur wishes to again bring the issue to the attention of the Human Rights Council. The present report focuses on the protection of journalists outside of armed conflict situations as the majority of human rights violations against journalists take place outside of armed conflict, and the Special Rapporteur on extrajudicial, summary or arbitrary executions will be presenting his annual report regarding the protection of journalists in conflict situations to the Human Rights Council. Moreover, the Human Rights Council held a panel discussion on the protection of journalists in armed conflict situations on 4 June 2010 (A/HRC/15/54), and the United Nations Security Council, whose binding powers do not extend to human rights violations in times of peace or when peace is not threatened, has condemned attacks against journalists in conflict situations in resolution 1738, adopted on 23 December 2006.

3. The Special Rapporteur affirms that journalism must be seen as an activity and profession that constitutes a necessary service for any society, as it provides individuals and society as a whole with the necessary information to allow them to develop their own thoughts and to freely draw their own conclusions and opinions. By exercising the right to "seek and receive information," individuals can make informed decisions and express their opinions freely and participate actively in a democratic system.

4. Against this backdrop, and defined by their function and service, journalists are individuals who observe and describe events, document and analyse events, statements, policies, and any propositions that can affect society, with the purpose of systematizing such information and gathering of facts and analyses to inform sectors of society or society as a whole. Such a definition of journalists includes all media workers and support staff, as well as community media workers and so-called "citizen journalists" when they momentarily play that role.

5. Indeed, the Human Rights Committee, in its general comment No. 34, has also adopted a functional definition of journalism, by defining journalism as "a function shared by a wide range of actors, including professional full-time reporters and analysts, as well as bloggers and others who engage in forms of self-publication in print, on the Internet or elsewhere" (para. 44).

<sup>1</sup> See for example A/HRC/4/27, A/HRC/7/14, A/HRC/11/4, A/HRC/14/23.

6. The Special Rapporteur also emphasizes that journalists must seek to develop their professional abilities academically and in practice; journalists may form professional associations to guarantee professionalism and common ethical standards; and journalists may register for the purposes of obtaining an identification card to allow them to have access to certain events. However, under no circumstances should such conditions be imposed by State authorities as preconditions to practice journalism, given that journalism as a profession can only fulfil its role if it has full guarantees of freedom and protection.

# **II. Activities of the Special Rapporteur**

## **A. Communications**

7. Between 1 April 2011 and 20 March 2012, the Special Rapporteur sent 218 communications, 213 of which were submitted jointly with other special procedures mandate holders. The geographical distribution of the communications was as follows: 29 per cent for Asia and the Pacific; 23 per cent for the Middle East and North Africa; 21 per cent for Latin America and the Caribbean; 15 per cent for Europe, Central Asia and North America; and 12 per cent for Africa. The summary of communications sent and replies received from Governments can be found in the following special procedures communications reports: A/HRC/18/51, A/HRC/19/44 and A/HRC/20/30.

### **B. Country visits**

#### **1. Missions undertaken in 2011**

8. The Special Rapporteur undertook a mission to Algeria from 10 to 17 April 2011. His main findings and recommendations to the Government can be found in the addendum to this report (A/HRC/20/17/Add.1).

9. The Special Rapporteur visited Israel and the occupied Palestinian territories from 6 to 17 December 2011. His main findings and recommendations can be found in the addendum to this report (A/HRC/20/17/Add.2).

#### **2. Upcoming missions**

10. Following an invitation received from the Government of Honduras on 25 October 2011, the Special Rapporteur is in the process of finalizing dates for a joint visit with the Special Rapporteur for freedom of expression of the Inter-American Commission on Human Rights.

11. Following an invitation received from the Government of Pakistan on 7 February 2012, the Special Rapporteur is in the process of confirming the specific dates of the visit.

#### **3. Pending visit requests**

12. As of March 2012, the following visit requests from the Special Rapporteur were pending: Ecuador (requested most recently in February 2012), Iran (Islamic Republic of) (requested in February 2010), Italy (requested in 2009), Sri Lanka (requested in June 2009), Thailand (requested in 2012), Tunisia (requested in 2009), Uganda (requested in May 2011) and Venezuela (Bolivarian Republic of) (requested in 2003 and 2009).

## **C. Press releases**

13. On 22 March 2011, the Special Rapporteur issued a joint press release<sup>2</sup> on the deteriorating situation in Bahrain, noting that the Government had failed to implement human rights commitments made in February 2012. He called on the Government to fully respect the right to fully guarantee the rights of peaceful demonstrators expressing their legitimate concerns and grievances.

14. On 5 April 2011, at the end of his three-day visit to Hungary, the Special Rapporteur highlighted his outstanding concerns regarding the Hungarian media legislation, such as restrictions on media content based on vague concepts, insufficient guarantees to ensure the independence and impartiality of the regulatory body empowered to apply the law, excessive fines and other administrative sanctions that can be imposed on the media, and lack of sufficient protection of journalistic sources. He recommended that the Government undertake broad public consultations on the "media law package" as a whole, as well as on ongoing constitutional reforms, to ensure that the right to freedom of expression is fully guaranteed in accordance with Hungary's international human rights obligations.

15. On 27 April 2011, the Special Rapporteur expressed deep shock and sorrow over the killing of Ahmed Kerroumi, a political activist he had met on a recent official visit to Algeria. He called on the Government of Algeria to conduct a detailed and independent investigation into his killing and to bring those responsible to justice.

16. On 2 May 2011, on the occasion of World Press Freedom Day of 3 May, the Special Rapporteur issued a press release on the right to freedom of expression on the Internet, expressing particular concern regarding journalists, bloggers and activists who have been targeted in countries such as Libya, Syrian Arab Republic and Yemen. He called on all Governments to choose reform over repression, to embrace diverging views, to listen to the people, and to build a strong society based on the consent of the governed, whose freedom of expression must be upheld.

17. On 1 June 2011, the Special Rapporteur, together with the Special Rapporteur for Freedom of Expression of the Inter-American Commission on Human Rights of the Organization of American States, the Representative on Freedom of the Media of the Organization for Security and Cooperation in Europe, and the Special Rapporteur on Freedom of Expression of the African Commission on Human and Peoples' Rights, issued a joint declaration establishing guidelines to protect freedom of expression on the Internet.

18. On 11 July 2011, the Special Rapporteur, together with the Chair-Rapporteur of the Working Group on Arbitrary Detention, expressed his dismay at the use of tear gas and water cannons by security authorities in Malaysia against peaceful protestors during the Bersih 2.0 rally on 9 July 2011, reportedly leading to injuries and one death. The mandateholders also expressed concern over the arrest of more than 1,600 people, as well as the continued detention of six leaders from the Socialist Party of Malaysia on the basis of the Emergency Ordinance, which allows for detention without trial for up to 60 days.

19. On 5 August 2011, the Special Rapporteur, together with other mandate holders, warned that the scale and gravity of the violent crackdown in the Syrian Arab Republic continues unabated, and reiterated their call for an immediate end to the violent strategies adopted by the Government to quash ongoing demonstrations. The Special Rapporteur expressed his deep concern at the Government's continued attempt to prevent the world

<sup>2</sup> Press releases issued by the Special Rapporteur are available at [http://www.ohchr.org/en/](http://www.ohchr.org/en/%0bNewsEvents/Pages/NewsSearch.aspx?NTID=PRS&MID=SR_Freedom_Expressio) [NewsEvents/Pages/NewsSearch.aspx?NTID=PRS&MID=SR\\_Freedom\\_Expressio.](http://www.ohchr.org/en/%0bNewsEvents/Pages/NewsSearch.aspx?NTID=PRS&MID=SR_Freedom_Expressio)

from knowing the extent of atrocities unfolding on the ground, by refusing access to foreign journalists.

20. On 10 October 2011, the Special Rapporteur urged the Government of Thailand to hold broad-based public consultations to amend its criminal laws on *lèse majesté* primarily section 112 of the Thai penal code and the 2007 Computer Crimes Act, which provides for imprisonment of up to fifteen years and five years respectively. He underscored that the threat of a long prison sentence and vagueness of what kinds of expression constitute defamation, insult, or threat to the monarchy encourage self-censorship and stifle important debates on matters of public interest, and that the recent spike in *lèse majesté* cases pursued by the police and the courts shows the urgency to amend them. He also expressed continuing concern at the blocking of hundreds of thousands of websites that contain commentary on the Thai monarchy.

21. On 14 October 2011, the Special Rapporteur, together with other mandate holders, warned that the current public draft of the Law on Associations and Non-Governmental Organizations in Cambodia, if adopted, risks breaching fundamental rights, including the right to freedom of opinion and expression of human rights defenders. Noting the statement by the Ambassador of Cambodia to the Human Rights Council to undertake further consultations, the mandate holders called on the Government of Cambodia to review the draft law in open and meaningful discussions with associations and NGOs.

22. On 1 November 2011, the Special Rapporteur, together with other mandate holders, voiced grave concern over reports of restrictions of fundamental rights of monks, who have been calling for religious freedom in and around the area of the Tibetan Buddhist Kirsti monastery in Sichuan province, China. Noting that the tension in the area has escalated since March 2011, he expressed deep concern about allegations of restrictions to Internet access and mobile messaging services within Aba Country, as well as lack of access to the region by journalists. The mandate holders urged the Government to fully respect and uphold the rights of minorities, cease any restrictive practices, and refrain from use of any violence or intimidation.

23. On 21 November 2011, the Special Rapporteur, together with other mandate holders, expressed alarm at the degree of violence and the deteriorating situation in Egypt ahead of parliamentary elections planned for 28 November 2011. The Special Rapporteur urged the Government to ensure that diverse views and opinions, including criticism of authorities, can be expressed peacefully by all.

24. On 24 November 2011, the Special Rapporteur, in a joint press release, warned that the new legislative amendments adopted by the National Assembly of Belarus may severely and arbitrarily restrict the rights to freedom of peaceful assembly, association, and expression. The mandate holders noted that the amendments to various laws in Belarus can worsen the climate of fear and intimidation in the country, and that such amendments may be linked to the situation of Ales Bialiatski, President of the Viasna human rights centre, and the current legal proceedings against him for alleged tax evasion.

25. On 7 December 2011, the Special Rapporteur, together with other mandate holders, warned that a new Peaceful Assembly Bill in Malaysia may arbitrarily and disproportionally restrict the right to assemble peacefully. They expressed concern at restrictions ranging from a ban on street protests and the prohibition on non-citizens and citizens under 21 years of age to assembly peacefully to conditional access for media to public gatherings.

26. On 23 December 2011, the Special Rapporteur, together with other mandate holders, denounced the continued secret detention of Gao Zhisheng, a prominent Chinese human rights lawyer who was arbitrarily arrested in 2006 in China. They expressed concern that a Beijing court had withdrawn Mr. Gao's five-year probation and ordered an additional threeyear sentence.

27. On 2 February 2012, the Special Rapporteur, together with other mandate holders, issued a press release expressing dismay at the continuing abuse of anti-terrorism legislation to curb freedom of expression in Ethiopia. The Special Rapporteur condemned the sentencing of three journalists and two opposition politicians whose sentences range from 14 years to life imprisonment.

28. On 16 February 2012, the Special Rapporteur, together with the Special Rapporteur for Freedom of Expression of the Inter-American Commission on Human Rights of the Organization of American States, issued a joint press release regarding the sentencing by the National Court of Justice of Ecuador of three executives and a journalist from *El Universo* newspaper to three years' imprisonment and a fine of USD 40 million for the publication of an article which offended President Rafael Correa.

29. On 21 February 2012, the Special Rapporteur, together with other mandate holders, condemned the arrest of at least 16 persons in Syrian Arab Republic, including prominent Syrian human rights figures, and expressed concern that their arrests and detention are directly linked to the activities of the Syrian Centre for Media and Freedom of Expression. Concern was also expressed that they may be subjected to torture and ill treatment.

30. On 24 February 2012, the Special Rapporteur, together with the Special Rapporteur on the rights to freedom of peaceful assembly and of association, urged the Senegalese authorities to take all necessary measures to ensure free, fair and transparent presidential elections that reflect the will of the Senegalese people. They also called on all parties to refrain from using violence before, during and after the elections.

31. On 28 February 2012, the Special Rapporteur, together with other mandate holders, called on the Government of Bangladesh to ensure that any policy concerning open-pit coal mining includes robust safeguards to protect human rights. In the interim, they called on the Government of Bangladesh not to allow the Phulbari coal mine to proceed, as it could displace hundreds of thousands of people and lead to the violation of fundamental human rights.

32. On 19 March 2012, the Special Rapporteur, together with 21 other mandate holders, called on States to incorporate universally agreed international human rights norms and standards with strong accountability mechanisms into the goals of the United Nations Rio+20 Conference on Sustainable Development, as the first round of informal-informal negotiations began in New York.

## **D. Participation in meetings and seminars**

33. From 1 to 3 May 2011, the Special Rapporteur participated in the global conference "World Press Freedom Day" on 21st century media, organized by UNESCO in Washington D.C.

34. On 16 and 17 May 2011, the Special Rapporteur participated in the workshop "Civil Protest and Peaceful Change: Upholding Human Rights," organized by the Geneva Academy of International Human Rights Law and Human Rights in Geneva.

35. From 30 May to 1 June 2011, the Special Rapporteur participated in the Expert Consultation Meeting on National Security and Access to Information, organized by the Open Society Institute and hosted by Central European University in Budapest.

36. On 6 and 7 July 2011 and on 12 and 13 October 2011, the Special Rapporteur participated in expert regional workshops on the prohibition of incitement to national, racial or religious hatred, organized by the Office of the High Commissioner for Human Rights (OHCHR) in the Asia-Pacific region and in the Americas, respectively.

37. From 8 to 16 July 2011, the Special Rapporteur participated in academic events on freedom of expression, organized by the Asian Forum for Human Rights and Development (FORUM-ASIA) in Bangkok, Phnom Penh, Kuala Lumpur and Jakarta.

38. On 13 and 14 September 2011, the Special Rapporteur participated in the United Nations Inter-Agency meeting on the Safety of Journalists and the Issue of Impunity, organized by UNESCO in Paris.

39. From 17 to 19 September 2011, the Special Rapporteur participated in the Pan-African Conference on Access to Information, hosted by the Working Group on the African Platform on Access to Information, UNESCO, and the African Union Commission at the International Convention Centre in Cape Town, South Africa.

40. On 23 and 24 September 2011, the Special Rapporteur participated in the International Conference on Freedom of Expression and Press Freedom in Nuremburg, Germany.

41. From 27 to 30 September 2011, the Special Rapporteur participated as a panellist in the 2011 Internet Governance Forum, held at the United Nations Office in Nairobi.

42. From 7 to 11 November 2011, the Special Rapporteur participated in the meeting "Asia Civil Society Consultation on National Security and Rights to Information Principles," organized by the Open Society Foundation, Asian Forum for Human Rights and Development (FORUM-ASIA), Yayasan Tifa, and the Institute for Defense, Security and Peace Studies in Jakarta.

43. On 23 November 2011, the Special Rapporteur participated in the expert consultation meeting, "Safety of journalists: Towards a more effective international protection framework," organized by the Austrian Federal Ministry for European and International Affairs in Vienna.

44. From 10 to 16 January 2012, the Special Rapporteur participated in a series of consultations in Thailand, and attended the Regional Symposium on Social Media, Freedom of Expression and Incitement to Hatred in Asia, organized by the Asian Forum for Human Rights and Development (FORUM-ASIA) in Singapore.

45. On 29 February 2012, the Special Rapporteur participated as a panellist in the Human Rights Council panel discussion on freedom of expression on the Internet in Geneva, Switzerland.

46. On 1 and 2 March 2012, the Special Rapporteur participated in the experts meeting on the Safety of Journalists, organized by the Special Rapporteur on extrajudicial, summary or arbitrary executions and the Centre of Governance and Human Rights at University of Cambridge, United Kingdom.

47. From 25 to 27 March 2012, and from 28 to 30 March 2012, the Special Rapporteur participated in several academic meetings in Florence and Rome, Italy, respectively.

# **III. Challenges to the protection of journalists and media freedom outside of armed conflict situations**

## **A. Overview**

48. The challenges that journalists encounter in undertaking their professional work are manifold. While the death or plight of foreign journalists in armed conflict situations frequently draw the attention of the international community, local journalists continue to face daily challenges in situations that have not reached the threshold of an armed conflict, but may be characterized by violence, lawlessness and/or repression. These range from restrictions to movement, including deportations and denial of access into a country or a particular area; arbitrary arrests and detention, particularly during public crises or demonstrations; torture and other cruel, inhuman or degrading treatment or punishment, including sexual violence against female journalists; confiscation of and damages to equipment, information theft, illegal surveillance and office break-ins; intimidation, including summons to police stations for questioning, harassment of family members, death threats, stigmatization and smear campaigns to discredit journalists; abductions or enforced disappearance to killings.

49. Since 1 January 2011, the Special Rapporteur has addressed communications relating to instances of restrictions or violence against journalists to the governments of Angola, Azerbaijan, Belarus, China, Colombia, Cuba, Ecuador, Egypt, El Salvador, Ethiopia, Georgia, Honduras, Iran (Islamic Republic of), Iraq, Kazakhstan, Libya, Madagascar, Malawi, Malaysia, Maldives, Mexico, Morocco, Pakistan, Panama, Paraguay, Russian Federation, Spain, Sri Lanka, Sudan, Syrian Arab Republic, Thailand, Tunisia, Turkey, Uganda, United Arab Emirates, Uzbekistan, Venezuela (Bolivarian Republic of), Viet Nam and Yemen.<sup>3</sup>

50. A notable trend in 2011 was the increase in the number of attacks against journalists during coverage of street protests and demonstrations, such as arbitrary arrests and detention, verbal and physical attacks, confiscation or destruction of equipment, as well as killings in countries such as Angola, Belarus, Egypt, Georgia, Iraq, Kazakhstan, Libya, Malawi, Maldives, Russian Federation, Spain, Sri Lanka, Sudan, Syrian Arab Republic, Tunisia and Yemen.<sup>4</sup>

51. Attacks against journalists may be perpetrated by a range of actors – State or non-State – such as organized crime groups, terrorist groups, security forces or militia. Journalists are placed at risk of attack for documenting and disseminating information deemed to be "inconvenient," including on human rights violations, environmental issues, corruption, organized crime, drug trafficking, public crises, emergencies or public demonstrations.

52. Female journalists also face additional risks, such as sexual assault, mob-related sexual violence aimed against journalists covering public events, or sexual abuse in detention or captivity. Many of these attacks are not reported as a result of powerful cultural and professional stigmas.<sup>5</sup> A gender-sensitive approach is therefore needed when considering measures to address the issue of violence against journalists.

<sup>3</sup> See A/HRC/18/51, A/HRC/19/14, A/HRC/20/30.

<sup>4</sup> Ibid.

<sup>5</sup> Lauren Wolfe, "The silencing crime: Sexual violence against journalists," Special report, Committee to Protect Journalists (CPJ), 7 June 2011. Available at [http://cpj.org/reports/2011/06/silencing-crime](http://cpj.org/reports/2011/06/silencing-crime-sexual-violence-journalists.php)[sexual-violence-journalists.php.](http://cpj.org/reports/2011/06/silencing-crime-sexual-violence-journalists.php)

53. Another threat to the freedom of journalists and to press freedom is the increasing use of criminal law on defamation, slander or libel by public officials to silence criticism regarding their personal activities or public policies. The mere use of such "judicial harassment" generates a climate of fear and a "chilling effect" which encourages selfcensorship. This issue is further explored under section D below on criminalization of expression.

54. An attack against a journalist is not only a violation of his or her right to impart information, but also undermines the right of individuals and society at large to seek and receive information, both of which are guaranteed under articles 19 of the Universal Declaration of Human Rights and the International Covenant on Civil and Political Rights respectively. Indeed, without respect for freedom of expression, and in particular freedom of the press, an informed, active and engaged citizenry is impossible. An attack against a journalist is therefore an attack against the principles of transparency and accountability, as well as the right to hold opinions and to participate in public debates, which are essential for democracy.

55. In addition to articles 19 of the Declaration and of the Covenant, which protect the right of journalists to seek, receive and impart information and ideas of any kind through any medium of communication, journalists are also protected under other provisions in international human rights law, including the right to life, freedom from torture and arbitrary arrests and detention, and the right to an effective remedy.

56. Despite the existence of provisions in international human rights law which protect their right to seek, receive and impart information and ideas of all kinds, journalists across the world continue to face risks and challenges in carrying out their work. The Special Rapporteur reiterates that the problem with regard to continued and increasing violence against journalists is not a lack of legal standards, but the lack of implementation of existing norms and standards (A/65/284, para. 83). It is therefore essential that these existing norms and standards be implemented at the national level. The Special Rapporteur wishes to emphasize again that although the origin of the acts of violence may not initially be known, the primary responsibility of protecting journalists, fully investigating each case and prosecuting those responsible lies with Governments and State institutions (A/HRC/4/27).

57. As well as having an obligation to prevent human rights violations against journalists, such as killings, ill-treatment or unlawful arrest, States also have a responsibility to ensure that their national legal systems do not permit impunity in cases when such violations take place. The issue of impunity is further discussed below.

58. The Special Rapporteur would like to underscore that given that the causes of violence, as well as of impunity, vary in each context, strategies or protection mechanisms established to protect journalists must be tailored to local needs with context-specific consideration of the differing needs of journalists.

59. States are also responsible for ensuring that legal measures, such as anti-terrorism or national security laws, are not used to limit freedom of expression by leading to the arrest and detention, or to fear of arrest and detention, among journalists. The issue of criminalization of freedom of expression, which has a direct impact on the ability of journalists to carry out their work, is further examined below.

60. For their part, journalists and media organizations also have a responsibility to take precautionary safety measures to ensure their own protection. Additionally, by voluntarily adhering to global standards of professionalism, journalists can also enhance their credibility in the eyes of society and their legitimate protection concerns. Such standards of journalistic professionalism include those that have been developed and adopted by journalists and media workers themselves, such as the Declaration of Principles on the Conduct of Journalists of the International Federation of Journalists, which proclaims that "respect for truth and the right of the public to truth is the first duty of the journalist." 6

## **B. Safety and protection of online journalists**

61. Most of the offline media have developed an online alternative, and given that the Internet has become an essential and economic medium for disseminating news to a global audience, leading to an emergence of "online journalists" – both professionals and so-called "citizen journalists" who are untrained, but who play an increasingly important role by documenting and disseminating news as they unfold on the ground. Such an expansion of individuals involved in spreading information has enriched the media landscape by increasing access to sources of information, stimulating informed analysis and promoting the expression of diverse opinions, particularly in moments of crises.

62. The Special Rapporteur has already examined issues related to the right to freedom of expression on the Internet (A/HRC/17/27) and citizen journalists (A/65/284), but remains concerned about the increasing risks against individuals who disseminate information via the Internet. The killing of Mexican reporter, Maria Elizabeth Marcias Castro, whose decapitated body was found near the city of Nuevo Laredo, along with a note saying she had been killed for reporting news on social media websites, is a case in point.

63. Additionally, the Special Rapporteur is deeply concerned by harassment of online journalists and bloggers, such as illegal hacking into their accounts, monitoring of their online activities, arbitrary arrests and detention, and the blocking of websites that contain information that are critical of authorities. Such actions constitute intimidation and censorship.

64. The Special Rapporteur reiterates that the right to freedom of expression should be fully guaranteed online, as with offline content. If there is any limitation to the enjoyment of this right exercised through the Internet, it must also conform to the criteria listed in article 19, paragraph 3, of the International Covenant on Civil and Political Rights. This means that any restriction imposed as an exceptional measure must (i) be provided by law, which is clear and accessible to everyone; (ii) pursue one of the legitimate purposes set out in article 19, paragraph 3, of the Covenant; and (iii) be proven as necessary and the least restrictive means required to achieve the purported aim.

#### **C. Impunity and prevention of attacks against journalists**

65. One of the biggest challenges to ensuring the protection of journalists is impunity or the failure to bring to justice the perpetrators of human rights violations. In this regard, the Special Rapporteur has on many occasions stressed that impunity for those who attack and/or kill journalists is a central obstacle to guaranteeing the protection of journalists and press freedom, as it emboldens perpetrators as well as would-be perpetrators to attack journalists with no legal consequences. Indeed, impunity is one, if not the main cause of the unacceptably high number of journalists who are attacked or killed every year. States must recognize that in cases of violence against journalists, impunity generates more violence in a vicious cycle.

66. According to the Committee to Protect Journalists (CPJ), in nine out of 10 cases in which journalists are murdered, the perpetrators go free. As at 20 March 2012, 565

<sup>6</sup> See http://www.ifj.org/en/articles/ifj-declaration-of-principles-on-the-conduct-of-journalists.

journalists have been murdered with impunity since 1992. <sup>7</sup> The root causes of impunity may vary from context to context, but can mainly be attributed to lack of political will to pursue investigations, including for fear of reprisal at the hands of powerful criminal networks, inadequate legal framework and a weak judicial system, ineffectiveness of police forces and judicial bodies and lack of expertise, lack of resources allocated to law enforcement and the justice system, as well as negligence and corruption. Against these obstacles, many journalists choose not to report threats or incidents of physical attack, further fuelling the cycle of impunity.

67. The Special Rapporteur welcomes the efforts by various organizations to combat impunity, as well as the declaration by the International Freedom of Expression Exchange (IFEX) network in 2011 of 23 November as the International Day to End Impunity. This date has been chosen by the network to mark the second anniversary of the Maguindanao massacre in the Philippines, during which over 30 journalists were killed. As mentioned in Chapter II, the Special Rapporteur attended the Inter-Agency meeting on the Safety of Journalists and the Issue of Impunity, and welcomes efforts to adopt a United Nations joint Plan of Action on the Protection of Journalists and the Issue of Impunity, which is being coordinated by UNESCO. He hopes that such a joint plan of action will strengthen the protection of journalists on the ground through the presence of various United Nations agencies, funds and programmes in the field. He calls on all States to support the plan.

#### **Initiatives to combat impunity**

68. In the case of Guatemala, the International Commission against Impunity in Guatemala (CICIG), which began operations in September 2007, has an unprecedented mandate among United Nations and other international efforts to promote accountability and strengthen the rule of law. The Commission aims to investigate and dismantle violent criminal organizations in Guatemala, which are believed to be among the cornerstones of impunity in the country, threatening the justice system and democratic institutions. The Commission carries out independent investigations in accordance with international human rights standards under Guatemalan law and following Guatemalan procedure. It fortifies Guatemala's public policy framework and justice sector institutions, making proposals for legal reforms, providing technical assistance to justice sector institutions, and working closely with the Attorney General's Office on the prosecution of symbolic cases. Although the CICIG is not specifically directed towards journalists, it draws attention to issues at the heart of the problem of impunity.

69. With regard to initiatives that address journalists in particular, efforts made to provide protection to journalists in Colombia have been welcomed, primarily as it recognizes that it is an important issue within the country and that measures must be taken to address the phenomenon. The Protection Programme for Journalists and Social Communicators, together with the Programme for the Protection of Human Rights Defenders, was created by the Government of Colombia in 2000, with the approval of Decree No.1592. The aim of the programme is to protect journalists and media workers in situations of risk or threat because of their work. Civil society organizations have contributed to the programme by presenting, investigating and following up on threats against journalists; and the Risk Evaluation and Regulation Committee (CRER) an interinstitutional committee determines and implements the necessary protection measures in each case.

70. Various protection programmes in Colombia, including the programme for the protection of journalists, were subsequently merged into one programme, which was

<sup>7</sup> See CPJ, Global Campaign Against Impuntiy, at [http://www.cpj.org/campaigns/impunity/.](http://www.cpj.org/campaigns/impunity/)

formally institutionalized under the Ministry of Interior following the adoption of Decree No. 4912 in December 2011. Such a programme was necessitated by the high number of assassinations of journalists during the previous administration, in which eight journalists were killed in the first year, and six killed in the last six years. However, the situation in Colombia is still not an optimal one for journalists; in fact, Colombia has dropped in its ranking on the Press Freedom Index of Reporters Without Borders, from 114th out of 179 countries in 2002 to 143rd in 2011-2012.

71. OHCHR Colombia has welcomed the protection programme of the Ministry of Interior and Justice, but has also highlighted concerns, including the delays in assessing risks and implementing protection measures, the absence of a contextual approach and the transfer of protection schemes to private companies. OHCHR Colombia continues to provide assistance and advice to help to create more homogeneity and coordination between the different protection mechanisms. Despite these shortcomings, the Special Rapporteur welcomes the positive steps taken to combine different protection programmes based on coordination between State institutions, journalists and civil society organizations, and considers it an important step forward in preventing the assassination of journalists.

72. The establishment in Colombia of the National Unit for the Protection of Journalists and other vulnerable sectors is also a good practice worth mentioning. However, this mechanism only addresses so-called "material measures of protection," such as mobile phones, bulletproof vehicles, emergency evacuations and transfers to other regions of the country or abroad, such as those granted under witness protection programmes. The Special Rapporteur considers it important to mention that the protection of journalists requires a holistic approach that includes material, legal, and political measures of protection, in particular public condemnation of attacks against journalists and support for press freedom by high-level State officials.

73. In Mexico, reacting to the seriousness of the situation of journalists in the country, the Federal State established the Special Prosecutor's Office for Crimes against Freedom of Expression (FEADLE) within the Office of the Attorney General of the Republic (PGR).

74. However, during the Special Rapporteur's mission to Mexico in 2010, reservations were expressed regarding the paucity of results achieved by the FEADLE and its tendency to decline competency over certain cases referred to its jurisdiction, due in part to the lack of will on the part of officials to take up cases and implement an adequate work programme, but also due to lack of autonomy and resources, and the fact that acts of violence against journalists are not prohibited under federal law. Although the Special Rapporteur welcomed the work plan which the FEADLE was implementing at the time of his mission to Mexico (A/HRC/17/27/Add.3), he emphasized the importance of immediately creating a national mechanism to protect journalists, designed and implemented through a high-level official and inter-institutional committee, led by a federal authority with the capacity to coordinate between diverse authorities, having its own sufficient resources, and with the participation of journalists and civil society organizations in its design, integration, functioning and evaluation. The Special Rapporteur underlines the importance of such institutions having sufficient autonomy and resources, as well as investigatory powers and the competency to make recommendations to the Government.

75. The Special Rapporteur also recommended that the Congress in Mexico criminalize acts of violence against journalists and give federal courts the competency to prosecute such matters. He has been informed that Congress has passed such a law, which is currently being considered for adoption by the authorities of each state in Mexico.

76. Although the above examples of challenges and good practices relating to the protection of journalists in situations of widespread violence or impunity have been drawn from Latin America, this is not the only region in which these issues are a concern. The Special Rapporteur has sent communications to several countries regarding issues such as impunity, journalists reporting on violence and organized crime, as outlined in chapters II and III above.

77. Combating impunity and ensuring the protection of journalists requires strengthening respect for the rule of law and ensuring that the domestic legal framework and institutions promote the right to freedom of expression and support the establishment of free, independent and pluralistic media. The Special Rapporteur notes with concern the continuing existence and application of domestic legislation which criminalize expression.

## **D. Criminalization of expression**

78. Ensuring that journalists can effectively carry out their work means not only preventing attacks against journalists and prosecuting those responsible, but also creating an environment where independent, free and pluralistic media can flourish and journalists are not placed at risk of imprisonment. The Special Rapporteur expresses his deep concern that the current total number of journalists imprisoned worldwide is reportedly the highest since 1996, with 179 journalists behind bars as at 1 December 2011.<sup>8</sup> Reportedly, the work of 86 imprisoned journalists – half of the total imprisoned – has primarily appeared online. In addition, journalists may be victims of short-term detentions, which can also heighten the climate of intimidation. Such detentions are often difficult to document statistically.

79. Indeed, the Special Rapporteur remains concerned at the continuing existence and use of criminal laws against journalists and members of the media, which are often used by authorities to suppress "inconvenient" information and to prevent journalists from reporting on similar matters in the future. Consequently, there is a chilling effect which stifles reporting on issues of public interest. Charges such as treason, subversion and acting against national interests continue to be brought against journalists worldwide, as well as allegations of terrorism and criminal defamation for reporting false news or engaging in ethnic or religious insult.

80. As stressed previously, including in the report to the General Assembly (A/66/290), there are four types of expression or information which States are required to prohibit under international law: child pornography; incitement to genocide; advocacy of national, racial or religious hatred that constitutes incitement to discrimination, hostility or violence and incitement to terrorism. Other types of information or expression, which States are not required to prohibit, but may be restricted in exceptional and limited circumstances primarily to protect the rights of others, are established under article 19, paragraph 3, of the International Covenant on Civil and Political Rights. However, while protecting individuals from false and malicious accusations, protecting national security or countering terrorism are legitimate interests, the Special Rapporteur remains concerned that such pretexts are used by authorities to unduly control and censor the media and to evade transparency or to silence criticism of public policies.

81. The Special Rapporteur reiterates that any restriction to the right to freedom of expression must satisfy the three-part test stipulated in article 19, paragraph 3, of the Covenant: (i) the restriction imposed must be provided by law, which is clear and accessible to everyone; (ii) it must be proven as necessary and legitimate to protect the rights or reputation of others; national security or public order, public health or morals; and

<sup>8</sup> See CPJ special report, "Imprisonments jump worldwide, and Iran is worst," available at [http://www.cpj.org/reports/2011/12/journalist-imprisonments-jump-worldwide-and-iran-i.php.](http://www.cpj.org/reports/2011/12/journalist-imprisonments-jump-worldwide-and-iran-i.php)

(iii) it must be proven as the least restrictive and proportionate means to achieve the purported aim.

82. Moreover, any legislation restricting the right to freedom of expression must be applied by a body which is independent of any political, commercial, or other unwarranted influences in a manner that is neither arbitrary nor discriminatory, and with adequate safeguards against abuse, including the possibility of challenge and remedy against its abusive application.

#### **1. Defamation**

83. Defamation laws protect an individual's reputation from false and malicious attacks, and constitute valid grounds for restricting freedom of expression. Nearly all countries have some form of defamation legislation, although different terms are used, such as libel, calumny, slander, insult, *desacato*, or *lèse majesté*. However, the problem with defamation cases is that they frequently mask the determination of political and economic powers to retaliate against criticisms or allegations of mismanagement or corruption, and to exert undue pressure on the media.

84. In particular, the Special Rapporteur remains concerned that defamation remains classified as a criminal offence rather than a civil tort in many countries around the world. As he has emphasized on many occasions, criminal defamation laws are inherently harsh and have a disproportionate chilling effect on free expression. Individuals face the constant threat of being arrested, held in pretrial detention, subjected to expensive criminal trials, fines and imprisonment, as well as the social stigma associated with having a criminal record.

85. Even in countries where defamation is classified as a civil tort, the financial sanctions imposed may be high and disproportionate, which can bankrupt small and independent media and have adverse consequences on media freedom in a country.

86. Many journalists continue to inform the Special Rapporteur that the systematic use of unjustified criminal prosecution or even civil tort prosecution with disproportionate financial sanctions paralyzes journalistic investigation and generates an atmosphere of intimidation, which constitutes a form of judicial harassment.

87. The Special Rapporteur thus calls on all States to repeal criminal defamation provisions allowing prosecution of authors of media content, as well as to limit civil law penalties for defamation so that it is proportionate to the harm done. He emphasizes that criminal prosecution for defamation inevitably becomes a mechanism of political censorship, which contradicts freedom of expression and of the press.

88. Moreover, the Special Rapporteur underscores that public officials, including heads of State and public figures, must tolerate a higher degree of scrutiny than ordinary individuals because of their public functions, and should not be granted a higher level of protection against defamatory statements in media.

#### **2. National security and counter-terrorism legislation**

89. The Special Rapporteur remains concerned that laws purported to protect national security or to counter terrorism continue to be used against journalists who report on sensitive or critical matters of public interest, or to force journalists to reveal their sources of information.

90. The Special Rapporteur emphasizes the importance of journalists' right to access information, which is part of the right to seek and receive information under articles 19 of the Universal Declaration on Human Rights and the International Covenant on Civil and political Rights, respectively. He would like to stress that Governments should classify only those data which are proven to harm national security and other vital interests of the State. Moreover, there should be clear classification criteria and register of classified information, which is both established by law and accessible to everyone. Further, classified data should be subject to regular review and declassified if confidentiality is no longer necessary.

91. The Special Rapporteur also remains concerned at journalists being held accountable for receiving, storing and disseminating classified data which was obtained in a way that is not illegal, including leaks and information received from unidentified sources. In this regard, he emphasizes that journalists should not be held responsible for, or be forced to reveal, their sources of information. The Special Rapporteur further stresses that it is also important for States to facilitate access to historical archives of official information to enable victims of human rights violations to exercise their right to truth, as well as journalists and academics for investigative purposes.

## **IV. Conclusions and recommendations**

## **A. Conclusions**

92. **Despite provisions in international human rights law, including the Universal Declaration on Human Rights and the International Covenant on Civil and Political Rights, which guarantee the rights of journalists, journalists continue to be targeted for disseminating "inconvenient" information. The problem lies not in the lack of international standards, but in the inability or unwillingness of Governments to ensure the protection of journalists.** 

93. **While armed conflict situations may place journalists at risk, the Special Rapporteur notes that the majority of attacks against journalists take place outside of armed conflict situations. Individuals who cover public demonstrations, report on issues such as corruption, human rights violations, environmental issues, organized crime, drug trafficking, public crises or emergencies are placed at particular risk of violence. Nevertheless, the Special Rapporteur also reiterates the importance of the following concerns.**

94. **Central challenges in relation to human rights violations committed against journalists include various forms of intimidation, physical attacks – including abductions and killings –, arbitrary detention, as well as impunity and the use of criminal laws to imprison and intimidate journalists. Female journalists face additional risks, such as sexual assault, mob-related sexual violence at public events or sexual abuse in detention or captivity. Due to social, cultural and professional stigmas, many of these attacks are not reported.** 

95. **The presence of such risks deters journalists from continuing their work, or encourages self-censorship on sensitive matters. Consequently, society as a whole may not be able to access important information.** 

96. **The emergence of "online journalists" – both professionals and untrained socalled "citizen journalists" – play an increasingly important role in documenting and disseminating news in real time as they unfold on the ground. Journalists who publish their work online should be afforded the same protection under articles 19 of the Universal Declaration on Human Rights and of the International Covenant on Civil and Political Rights. Any restriction applied to online content must also be in conformity with the three-part test set out in article 19, paragraph 3, of the Covenant.** 

97. **Laws that criminalize expression continue to be used by States to imprison journalists who disseminate "inconvenient" information. Journalists may be arrested** **and detained, particularly in the run-up to elections, often on the basis of vague antiterrorist or national security laws. The Special Rapporteur is deeply concerned that the current number of journalists in prison is the highest since 1996. Criminal prosecution of journalists creates a "chilling effect" that stifles reporting on issues of public interest.** 

98. **The precarious situation of journalists is further exacerbated by a culture of impunity. Failure to undertake effective investigations and to prosecute those responsible for attacks against journalists perpetrates further violence and undermines the ability of journalists to report on similar matters in the future.** 

99. **The protection of journalists and combating impunity requires context-specific measures that address the specific risks in each situation and effectively addresses the root causes of attacks. While there are many organizations committed to ensuring the protection of journalists at all levels, there has not been much collaboration and joint strategies adopted at the international level. The Special Rapporteur thus welcomes the initiative to draft a United Nations joint Plan of Action on the Protection of Journalists and the Issue of Impunity and looks forward to its effective implementation.** 

### **B. Recommendations**

#### **1. States**

100. **Bearing in mind that standards exist in international human rights law for the protection of professional journalists outside of armed conflict situations, the Special Rapporteur urges States, with whom the primary responsibility for the protection of journalists lies, to implement those standards at the national level. This includes ensuring that no legislation is passed to unduly limit the freedom of expression of journalists, ensuring the physical and psychological integrity of journalists, and taking steps to tackle impunity for perpetrators of human rights violations against journalists.** 

101. **To combat impunity and to prevent human rights violations against journalists, States must take measures to facilitate awareness among the judiciary, journalists and civil society of the relevant international standards and show willingness to work towards the implementation of these standards.** 

102. **Necessary resources must be dedicated to preventing and investigating attacks, or bringing those responsible to justice. Special measures should be put in place to deal with attacks and to support journalists who are displaced by attacks.**

103. **The Special Rapporteur also calls on all States to publicly condemn all forms and incidents of attacks against journalists at the highest political level.** 

104. **As part of their positive obligation to promote the right to freedom of expression, States should give full political support to strengthening media freedom and ensuring that independent, plural and diverse media can flourish. Any laws regulating the work of the media should adhere to the highest international standards on freedom of opinion and expression and allow uninhibited debate in the media, in line with principles of diversity and plurality.** 

105. **Defamation should be decriminalized in all States. Criminal defamation laws are inherently harsh and have a disproportionate chilling effect on the right to freedom of expression.** 

106. **In countries where defamation is classified as a civil tort, the financial sanctions imposed must be strictly proportionate to the harm caused and limited by law.** 

107. **Journalists should not be held accountable for receiving, storing and disseminating classified data which they have obtained in a way that is not illegal, including leaks and information received from unidentified sources.** 

108. **Governments should only classify those data which are proven to cause direct harm to national security and other vital interests of the State. Classified data should be subject to regular review and be declassified if confidentiality is no longer necessary. Clear classification criteria and a register of classified information should be established by law and published.** 

109. **Journalists working both offline and online should be free to use diverse sources of information, including from those who do not wish to be identified. Journalists should never be forced to reveal their sources except for certain exceptional cases where the interests of investigating a serious crime or protecting the life of other individuals prevail over the possible risk to the source. Such pressing needs must be clearly demonstrated and ordered by an independent court.** 

110. **The Special Rapporteur recognizes efforts in countries, such as Colombia and Mexico, to create bodies to offer, inter alia, greater protection to journalists. The Special Rapporteur underlines the importance of the willingness and ability of such bodies to take on a broad range and high number of cases and issues under its competency; to work with autonomy; to have their own and sufficient resources and to have the capacity to coordinate between different authorities. Furthermore, the Special Rapporteur recommends that journalists and civil society organizations participate in the design, integration, functioning and evaluation of these bodies; that they have investigatory powers; that they have the competency to make recommendations to the Governments of their respective countries; that riskassessment is prompt and efficient; that measures are implemented promptly; and that a contextual approach is adopted. Protection measures must be holistic, including a range of physical, legal, and political measures.** 

#### **2. Civil society**

111. **The Special Rapporteur recommends that civil society organizations work to raise awareness of the risks faced by journalists, the international standards which exist to protect them, and how these might be implemented through campaigns and training initiatives; that civil society organizations, including journalists, make efforts to ensure that global standards of professional conduct are met in order to enhance the credibility and protection of journalists; and that they coordinate with one another and with the United Nations in order to ensure that their work is complementary.** 

112. **Civil society associations, including journalists, should engage actively with Government initiatives to establish protection mechanisms.** 

#### **3. United Nations**

113. **The Special Rapporteur welcomes United Nations initiatives, such as the innovative International Commission against Impunity in Guatemala (CICIG). He supports the idea of considering the implementation of similar initiatives in other countries where impunity for human rights violations is prevalent.** 

114. **United Nations field presences should support States in implementing measures for the protection of journalists, as in the case of OHCHR in Colombia which offers support for the protection mechanisms in Colombia.**

115. **The Special Rapporteur encourages coordination between United Nations agencies and initiatives, such as the United Nations joint Plan of Action on the Protection of Journalists and the Issue of Impunity. Greater coordination between United Nations agencies, in terms of funding and programmes, may result in more efficient use of resources and less duplication of work. The Special Rapporteur welcomes the fact that civil society was consulted as part of the initiative and encourages strengthened links between United Nations agencies and civil society in the protection of journalists.**

116. **In keeping with the United Nations Action 2 programme, the Special Rapporteur encourages other United Nations agencies to support the protection of journalists by ensuring that United Nations actions at the country level are grounded in human rights principles and guided by international norms and standards. Training and toolkits, such as those provided by the United Nations Development Programme (UNDP) in relation to journalists working on HIV/AIDS and corruption, for example, could be tailored to the protection of journalists.** 

#### **4. Regional actors**

117. **The Special Rapporteur welcomes the support for freedom of expression and the protection of journalists in different regional mechanisms, as well as measures taken, such as the establishment of Special Rapporteurs. In cases where regional actors have not yet set standards for the protection of journalists, the Special Rapporteur encourages them to do so in consonance with those already existing at the international level.**
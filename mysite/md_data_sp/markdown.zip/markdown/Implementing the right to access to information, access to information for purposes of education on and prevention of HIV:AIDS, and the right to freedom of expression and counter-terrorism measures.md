![](_page_0_Picture_2.jpeg)

# **Economic and Social Council**

Distr. GENERAL

E/CN.4/2004/62 12 December 2003

Original: ENGLISH

COMMISSION ON HUMAN RIGHTS Sixtieth session Item 11 (c) of the provisional agenda

#### **CIVIL AND POLITICAL RIGHTS, INCLUDING THE QUESTION OF FREEDOM OF EXPRESSION**

**The right to freedom of opinion and expression** 

**Report of the Special Rapporteur, Ambeyi Ligabo, submitted in accordance with Commission resolution 2003/42** 

GE.03-17169 (E) 200104

#### **Summary**

 This report is the eleventh report submitted by the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression to the Commission on Human Rights and the second report of Ambeyi Ligabo, appointed as Special Rapporteur on 26 August 2002. This report is submitted pursuant to Commission resolution 2002/48, in which the Commission decided to renew the mandate of the Special Rapporteur for a further three years.

 In section I, the report defines the terms of reference and methods of work of the Special Rapporteur. Section II describes the activities of the Special Rapporteur during the past year. Section III contains a discussion of issues relevant to the mandate, including the right to access to information, the right to access to information for the purposes of education on, and prevention of, HIV/AIDS, and the right to freedom of opinion and expression in the context of counter-terrorism measures. Section IV contains the conclusions and recommendations of the Special Rapporteur.

 The Special Rapporteur remarked that, on the one hand, positive measures were being taken in certain countries in favour of a greater protection of the right to freedom of opinion and expression; on the other hand, numerous negative trends and violations patterns remain substantially active and unchanged. In particular, the Special Rapporteur expressed his preoccupation for the ongoing attacks against journalists and media workers. He also reiterated the necessity for an in-depth study on the security of journalists in conflict zones.

 The Special Rapporteur noted that, owing to the technological development, the number of journalists and reporters working in war zones had increased, and that, consequently, journalists were more exposed to serious dangers. The Special Rapporteur underlined that media should give a fair depiction of conflicts, avoiding discriminatory statements on war victims, especially children and women, and war prisoners.

 The Special Rapporteur expressed his concern about the concentration of large media groups in the hands of few economic corporations. The Special Rapporteur encouraged Governments to ensure a pluralistic approach to the exercise of the freedom of opinion and expression, accessible to all actors of the civil society.

 The Special Rapporteur reiterated that violations of the right to freedom of opinion and expression may occur in all regions and countries, whatever their system. Yet, it contributes to the emergence and existence of effective democratic systems. All Governments may consider the possibility of seeking technical assistance from the Office of the United Nations High Commissioner for Human Rights in order to eliminate the causes of human rights violations.

 The Special Rapporteur believed that further consideration should be given to the monitoring of national legislation and court decisions, as an essential element for a better implementation of the right to information.

 The Special Rapporteur supported the work being done by various institutions to increase financial transparency and accountability, and its link with sustainable development.

 A summary of communications sent to and received from Governments is contained in addendum 1 to the present report. The report on the Special Rapporteur's mission to the Islamic Republic of Iran is contained in addendum 2.

#### **CONTENTS**

| | | | Paragraphs | Page |
|--------------|----------------------------------------|----------------------------------------------------------------------------------------|------------|------|
| Introduction | | | 1 - 2 | 5 |
| I. | TERMS OF REFERENCE AND METHODS OF WORK | | 3 - 6 | 5 |
| II. | ACTIVITIES | | 7 - 33 | 6 |
| | A. | Communications | 7 - 12 | 6 |
| | B. | Press releases | 13 - 17 | 6 |
| | C. | Requests for information | 18 | 7 |
| | D. | Country visits | 19 - 22 | 7 |
| | E. | Participation in seminars and conferences | 23 - 33 | 8 |
| III. | ISSUES | | 34 - 78 | 10 |
| | A. | Implementing the right to access to information | 34 - 64 | 10 |
| | B. | Access to information for the purposes of education<br>on, and prevention of, HIV/AIDS | 65 - 68 | 16 |
| | C. | The right to freedom of opinion and expression and<br>counter-terrorism measures | 69 - 78 | 17 |
| IV. | CONCLUSIONS AND RECOMMENDATIONS | | 79 - 90 | 19 |

#### **Introduction**

1. The present report, submitted pursuant to Commission on Human Rights resolution 2002/48, is the second general report by Mr. Ambeyi Ligabo (Kenya), appointed Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression on 26 August 2002. The Commission established the mandate of the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression in its resolution 1993/45.

2. Issues addressed in this report include an updating of the matters analysed in the Special Rapporteur's previous report (E/CN.4/2003/67), namely access to information with regard to the prevention of HIV/AIDS; the safeguard of human rights, and in particular the right to freedom of opinion and expression while adopting and implementing counter-terrorism measures; a large part of this report is devoted to the phenomenon of access to information as a whole.

## **I. TERMS OF REFERENCE AND METHODS OF WORK**

3. At the beginning of his mandate, the Special Rapporteur decided to endorse the terms of reference and methods of work of his predecessor, Abid Hussein. The Special Rapporteur reiterated that country visits are one of the essential elements of his mandate, enabling him to examine in situ the realization of the right to freedom of opinion and expression. He therefore calls upon Governments to cooperate with him in that regard.

4. The Special Rapporteur considers that exchange of communications with Governments on individual cases of alleged violations of the right to freedom of opinion and expression is also an important part of his mandate, and he thanks those Governments which cooperate with him in this respect, and wishes to call on other Governments to engage in a transparent and constructive dialogue with him.

5. The Special Rapporteur also emphasized that one of the main characteristics of his mandate would be the development of close cooperation with Governments, non-governmental organizations (NGOs) and all other relevant organizations and institutions, in order to seek and receive credible and reliable information which, in his view, is essential for the discharge of his mandate.

6. The Special Rapporteur wished to reiterate that, in carrying out his mandate, he intends to cooperate closely with other geographic and thematic special procedures mandate-holders, the treaty bodies and human rights field operations of the Office of the United Nations High Commissioner for Human Rights (OHCHR). He also intends to continue and develop the collaboration with the Organization for Security and Cooperation in Europe (OSCE) Representative on freedom of the media and the Organization of American States (OAS) Special Rapporteur on freedom of expression, as well as with the Programme for Freedom of Expression, Democracy and Peace of the United Nations Educational, Scientific and Cultural Organization (UNESCO).

## **II. ACTIVITIES**

#### **A. Communications**

7. One of the most significant features of the Special Rapporteur's mandate is the analysis of the communications received in order to identify trends, to reiterate issues already discussed in previous reports and to bring to the attention of the international community a number of policies, practices, incidents and measures having an impact on respect for the right to freedom of opinion and expression.

8. Customarily, the Special Rapporteur considered communications brought to his attention from a variety of sources - Governments, international, regional, national and local NGOs; associations of media professionals, trade unions, members of political parties - and from all regions of the world. The Special Rapporteur emphasizes that a plurality of sources of information is essential to the discharge of his mandate.

9. The Special Rapporteur notes that a large number of allegations continue to refer to the following situations: electoral processes; civil unrest; situations where the legal and institutional protections and guarantees of human rights exist but are not properly implemented; states of emergency in general; internal armed conflict. The Special Rapporteur also notes that the communications received are not confined to alleged violations in countries where the political, social and economic situation is particularly difficult, but also to alleged violations occurring in emerging or long-established democracies.

10. The nature of the alleged violations can enormously vary, depending on the level of respect for the rule of law and good governance in a society. The range of violations goes from killings, arbitrary arrest and detention, enforced disappearances, threats and harassment, criminal charges and sentencing to prison terms for libel or defamation, to various types of judicial and administrative measures.

11. However, analysing the increasing number of communications sent to the Special Rapporteur, it was clear that the right to freedom of opinion and expression was far from being sufficiently and adequately protected in all regions of the world. While the nature and the seriousness of the violations may significantly vary, even well-established protection systems may be at risk facing sudden crises. In addition, continuing violations to freedom of opinion and expression seems to be a common feature of certain political systems.

12. The Special Rapporteur wished to thank all those Governments that, in a spirit of collaboration and mutual understanding, answered his appeals and letters, thus exercising their right to reply. The correspondence is contained in document E/CN.4/2004/62/Add.1.

#### **B. Press releases**

13. On 16 October 2003, the Special Rapporteur signed a press release, together with four other Special Rapporteurs of the Commission on Human Rights, expressing their concern over the prevailing situation in Bolivia. In particular, they condemned violence during several

protests in various parts of the country and urged the Government to take necessary measures to ensure the full protection of the human rights of the demonstrators, including the right to assemble and protest, in the light of the international norms endorsed by Bolivia.

14. On 17 October 2003, the Special Rapporteur and the Special Representative of the Secretary-General on Human Rights Defenders, Mrs. Hina Jilani, expressed their deep concern over the conviction, on 16 October, of Irene Fernandez, director of "Tenaganita" - a women's non-governmental organization based in Kuala Lumpur - who was sentenced to 12 months' imprisonment by a Magistrates Court, in Kuala Lumpur, Malaysia.

15. On 28 October 2003, the Special Rapporteur and three other experts of the Commission on Human Rights expressed their concern over the post-election situation in Azerbaijan, in particular over the reported use of attacks against, and arrests of demonstrators, in particular opposition leaders and journalists, by security forces and of harassment of some election observers and polling station officials.

16. On 12 November 2003, the Special Rapporteur and two other experts of the Commission on Human Rights issued a press release on the situation in Nepal in the wake of the collapse of the ceasefire between the Government and the Communist Party of Nepal (CPN) (Maoist). They expressed particular concern at reports that dozens of individuals have been arrested and are detained secretly, allegedly on suspicion of supporting or being involved with the CPN (Maoist).

17. On the occasion of Human Rights Day on 10 December 2003, the Special Rapporteur joined many other experts of the Commission on Human Rights in a statement condemning all acts of intimidation and reprisal against individuals and groups who seek to cooperate, or have cooperated with the United Nations or representatives of its human rights bodies, and urging States to refrain from violating the rights of witnesses, in particular their rights to life, to be free from torture, to personal freedom and security, and to freedom of expression and to impart information and ideas. In their statement, the experts also called on States to protect witnesses from threats, intimidation and reprisals from private individuals or groups.

## **C. Requests for information**

18. On 22 July 2003, the Special Rapporteur sent a note verbale to all Member States drawing their attention to paragraph 17 of Commission on Human Rights resolution 2003/42 of 23 April 2003 entitled "The right to freedom of opinion and expression". In that paragraph, the Commission invites the Special Rapporteur "to consider approaches taken to access to information with a view to sharing best practices" and "to continue to seek the views and comments of the Government and others concerned in the elaboration of his report".

## **D. Country visits**

19. From 2 to 7 December 2002, the Special Rapporteur undertook a mission to Equatorial Guinea (E/CN.4/2003/67/Add.2). As a follow-up of his visit, the Government of Equatorial Guinea sent a letter inviting the Special Rapporteur to visit again the country in

late 2003, especially in order to verify the progress made regarding the technical assistance provided through OHCHR. While recognizing the efforts of the Government, in his letter dated 26 September 2003, the Special Rapporteur said that he considered a follow-up visit premature at that stage.

20. On 23 October 2002, the Government of the Islamic Republic of Iran invited the Special Rapporteur to visit the country. The mission was originally scheduled from 17 to 27 July 2003, but finally postponed at the request of the Government. Eventually, the Special Rapporteur had the opportunity of visiting the Islamic Republic of Iran from 3 to 11 November 2003. His mission report is contained in document E/CN.4/2004/62/Add.2. A joint mission to Côte d'Ivoire with the Special Rapporteur on contemporary forms of racism, racial discrimination, xenophobia and related intolerance was cancelled because of the situation prevalent in the country, especially the lack of security. The mission has been tentatively re-scheduled for the beginning of 2004.

21. Since his appointment, the Special Rapporteur has received invitations to visit Colombia, Côte d'Ivoire, Equatorial Guinea, which he had already visited in December 2002, and the Islamic Republic of Iran. He would like to thank those Governments for their cooperation.

22. In addition, the Special Rapporteur has requested invitations to visit the following countries: Algeria, Angola, Azerbaijan, Bangladesh, Belarus, China, Cuba, the Democratic People's Republic of Korea, Eritrea, Ethiopia, Indonesia, Italy, Liberia, Nepal, the Russian Federation, Spain, Sudan, Swaziland, Turkmenistan, Venezuela, Viet Nam and Zimbabwe. The Government of Spain, on 4 August 2003, sent the Special Rapporteur a comprehensive reply to his request, without inviting him to visit the country.

## **E. Participation in seminars and conferences**

23. On 4 April 2003, the Special Rapporteur opened the Commission on Human Rights agenda item on civil and political rights by introducing his general report E/CN.4/2003/67. Mr. Ligabo stated, among other things, that the right to freedom of opinion and expression was a clear indicator of the level of protection and respect for all other human rights in a given society, that it helped promote and strengthen democratic systems, and that it had widespread benefits in other areas, such as in the effectiveness of education and information campaigns on HIV/AIDS prevention.

24. In particular, the Special Rapporteur said that alleged violations of the right to freedom of opinion and expression occurred in all countries, whatever their systems. Nonetheless, democratic institutions offered more guarantees for protection of the right and also contributed to the existence of sound democratic systems. Some positive trends, the Special Rapporteur continued, could be noted such as the repeal of criminal libel provisions in certain countries, but other developments were still a matter of grave concern. In connection with attacks against journalists, a practice occurring in several countries, the Special Rapporteur stated that he would welcome a specific request from the Commission to undertake an in-depth study on the security of journalists, particularly in situations of armed conflict.

25. During the fifty-ninth session of the Commission on Human Rights, the Special Rapporteur had the opportunity of consulting with representatives of the following countries: Canada, Colombia, Côte d'Ivoire, Denmark, Equatorial Guinea, the Islamic Republic of Iran, Norway, Pakistan and Zimbabwe. He also met the Commission on Human Rights Group of African States, the Special Rapporteur on contemporary forms of racism, racial discrimination, xenophobia and related intolerance, Mr. D. Diène and a representative of UNAIDS. Furthermore, he had a briefing with the press and several non-governmental organizations.

26. In these consultations, the Special Rapporteur explained the scope of his mandate and his working methods, emphasizing that he envisaged country missions to be carried out in a cooperative spirit. He pointed out that during country visits, special rapporteurs should be allowed to meet with all persons they request to meet and should have free access to prisons. The Special Rapporteur also said that, while on mission, he will seek clarification with relevant country authorities on any allegation he had considered reliable.

27. The Special Rapporteur shared with his interlocutors the view that Governments should not feel targeted by the thematic mechanisms of the Commission on Human Rights, since these are global mandates relating to all countries. Furthermore, he stated that it was important to establish a constructive dialogue with Governments on communications sent by Special Rapporteurs, and that he will attentively consider all replies which will be ultimately included in the Special Rapporteurs' reports.

28. In those meetings, the Special Rapporteur systematically underlined the importance he gives to the relation between freedom of expression and the combat against HIV/AIDS. Examining the lack of access to information concerning the disease might, he said, directly point to the responsibility of Governments in preserving and guaranteeing the health of citizens, and ultimately, in saving many human lives through timely and comprehensive awareness programmes.

29. UNESCO invited the Special Rapporteur to participate in the celebration of World Press Freedom Day on 3 May 2003 in Kingston, Jamaica. In parallel, UNESCO organized, on 2 and 3 May, a conference to discuss the theme "Unpunished crimes against journalists". Journalists from all over the world debated topics such as safety of journalists, a strategy to reduce impunity and, in general, obstacles to the full enjoyment of freedom of expression in the information society.

30. The Special Rapporteur attended the tenth meeting of the special rapporteurs/representatives, independent experts and chairpersons of working groups of the special procedures and advisory services programme of the Commission on Human Rights, held in Geneva from 23 to 27 June 2003. The report of the meeting is contained in document E/CN.4/2004/4.

31. The NGO Article XIX, the African Commission on Human and Peoples' Rights and the Media Foundation for West Africa invited the Special Rapporteur to the All Africa Conference on Freedom of Expression to be held in Accra at the beginning of December 2003. Eventually, the Conference was postponed because of a concomitant meeting of the African Commission on Human and Peoples' Rights.

32. The Organization for Security and Cooperation in Europe and its Representative on freedom of the media, jointly with Reporters Without Borders, invited the Special Rapporteur to a round table on "libel and insult laws", to be held in Paris from 24 to 25 November 2003. Unfortunately, due to his tight schedule, the Special Rapporteur was unable to participate in the round table.

33. The Special Rapporteur was also invited to the first phase of the World Summit on the Information Society, scheduled from 10 to 12 December 2003, in Geneva. The Special Rapporteur took note of the contents of the PrepCom 2 and PrepCom 3 meetings, respectively, held from 17 to 28 February 2003 in Paris, and from 15 to 26 September 2003 in Geneva, especially with regard to the draft declaration of principles. The Special Rapporteur regrets to note that the first phase of the World Summit on the Information Society largely neglected human rights issues, especially the right to freedom of opinion and expression. In his opinion, a society cannot properly be informed if human rights are not respected or promoted. Freedom of opinion and expression is a fundamental human right. The Special Rapporteur wishes to state that any declaration on the right to information excluding exhaustive references to that right, as well as other basic human rights, is an empty exercise of international relations. The Special Rapporteur hopes that the second phase of the World Summit on the Information Society, to be held in Tunis in 2005, will take remedial action on this serious shortcoming, and human rights will be integrated meaningfully in the final documents of the Summit.

#### **III. ISSUES**

#### **A. Implementing the right to access to information**

34. In paragraph 17 of its resolution 2003/42, the Commission on Human Rights invited, inter alia, the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression, within the framework of its mandate:

 (a) With a view to promoting greater efficiency and effectiveness, as well as enhancing his access to the information necessary for him to fulfil his duties, to continue his efforts to cooperate with other special rapporteurs, special representatives, independent experts, working groups, other United Nations mechanisms and procedures in the field of human rights, specialized agencies, including the United Nations Educational, Scientific and Cultural Organization, and regional intergovernmental organizations and their mechanisms and further to develop and extend his network of relevant non-governmental organizations, particularly at the local level, with a view to ensuring that he has the full benefit of all pertinent information from such non-governmental organizations;

 (b) To consider approaches taken to access to information with a view to sharing best practices;

 (c) To continue to provide his views, when appropriate, on the advantages and challenges of new information and communication technologies, including the Internet, for the exercise of the right to freedom of opinion and expression, including the right to seek, receive and impart information and the relevance of a wide diversity of sources, as well as access to the information society for all.

35. Taking into account the requests of the Commission, the Special Rapporteur decided to focus on the question of the existence and extent of the right to access to information.

### **1. Understanding the right to information**

36. Since the establishment of the mandate of the Special Rapporteur on freedom of opinion and expression in 1993, the Special Rapporteur has been concerned with the concept and meaning of the right to information. The Special Rapporteur's reports to the Commission on Human Rights have often dealt with the concept - or specific aspects of it.

37. Whilst defining the concept definitively will always be difficult, Gopakumar Krishnan and Andrea Figari, writing on Transparency International's Corruption Online Research and Information System (CORIS) web site, offer a helpful approach:

[I]t is quite imperative that we talk about a "right" wherein ordinary citizens can get information as an entitlement and not as a favour. Watering down what is now universally regarded as a fundamental right (the concept is clearly articulated in the Universal Declaration of Human Rights and the International Covenant on Civil and Political Rights) to passive concepts like "access" or "freedom" will blur the focus and dilute the effectiveness of any concerted effort to open up records. So let's get the semantics correct - we are talking about a non-negotiable right of citizens to demand information from the State and other relevant entities to enhance the quality of governance and strengthen the vibrancy of democracy.**<sup>1</sup>**

38. In his report E/CN.4/1995/43, the Special Rapporteur stated the basis for, and rationale of, the right to information as "The freedom to seek information is guaranteed in ICCPR Article 19 (2). It entails the right to seek information inasmuch as this information is generally accessible" (para. 34) and as "the right to seek or have access to information is one of the most essential elements of freedom of speech and expression. Freedom will be bereft of all effectiveness if the people have no access to information. Access to information is basic to the democratic way of life. The tendency to withhold information from the people at large is therefore to be strongly checked" (para. 35).

39. However, in a more extensive commentary in 1998 (E/CN.4/1998/40), the Special Rapporteur moved beyond understanding the right to information as an element of freedom of expression generally aiming at securing democracy, towards the understanding that: "the right to seek and receive information is not simply a converse of the right to freedom of opinion and expression but a freedom on its own" (para. 11); the right "imposes a positive obligation on States to ensure access to information", in particular, by "freedom of information legislation, which establishes a legally enforceable right to official documents for inspection and copying" (para. 14); the right to "access to information held by the Government must be the rule rather than the exception" (para. 12).

40. The Special Rapporteur clearly affirmed that, insofar as it relates to Government, "'State activity', for example, meetings and decision-making forums should be open to the public wherever possible", and classification systems (breaches of which often lead to officials being prosecuted) should only be employed to capture information "necessary" to prevent harm to the State (ibid., para. 12).

41. Further, the Special Rapporteur's commentary on the right to information (E/CN.4/2000/63) - a right "a right in and of itself" - endorsed the set of principles drawn up by the non-governmental organization Article XIX, The Public's Right to Know: Principles on Freedom of Information Legislation, based on "international and regional law and standards, evolving State practice, and the general principles of law recognized by the community of nations". The principles are set out in annex II to that year's report.

42. In 1996, the Special Rapporteur noted the contribution of non-governmental organizations in furnishing "useful materials" on aspects of the right, in particular the relationship between the right to information and national security. The Johannesburg Principles on National Security, Freedom of Expression and Access to Information were endorsed and reproduced in an appendix to that year's report (E/CN.4/1996/39).

43. Another expression of relevant principles informing the concept of the right to information, The Lima Principles (adopted by the Seminar on Information for Democracy, Lima, 16 November 2000) were endorsed and set out in annex II of the 2001 report (E/CN.4/2001/64).

44. One of the main recommendations contained in the report E/CN.4/1998/40 stated that "As regards information, particularly information held by Governments, the Special Rapporteur strongly encourages States to take all necessary steps to assure the full realization of the right to access to information." In particular, the Special Rapporteur was of the view that the right to seek, receive and impart information imposes a positive obligation on States to ensure access to information, particularly with regard to information held by Government in all types of storage and retrieval systems, including film, microfiche, electronic capacities and photographs. In this regard, the Special Rapporteur observed that in countries where the right to information was mostly realized, access to governmental information is often guaranteed by freedom of information legislation, which establishes a legally enforceable right to official documents for inspection and copying (para. 14).

45. The Special Rapporteur went on to note the importance of such legislation establishing adequately-resourced "independent administrative bodies", having the power to compel the Government to produce information so that a decision may be made on whether any denial is legitimate and to then issue binding decisions on public authorities (ibid., para. 14).

46. In 1998, the Special Rapporteur suggested that it would be useful to "undertake a comparative study of the different approaches taken on this issue in different countries, with regard to the legislative framework, review mechanisms, as well as the implementation in practice" (para. 15).

47. This call was repeated in the 1999 report (E/CN.4/1999/64). The different countries would be appraised against the framework that "everyone has the right to seek, receive and impart information and that this imposes a positive obligation on States to ensure access to information, particularly with regard to information held by Government in all types of storage and retrieval systems - including film, microfiche, electronic capacities, video and photographs - subject only to such restrictions as referred to in article 19, paragraph 3, of the International Covenant on Civil and Political Rights" (para. 12).

#### **2. Global trends**

48. The Special Rapporteur notes the global trend, which is resulting in the adoption of increasing numbers of laws on the right to information. The latest tally is more than 50, in all regions of the world.**<sup>2</sup>** The Special Rapporteur also notes the official and non-official efforts, globally and regionally, to foster, entrench and support the principle, law and practice regarding the right to information. In this regard, the Special Rapporteur would like to mention in particular:

 (a) A seminar, "What Access to Official Documents?", held under the auspices of the Council of Europe concluded, inter alia, with a call to the Council of Europe's Steering Committee on Human Rights and Group of Experts on Access to Official Information to "promote a binding instrument on access to official documents, which could be signed and ratified by member Governments;**<sup>3</sup>**

 (b) At its 33rd General Assembly in Santiago, the Organization of American States adopted a resolution on "access to public information: strengthening democracy".**<sup>4</sup>** The Special Rapporteur wishes to endorse the principles contained in this resolution.

 (c) At the 22nd Governing Council meeting of the United Nations Environment Programme (UNEP), a decision was adopted regarding enhancing the application of principle 10 of the Rio Declaration on Environment and Development addressing, inter alia, the issue of access to information. That decision (UNEP/GC.22/L.3/Add.1) requests UNEP to "… assess the possibility of promoting, at the national and international levels, the application of principle 10 to determine if there is value in initiating an intergovernmental process to prepare global guidelines on applying principle 10". Further, the decision "requests UNEP's Executive Director to produce a report on progress made in preparing the guidelines for review at the Governing Council's twenty-third session".**<sup>5</sup>**

 (d) The special focus of Transparency International's *Global Corruption Report 2003* on access to information.**<sup>6</sup>** The chapter on "Freedom of Information legislation: progress, concerns and standards" makes the proposal that "much more needs to be done" to create clear, authoritative global standards such as, for instance, the "adoption of a declaration on freedom of opinion by the United Nations would go some way to addressing this problem and would help to provide an impetus for the adoption of national legislation".**<sup>7</sup>**

49. However, the Special Rapporteur was acutely aware that the movement towards enhancing the right to information is proceeding against a backdrop of increasing governmental concern over anti-terrorism policies and initiatives. These can have an adverse effect on the right to information. The matter has been well addressed in the Commonwealth Human Rights Initiative's publication, *Open Sesame: Looking for the Right to Information in the Commonwealth*. This has been published to highlight the right to information as the major topic issue for the 2003 Commonwealth Heads of Government Meeting.**<sup>8</sup>**

50. The Special Rapporteur also notes, in this connection, the work and proposals for new thinking being done within the book *National Security and Open Government: Striking the right balance*, a joint project of the Campbell Public Affairs Institute and the Open Society Justice Initiative. The project is, inter alia, redefining the notion of national security; showing how

openness can be an "ally" in the war against terror; harnessing the anti-corruption movement in promoting transparency; and how to set the highest standards for the proper application of national security restrictions.**<sup>9</sup>**

### **3. The right to sustainable development and financial transparency**

51. The Special Rapporteur noted favourably the United Nations Development Programme's 1997 transparency policy in the context of the relationship between the right to information and the right to development. The Special Rapporteur also commended the work done by UNDP's Oslo Governance Centre on the right to information, based on addressing the information and communication needs of the poor as an essential feature of the right to information because the poor often lack information that is vital to their lives - information on basic rights and entitlements, information on public services, health, education and employment.**<sup>10</sup>**

52. UNDP's activities in access to information focus on: Establishing a legislative framework on access to official information; public awareness-raising on official information legislation; capacity-building of the civil service to meet and monitor official information requests; using the right to information (strengthening of civil society and the media to make use of official information legislation; enforcing the Official Information Legislation (accountability mechanisms that hold national Governments to account for failing to provide official information).

53. The Special Rapporteur noted that the development of a "practice note and practice materials to assist UNDP's country offices in their access to information programming".**<sup>11</sup>** This Practice Note is based on a "background paper that captures and codifies UNDP's current practice in access to information while at the same time situating this work within the external context and UNDP's existing policy framework".

54. Also in connection with the right to sustainable development, the Special Rapporteur noted with great interest developments concerning the transparency of revenues and payments, in particular regarding the extractive industries - The Extractive Industries Transparency Initiative (EITI). Following a meeting in London, June 2003, a Statement of Principles and Agreed Actions on this matter was supported by 140 delegates representing 70 Governments, companies, industry groups, international organizations, investors and non-governmental organizations.

55. While impressed in general with the philosophy of transparency lying behind EITI, the Special Rapporteur was concerned at the voluntary aspect of the initiative, having regard to the non-optional nature of the right to information. In the view of the Special Rapporteur, the real viability of financial transparency lies in Governments cooperating to reveal financial flows and this result might be achieved on a country-by-country basis using various incentives and levers. In addition, the Special Rapporteur is concerned that efforts be made to expand the scope of disclosures to encompass government budgets and procurement processes.

56. Finally, the Special Rapporteur noted with great interest related non-governmental initiatives in the area of International Financial and Trade Institutions (IFTI) transparency: "IFTI Watch", which aims to monitor and promote information disclosure by International Financial

and Trade Institutions**<sup>12</sup>** and the Global Transparency Initiative, an "informal network of civil society organizations … working together to overcome the secrecy surrounding the operations of the International Financial Institutions", which has recently formulated a 225-item "matrix" to enable comparative research on the transparency policies.**<sup>13</sup>**

57. The Special Rapporteur was aware that, in the context of IFTIs, the disclosure policies of most multilateral development institutions are guided by a presumption in favour of disclosure, in absence of a compelling reason not to disclose. These disclosure policies list a series of constraints to disclosure under which information can be kept confidential. In addition to these provisions, the policies also list a series of documents that are highly recommended for disclosure, normally with the consent of the borrowing Government.

58. The Special Rapporteur was concerned at the lack of any independent oversight mechanism to evaluate how multilateral development institutions staff and management decides whether or not to disclose a certain document, and how consistent these decisions are. The key issue is whether or not institutions officials are properly weighing the public interest.

59. The Special Rapporteur was concerned that the disclosure policies of the multilateral development institutions lack accountability, and that, in line with national right to know laws, multilateral development institutions need to be made accountable to an independent oversight and review mechanism. The role of the independent mechanism would be to: receive appeals from the public when citizens feel that they have been wrongly denied information; to provide opinions to the board and management of the institution on what should be disclosed, and to conduct annual reviews of disclosure policy implementation.

## **4. Implementing and monitoring the right to information**

60. The Special Rapporteur appreciated that, to be effective, States should implement the right to information by establishing specific legislation, conforming to best international principles and practice. The annual review of the right to information laws in the world, carried out by Privacy International's Freedom of Information Project**<sup>14</sup>** indicates that more than 50 States have adopted such laws. However, ensuring an effective right to information regime entails that the law must comprise certain fundamental structural elements (e.g., regular reporting mechanisms to independent oversight bodies), and systematic official and unofficial monitoring of the implementation of the law.

61. Increasingly, there are projects designed to facilitate monitoring of the implementation of the right to information, both global/regional and national in scope. Some focus on the right to information in general; others concentrate on environmental information/sustainable development fields.

62. The Special Rapporteur notes with particular interest the Open Society Justice Initiative's *Access to Information Monitoring Tool*. **<sup>15</sup>** Importantly, the tool can be used to measure and track access to information held both by national authorities and by international/supranational organizations.

63. The Special Rapporteur awaited with interest the outcome of the pilot project currently being undertaken by the Open Society Justice Initiative, and due to report in late 2003, monitoring the situation with regard to the implementation of the right to information in five countries.

64. The Special Rapporteur also noted with interest The Access Initiative (in conjunction with the World Resources Institute)**<sup>16</sup>** which focuses on the provision of environmental information. The Access Initiative is a global coalition of civil society groups working together to promote national-level implementation of commitments to access to information, participation, and justice in decisions affecting the environment. The Initiative has its roots in the 1992 Rio Declaration, Principle 10**<sup>17</sup>** which stated that "At the national level, each individual shall have appropriate access to information concerning the environment that is held by public authorities; including information on hazardous materials and activities in their communities … States shall facilitate and encourage public awareness and participation by making information widely available".

#### **B. Access to information for the purposes of education on, and prevention of, HIV/AIDS**

65. In a joint statement dated 29 November 2002, the late United Nations High Commissioner for Human Rights, Sergio Vieira De Mello and the Special Rapporteur on the right to health, Paul Hunt, stated that: "One crucial step is ensuring access to treatment, care and support. Equally important are prevention measures, including access to appropriate information, education, goods and services. All of these steps are central to the solemn pledge made by all United Nations Member States in the Declaration of Commitment adopted at last year's General Assembly special session." The Special Rapporteur welcomed this statement which, inter alia, reflected the substance of the conclusions on this matter made in his 2003 report.

66. The Special Rapporteur welcomed the adoption of resolution 2003/47, on 23 April 2003, by the Commission on Human Rights. In that resolution, the Commission insisted on the importance of sharing knowledge, experiences and achievements concerning HIV-related issues and urged States to, inter alia, promote effective programmes for the prevention of HIV/AIDS, including through education and awareness-raising campaigns. The Commission also requested States to develop and support services, including legal aid where appropriate, to educate people infected and affected by HIV/AIDS about their rights and to assist them in realizing their rights.

67. In addition to the above, the Special Rapporteur especially welcomed the Commission's request to States to take all the necessary steps, including appropriate education, training and media programmes, to combat discrimination, prejudice and stigma, and to ensure the full enjoyment of civil, political, economic, social and cultural rights, including access to care, by people infected and affected by HIV/AIDS. Finally, the Special Rapporteur noted with appreciation the Commission's request that all special representatives, special rapporteurs and working groups of the Commission, including the special rapporteur on the promotion and protection of freedom of opinion and expression, to integrate the protection of HIV-related human rights within their respective mandates.

68. The Special Rapporteur took note of the valuable speech made by the Sub-Commission on Promotion and Protection of Human Rights Expert, David Weissbrodt, at the fifty-fifth session of the Sub-Commission, on 4 August 2003. Mr. Weissbrodt stated, inter alia, that the rapid spread of the HIV virus was facilitated by the unwillingness of many Governments to support preventive education related to HIV/AIDS. The Sub-Commission expert also said that Governments and non-governmental organizations must give priority to both formal and informal educational programmes that enabled women to develop self-esteem, acquire knowledge, make decisions on, and take responsibility for their own sexual health.

#### **C. The right to freedom of opinion and expression and counter-terrorism measures**

69. The Special Rapporteur noted the adoption of General Assembly resolution 57/219 of 18 December 2002 in which it affirmed that States must ensure that any measure taken to combat terrorism complies with their obligations under international law. The General Assembly also encouraged States to consider the recommendations of the special procedures and mechanisms of the Commission on Human Rights and the relevant comments and views of United Nations treaty bodies.

70. The Special Rapporteur much appreciated the intervention of the late High Commissioner for Human Rights who placed great emphasis on the need to respect human rights while countering terrorism in his bilateral discussions with Member States. In particular, he underlined the principle that any exceptional measures taken to counter terrorism must be subject to strict limitations, including that they be transparent, necessary, time-limited and otherwise strictly proportional to the exigencies of the situation. The High Commissioner also continued to call attention to certain human rights provisions which are non-derogable under any circumstances, including freedom of thought, conscience and religion (see E/CN.4/2003/120, para. 5).

71. The Special Rapporteur welcomed the adoption of Commission on Human Rights resolution 2003/68, entitled "Protection of human rights and fundamental freedoms while countering terrorism", in which the Commission reiterated its interest and concern on this matter.

72. In connection with paragraph 4 of Commission resolution 2003/68, the Special Rapporteur expressed his esteem to the Vice-Chairperson of the Human Rights Committee, Sir Nigel Rodley, for the meaningful and balanced speech he made before the Counter-Terrorism Committee of the Security Council on 19 June 2003. The Special Rapporteur found particularly significant the mention the Vice-Chairperson of the Human Rights Committee made of the declaration annexed to Security Council resolution 1456 (2003), paragraph 6, in which the Council demanded that:

"States must ensure that any measure taken to combat terrorism comply with all their obligations under international law, and should adopt such measures in accordance with international law, in particular international human rights, refugee, and humanitarian law."

73. The Special Rapporteur noted that the Sub-Commission on the Promotion and Protection of Human Rights, at its fifty-fifth session, extensively discussed the nature and the consequences of the human rights violations that terrorism represented, as well as the human rights violations

observed in counter-terrorism measures undertaken since 11 September 2001. The Special Rapporteur also took note of the concluding remarks of the Special Rapporteur of the Sub-Commission on human rights and terrorism, Kalliopi Koufa, in which she said that the discussion on terrorism and human rights was complicated, inter alia, by the current international tension that had also somewhat affected the inability of the international community to identify a definition of terrorism.

74. The Special Rapporteur welcomes the drafting of "The digest of relevant practice of the United Nations and regional organizations in the area of the protection of human rights while countering terrorism", in accordance with recommendation No. 5 of the report of the Policy Working Group, submitted to the General Assembly and the Security Council (A/57/273-S/2002/875). Starting from the concept that human rights law establishes a framework in which terrorism can be effectively countered without infringing on fundamental freedoms; the digest examined a number of issues critical to the balance between legitimate national security concerns and fundamental freedoms. Provisions contained in the International Covenant on Civil and Political Rights (ICCPR), the European Convention for the Protection of Human Rights and Fundamental Freedoms (ECHR), the American Convention on Human Rights (ACHR) and the African Charter on Human and Peoples' Rights, and the decisions taken by the bodies monitoring the implementation of the above conventions constituted the core of the digest.

75. The three conventions mandate that certain rights may not be derogated from under any circumstances. The American Convention contained strong guarantees on freedom of expression which were designed to reduce to a bare minimum restriction impeding the free circulation of ideas. For instance, the Inter-American Court stated that:

"Freedom of expression is a cornerstone upon which the very existence of a democratic society rests. It represents, in short, the means that enable the community, when exercising its options, to be sufficiently informed. Consequently, it can be said that a society that is not well informed is not a society that is truly free."**<sup>18</sup>**

76. With regard to the content of the right to freedom of thought and expression, those who are protected by the Convention not only have the right and the freedom to express their own thoughts, but also the right and freedom to seek, receive and impart information and ideas of all kinds. Consequently, freedom of expression has an individual and a social dimension: "It requires, on the one hand, that no one be arbitrarily limited or impeded in expressing his own thoughts. In that sense, it is a right that belongs to each individual. Its second aspect, on the other hand, implies a collective right to receive any information whatsoever and to have access to the thoughts expressed by others."**<sup>19</sup>**

77. Finally, the American Convention also pointed out, in article 16, that the freedom of association "shall be subject only to such restrictions established by law as may be necessary in a democratic society, in the interest of national security, public safety or public order, or to protect public health or morals or the rights and freedoms of others".

78. The Special Rapporteur also wishes to draw the attention of the reader to the joint statement of special rapporteurs, independent experts and chairpersons of the working groups of the special procedures of the Commission on Human Rights and of the advisory services programme, released at the end of their 10th meeting, held in Geneva from 23 to 27 June 2003 (E/CN.4/2004/4, p. 22).

#### **IV. CONCLUSIONS AND RECOMMENDATIONS**

79. **The Special Rapporteur considers that the exercise of the right to freedom of opinion and expression is a significant indicator of the level of protection and respect of all other human rights in a given society. The Special Rapporteur notes that positive measures are being taken in a number of countries in favour of a greater protection of the right to freedom of opinion and expression and in a few cases, also in favour of the promotion of the freedom of opinion and expression. He encourages members and organizations of civil society especially to continue to provide him with information on the realization and violations of the right to freedom of opinion and expression around the world.** 

80. **However, in spite of some progress, the situation is still grim: numerous trends and violations patterns remain substantially active and unchanged. The Special Rapporteur remains extremely concerned at the fact that the attacks against journalists and media workers, including killings, continue to occur in many countries. Most of the time these crimes are not adequately punished, if not encouraged or favoured by authorities. He urges Governments to take all necessary measures to protect journalists from attacks, be they from officials, law enforcement officers, armed groups or terrorists, and to provide an enabling environment for their activities. An end to impunity for the perpetrators of such acts and the conduct of serious investigation into these attacks is essential to ensure greater protection for journalists. The Special Rapporteur urges national authorities, both civilian and military, to carry out, for the sake of truth, investigations on the killings and attacks on journalists and reporters in any event and location, including war and conflict zones.** 

81. **The Special Rapporteur strongly believes that an in-depth study on the issue of the security of journalists, in particular in situations of armed conflicts, based on information from and the experiences of Governments, intergovernmental and non-governmental organizations, is necessary, and he would welcome a request from the Commission on Human Rights to undertake such a study.** 

82. **Generally, the number of journalists and reporters working in war zones has increased because modern technologies have made it possible to report instantaneously with minimal equipment. Consequently, the danger is greater as media are now experiencing the same kind of action of combatants. The Special Rapporteur noted that the fact that journalists can report from the front line has some positive and, at the same time, some negative aspects. While the violence and the absurdity of war are fully disclosed, warriors and civilians involved in the conflicts seem to be treated in a different way according to the side they belong to. The Special Rapporteur underlines that media should provide a factual, impartial, overview of the conflict, and that war victims and war prisoners should be treated in accordance with international human rights and humanitarian standards.** 

83. **The Special Rapporteur believes that democratic institutions, while not preventing punctual violations of the right to freedom of opinion and expression, do offer guarantees for its protection as well as an enabling environment for its exercise. Freedom of opinion and expression not only benefits from a democratic environment; it also contributes, and is indeed instrumental to the emergence and existence of effective democratic systems. However, violations of the right to freedom of opinion and expression may occur in all regions and countries, whatever their system, and may have various forms and shape. The Special Rapporteur urges all concerned Governments to implement the necessary measures to review existing practices and take remedial actions. The Special Rapporteur especially encourages Governments of emerging democracies to promote and protect freedom of opinion and expression and freedom of the press and political parties. As appropriate, Governments may also consider the possibility of seeking technical assistance from OHCHR in order to eliminate the causes of human rights violations.**

84. **The Special Rapporteur believes that, in the legitimate effort to prevent and eliminate terror, progress towards enhancing the basic right to information is extremely vulnerable and is highly susceptible to unwarranted restrictions. Consequently, the Special Rapporteur would consider the opportunity of reporting annually on the situation of balance/imbalance in this regard, and may evaluate the possibility of intervening as and when necessary in the light of any gross instance occurring in any national jurisdiction.** 

85. **The Special Rapporteur is especially concerned about the concentration of large media groups, dominant in a given market, in the hands of a few business corporations. Reversing this phenomenon will allow the emergence of a more pluralistic approach to information and will contribute to more efficient service to customers. The Special Rapporteur encourages Governments to ensure that the exercise of the freedom of opinion and expression through the media is open and accessible to various actors of the civil society, local communities and minorities, vulnerable groups, in addition to economic and political groups.** 

86. **The Special Rapporteur noted that, in some countries, decisions of courts are unavailable to any but the parties involved. This deprives the whole community of the outcome of the full body of judicial decisions, thus hindering their collection and their analysis, constituent elements of the rule of law. In this connection, the Special Rapporteur believes that the monitoring of national legislation, compared to the generally-accepted principles of the public's right to know, should be carried out in a systematic way, for instance through a global survey of jurisprudence on access to information cases.** 

87. **As regards legislatures, the Special Rapporteur felt that it would be useful to survey the scope of accessible information held by parliaments e.g. verbatim proceedings of the plenary chamber; background papers and full records of proceedings of committees and subcommittees, and the extent to which draft laws are published prior to their being considered by the legislature. A "trend survey of access to information" would be a useful tool to measure access.** 

88. **The Special Rapporteur encourages and supports the development of initiatives aimed at monitoring the implementation of the right to information. He considers that the United Nations system should increasingly contribute to such initiatives within existing** 

**technical and financial resources. In this context, the Special Rapporteur wishes to encourage and support the important work to increase financial transparency and accountability, and its link with sustainable development, with special reference to the activities of multilateral development institutions.**

89. **The Special Rapporteur would consider the opportunity of gathering information on proposals to enhance the right to information by the adoption of a global and/or regional, binding and/or authoritative instrument on the right to information. The Special Rapporteur also wishes to give further consideration to the drafting of a set of recommendations supporting a comparative study of measures to better implement the right to information.** 

90. **The Special Rapporteur believes that an expert seminar on "Designing and evaluating projects at the global, regional and national level to monitor the effective implementation of the right to information held by national and intergovernmental authorities" should be planned and organized by the relevant United Nations agencies in the future.** 

#### **Notes**

**1** See www.corisweb.org/article/archive/246/.

**2** See www.freedominfo.org/survey.htm.

**3** Sem-AC (2002) 009 def, Strasbourg, 25 March 2003.

**4** Organization of American States, AG doc. 4238/03: AG RES. 1932 (XXX111- O/03), Annex I.

**5** See www//iisd.ca/linkages/unepgc/22gc/, pp. 9-10.

**6** See www.globalcorruptionreport.org/download.shtml.

**7** See www.globalcorruptionreport.org/download/gcr2003/07\_Freedom\_of\_information \_legislation\_(Mendel).pdf, p. 5.

**8** See www.humanrightsinitiative.org/publications/chogm/chogm\_2003/default.htm.

**9** See www.maxwell.syr.edu/campbell/opengov.

**<sup>10</sup>** See www.undp.org/oslocentre/civilsoc.htm.

**<sup>11</sup>** See www.undp.org/oslocentre/citzpart.htm.

- **<sup>12</sup>** See www.freedominfo.org/ifti.htm.
- **<sup>13</sup>** See www.bicusa.org/policy/InfoDisclosure/workinggroup.htm.

**<sup>14</sup>** See www.freedominfo.org/survey.htm.

**<sup>15</sup>** See www.justiceinitiative.org/activities/foifoe/foi/foi\_aimt.

**<sup>16</sup>** See www.accessinitiative.org/.

**<sup>17</sup>** See www.un.org/documents/ga/conf151/aconf15126-1annex1.htm.

**<sup>18</sup>** Inter-American Court H.R., Advisory Opinion OC-5/85, *Compulsory Membership in an Association Prescribed by Law for the Practice of Journalism* (articles 13 and 29 of the American Convention on Human Rights), 13 November 1985, Ser. A No. 5 (paras. 50, 70).

**<sup>19</sup>** *Olmedo Bustos et al. Case ("Last Temptation of Christ")*, I/A Court H.R., Series C No. 73, Judgement of 5 February 2001 (para. 64).

-----
![](_page_0_Picture_2.jpeg)

24 March 2020

Original: English

**Human Rights Council Forty-third session** 24 February–20 March 2020 Agenda item 3

## **Promotion and protection of all human rights, civil, political, economic, social and cultural rights, including the right to development**

#### **Report of the Special Rapporteur on the right to privacy**\*, \*\*

## *Summary*

In the present report, prepared pursuant to Human Rights Council resolution 28/16, the Special Rapporteur on the right to privacy highlights activities undertaken in 2019 concerning, inter alia, security and surveillance, health data and the use of personal data by business enterprises. The thematic focus of the report is reflected in recommendations for protecting against gender-based privacy infringements.

<sup>\*\*</sup> Acknowledgements and bibliographical information for the present report may be found on the website of the Special Rapporteur (www.ohchr.org/EN/Issues/Privacy/SR/Pages/ AnnualReports.aspx).

![](_page_0_Picture_12.jpeg)

![](_page_0_Picture_13.jpeg)

<sup>\*</sup> The present report was submitted after the deadline to reflect the most recent information.

# **I. Overview of activities**

1. Since March 2019, the Special Rapporteur has examined challenges arising from new technologies, undertaken official and "non-official" country visits, promoted the protection of the right to privacy, advocated privacy principles, contributed to international events on privacy, raised awareness of the right to privacy and effective remedies and reported on alleged violations.

2. In October 2019, the Special Rapporteur submitted a report to the General Assembly containing a recommendation on the use of health-related data (A/74/277).

## **Communications to Member States**

3. Throughout the year, letters and statements were issued in which matters concerning practices that appeared to be inconsistent with the right to privacy were raised. They included communications with the Government of Saudi Arabia between February and June 2019 concerning the use of technology and the infringement of women's rights to privacy and a full set of recommendations to the Government of Malta in December 2019 and January 2020 in connection with proposals for reforming oversight of the security services. The Special Rapporteur is pleased to note that he is also increasingly receiving requests from Governments to assist them in drafting new privacy laws, including on both data protection and surveillance carried out by law enforcement and intelligence services.

## **Task force on corporations**

4. From 16 to 18 September, the Special Rapporteur organized the second task force meeting of 2019, held in Brussels, on the use of personal data by corporations, following the first meeting, held in Malta in March. The event was attended by partner civil society organizations and leading corporations, including Huawei, Deutsche Telekom, Microsoft, Facebook, Apple and Google. It included discussions of best practices and common challenges on topics such as corporate transparency, artificial intelligence, the use of personal data and privacy and children.

## **Task force on privacy and health-related data**

5. The recommendation on the use of health-related data made to the General Assembly was developed with specialized input and extensive global consultation and has been well received. The updated version of the recommendation and a detailed explanatory note are available online.<sup>1</sup>

### **Task force on privacy and personality**

6. Following its release to the Human Rights Council in March, consultations on the preliminary report entitled "Privacy: a gender perspective" were opened. Stakeholder feedback was instrumental during a consultation event organized in New York with the support of New York University, Facebook and others on 30 and 31 October.

7. The Special Rapporteur also provided input on privacy and gender to events organized by the United Nations Development Programme in June and October and to international forums.

## **Children and privacy**

8. The Special Rapporteur is working independently and in collaboration with the Interdepartmental Committee on the Convention on the Rights of the Child to develop new guidelines to protect children's privacy. He participated in a consultation event held in London on 7 and 8 October on the general comment being prepared by the Committee. He gave a briefing to the Committee in Geneva on 31 January 2020.

<sup>1</sup> Se[e www.ohchr.org/Documents/Issues/Privacy/SR\\_Privacy/MediTASFINALExplanatory](http://www.ohchr.org/Documents/Issues/Privacy/SR_Privacy/MediTASFINALExplanatory%20Memoradum1.pdf) [Memoradum1.pdf.](http://www.ohchr.org/Documents/Issues/Privacy/SR_Privacy/MediTASFINALExplanatory%20Memoradum1.pdf)

## **Visits and events**

9. Official visits were carried out to Argentina in May and the Republic of Korea in July. Preliminary findings were released at the conclusion of each visit.

10. The Special Rapporteur undertook study visits and attended international events, including the regional conference on data protection in Africa, held in Ghana in June, and the forty-first International Conference of Data Protection and Privacy Commissioners, held in Tirana in October.

## **II. Security and surveillance**

#### **International Intelligence Oversight Forum**

11. On 8 and 9 October, the Special Rapporteur organized the fourth edition of the International Intelligence Oversight Forum, in London. Over 170 delegates from independent oversight agencies, parliamentary committees and intelligence services in over 40 countries engaged in candid discussions about best practices to improve the protection of privacy through the oversight of surveillance.

12. The Special Rapporteur thanks the Government of the United Kingdom of Great Britain and Northern Ireland for its crucial support. He encourages all Member States to respond to the invitations extended through their permanent missions in Geneva and participate in the Forum. The next gathering is scheduled for late October 2020.

## **Encryption**

13. The Special Rapporteur is working on a multi-stakeholder initiative in response to some nations' well-intentioned but fatally flawed calls for corporations to weaken or halt individual access to strong encryption.

## **Individual cases**

14. The Special Rapporteur has devoted significant time and resources to dealing with individual cases related to surveillance, including those initiated following complaints by Julian Assange and the President of Ecuador, Lenín Moreno. Investigations are ongoing and will be reported on separately, as appropriate.

## **III. Gender equality and the right to privacy**

15. Everyone, irrespective of their biological sex, sex characteristics, sexual orientation or gender identity or expression, is entitled to the full enjoyment of the right to privacy. For some, their gender<sup>2</sup> entails a particular reliance upon States and non-State actors to facilitate access to their right to privacy and to protect them from infringements.

16. Privacy enables the full development of the person, while protecting against harms that stunt human development, innovation and creativity, such as violence, discrimination and the loss of the freedoms of expression, association and peaceful assembly.

17. Privacy and gender have long been regarded as second-order considerations, but their complex impact on society is of critical importance. Recognizing that significance is imperative to delivering the pledge within the 2030 Agenda for Sustainable Development to leave no one behind and reach the furthest behind first.

18. The Special Rapporteur requires the integration of a gender perspective into all the work in pursuance of the mandate. He has therefore incorporated a gender perspective into

<sup>2</sup> All references to gender herein should be read to mean inclusive of cisnormativity, sexual orientation, gender identity, gender expression and sex characteristics and the social norms attributed to biological characteristics.

task forces on thematic action streams and has sought a better understanding of privacy from a gender perspective.

19. The work undertaken <sup>3</sup> reveals the following deeply disturbing infringements of privacy related to, or arising from, an individual's gender:

(a) Gender-based breaches of privacy are a systemic form of the denial of human rights, are discriminatory in nature and frequently perpetuate unequal social, economic, cultural and political structures;

(b) These harms extend beyond individuals and have an impact on society as a whole. Losses of privacy weaken the universality of human rights and corrode societies and democracy;

(c) Gender and factors such as ethnicity, beliefs, culture, social origins, age, economic self-sufficiency and legal and political frameworks serve to mould experiences of privacy;

(d) Privacy infringements happen in multiple, interrelated and recurring forms facilitated by digital technologies, in both private and public settings and across physical and national boundaries. Online privacy infringements reflect and extend offline privacy infringements. Digital technologies amplify their scope and intensify their impact;

(e) Privacy offers protection against gender-based violence and discrimination and other harms that disproportionately affect women and intersex and gender-nonconforming individuals;

(f) The actions and responses of States and non-State actors in relation to infringements of privacy based on gender were reported as ranging from weakly supportive to punitive, with a few notable exceptions;

(g) Remedial actions to address gender-based breaches of privacy are needed at the international, regional and national levels. Preventive strategies that address the behaviours of individuals alone have been ineffective.

20. A robust international privacy and gender framework was identified as comprising:

(a) Integration of a gender perspective and privacy into the mandates of United Nations entities, special procedures and other mechanisms of the Human Rights Council and treaty bodies;

(b) Collaboration between States, companies, religious bodies, civil society, human rights institutions, professional organizations and individuals to secure the benefits of the right to privacy for all, regardless of gender;

(c) Recognition that, for those vulnerable on account of their gender, the interrelationship between privacy and other rights, such as the freedoms of assembly and expression, is heightened;

(d) A contemporary understanding of gender based on recognition that:

(i) Cisnormativity, biological sex, sexual orientation and expression, gender identity or expression, sex characteristics and societal norms are elements of gender;

(ii) Gender, for some individuals, can change throughout their lives;

(iii) Gender identity is integral to personality and important to self-determination, dignity and freedom;

(iv) Gender intersects with ethnicity, indigeneity, age, disability, health, migration and marital or family status, among others, to heighten the importance of human rights to dignity and quality of life;

<sup>3</sup> See annex II.

(e) Promotion, design and enforcement of the right to privacy to address structural inequities in order to significantly increase enjoyment of the right to privacy by those furthest behind;

(f) Assistance for State and non-State actors and individuals to implement their responsibilities with regard to the right to privacy, education on gender issues and support for civil society organizations;

(g) Redress for victims of infringements of privacy based on gender.

21. There is great need for international leadership on gender equality and privacy rights. Establishing clear international directives on how to protect against gender-based infringements of privacy will help to prevent the harms that many individuals and communities continue to face.

22. The above findings, along with those of treaty bodies and human rights experts, have shaped the following recommendations aimed at addressing the gap.

## **IV. Recommendations for protecting against gender-based infringements of privacy**

23. The recommendations below build upon the findings contained in the preliminary findings on privacy and gender (see A/HRC/40/63), presented in March 2019, and subsequent consultations. The recommendations are aimed at ensuring the right of every person, regardless of gender, to fully enjoy the right to privacy and to participate in public and private spheres, intimate decisions and human relations without arbitrary interference, as set out in the Universal Declaration of Human Rights (art. 12), the International Covenant on Civil and Political Rights (art. 17) and the findings of treaty bodies.

24. The recommendations are intended to cover both State and non-State actors and are relevant to the privacy of all individuals, inclusive of binary female and male individuals and those of diverse sexual orientation, gender identity, gender expression and sex characteristics.

25. Their implementation should be informed by the consideration of other internationally recognized instruments, such as the Convention on the Elimination of All Forms of Discrimination against Women, the Convention on the Rights of the Child, the updated Yogyakarta Principles on the Application of International Human Rights Law in relation to Sexual Orientation and Gender Identity and the United Nations Declaration on the Rights of Indigenous Peoples.

26. Nothing in the recommendations should be interpreted as restricting or limiting the rights and freedoms of individuals as recognized in international, regional or national laws or standards. Nor are the provisions designed to restrict the collection of sex and gender information where such data are necessary for the performance of lawful responsibilities.

## **A. Development of personality and the person**

27. States and non-State actors should:

(a) Recognize that:

(i) The right to privacy includes gender identity and the freedom of individuals to make autonomous decisions about their bodies;

(ii) The privacy needs and aspirations of people and populations of cisnormativity and diverse sexual orientations, gender identities, gender expressions and sex characteristics, while having common ground, are distinct from one another;

(iii) Other factors, such as disability, age, indigeneity and social origins, intersect with gender, typically to intensify experiences of privacy and gender;

(iv) An intersectional approach is necessary to address the gender aspects of privacy;

(b) Respect, protect and facilitate the right to privacy to enable individuals to enjoy other rights, such as the rights to assemble and express opinions, irrespective of their gender, by:

(i) Promoting Internet access for all, regardless of gender, and bridging any digital gender divides using relevant mechanisms, including building digital skills and appropriate online behaviour;

(ii) Reducing infringements of privacy based on gender by:

a. Adopting robust privacy and data protection laws and policies;

b. Making public commitments on addressing gender differences in the enjoyment of the right to privacy;

c. Running public awareness campaigns, training courses and continuing professional development programmes with comprehensive, affirmative and accurate material on sexual, biological, physical and psychological diversity and human rights;

d. Adopting all measures necessary to eliminate the stigma associated with gender diversity, including ensuring internal and external communications that constructively address privacy and gender issues;

e. Requiring gender-aware privacy impact assessments before introducing new products, services, strategies, legislation, procedures and initiatives;

(c) Ensure that requirements for the provision by individuals of sex and gender information:

(i) Are relevant, reasonable and necessary, as required by law for a legitimate purpose in the circumstances in which such provision is sought;

(ii) Respect the right to self-determination of gender;

(iii) Protect against the arbitrary or unwanted disclosure or threatened disclosure of such information;

(iv) Support research into the right to privacy and gender to better understand the benefits, prevention and mitigation of harms arising from infringements of privacy.

28. States should take all legislative, policy, administrative and other measures, in line with international human rights norms and standards, necessary to ensure that:

(a) All individuals have information about their civil, political, economic, social and cultural rights in relation to gender, by:

(i) Ensuring access to international and regional treaties and instruments; national constitutions, laws and regulations; research studies, reports, data and archives; reports and information submitted by the State to international and regional bodies and mechanisms; and other relevant information to enable the exercise of the right to privacy and remedy for violation of the right;

(ii) Providing and supporting education and public information programmes to promote the right to privacy and gender inclusiveness, including relevant training of judicial and law enforcement officers and other public officials in relation to their human rights obligations regarding gender;

(b) Privacy infringements based on gender, by public or private actors, are prevented by ensuring that:

(i) The applied legal bases to prevent and penalize privacy breaches are aligned with relevant laws and treaties at the global, regional and national levels and incorporate provisions to enhance privacy, regardless of gender;

(ii) There is consistency among laws relating to privacy and gender, such as consumer safety, employment, health care, anti-discrimination and corporate regulations;

(iii) Gender is fully included in anti-discrimination laws in relation to sex characteristics;

(iv) There is recognition of the responsibility to protect and warn in relation to patterns of extraterritorial outreach of States that violate the right to privacy;

(v) Policies and procedures are up to date and adequately serve the obligation to protect and warn, and prevent surveillance and harassment based on gender, by foreign States and non-State actors against their citizens or non-citizens in their territories;

(vi) The right to privacy of all, regardless of gender, is embedded in policy development, legislative reform, service provision, regulation, programmes to support civil society organizations, and education and training;

(vii) Best practice data protection systems, such as the General Data Protection Regulation of the European Union and the Modernized Convention for the Protection of Individuals with Regard to the Processing of Personal Data of the Council of Europe (also referred to as the "Modernized Convention 108"), or better, are adopted;

(viii) There is comprehensive protection for secure digital communications, including by promoting strong encryption and anonymity-enhancing tools, products and services and resisting requests for back doors to digital communications;

(c) Gender-based infringements of privacy by State and non-State actors are eradicated, investigated, prosecuted and penalized and remedies therefor provided, whether such infringements are committed in the public or the private sphere, and that support services are established for victims;

(d) Victimization, revictimization and criminalization on the basis of gender are prevented, by:

(i) Taking action against States and non-State actors that use digital technologies to subject users to cruel and degrading treatment, extortion or blackmail;

(ii) Refraining from using laws, such as laws on vagrancy and loitering, to target certain genders;

(iii) Preventing forced labour, trafficking in persons, abuse and violence in the context of commercial sex;

(iv) Ensuring the participation of sex workers in the development of laws and policies that directly affect their lives and safety and enabling equal access for them to justice, health care and other services;

(e) Laws and policies to protect sex workers' health and safety are introduced;

(f) The identity of victims is never disclosed, except with court authorization;

(g) The death penalty is not imposed for consensual same-sex relations;

(h) Legal provisions, including those in customary, religious and indigenous laws, whether explicit or general punitive provisions, do not criminalize or penalize on the basis of gender;

(i) Access to justice and protection for complainants are provided;

(j) Redress is provided for victims whose privacy has been infringed upon owing to their gender, including in the following ways: public apology; application to expunge historical criminal convictions and records concerning consensual adult same-sex relations or cross-dressing; rehabilitation and recovery services; adequate compensation; and guarantees of non-recurrence;

(k) Research is supported into privacy and gender, including into the experiences of all members of the lesbian, gay, bisexual, transgender and intersex community, on the extent, causes (including attitudes, beliefs, customs and practices) and effects of infringements of privacy;

(l) The type, prevalence, trends and patterns of complaints concerning privacy experiences, differentiated by gender, are assessed using rights-based data-collection procedures and best practice privacy and data protection standards and law, and disaggregated, de-identified data on gender-based infringements of privacy are made publicly available.

## **B. Defence of human rights**

29. States and non-State actors should:

(a) Provide a safe and enabling environment for human rights defenders, giving particular attention to the privacy and data protection rights of those defending the rights of women and gender-nonconforming individuals and those who may be personally vulnerable on account of their gender;

(b) Meet legal obligations to protect the right to privacy and support the work of human rights defenders, regardless of their gender or that of those whose rights they are defending;

(c) Apply an intersectional approach to assessing opportunities and risks to advancing the defence of human rights for and by women and gender-nonconforming human rights defenders;

(d) Address the particular challenges that indigenous women human rights defenders face when exercising their right to participate in public life.

30. States should:

(a) Enact legislation that protects human rights defenders, especially those who are women or gender-diverse, from all forms of violence, including cyberviolence;

(b) Repeal laws that criminalize the role of human rights defenders and pass legislation to prohibit and penalize violence against them;

(c) Establish supportive legal, institutional and administrative frameworks by:

(i) Creating a strong and independent national human rights institution that promotes the defence of human rights and documents abuses and successful exercises of justice;

(ii) Ensuring access to justice, addressing violations against human rights defenders by taking a public stand against all States and non-State actors that violate defenders' rights, ceasing all attacks and threats against defenders and investigating all threats that are made;

(iii) Introducing effective policies and programmes, with specific attention given to women and gender-nonconforming defenders, that address the risks and systemic and structural discrimination and violence that they experience;

(iv) Addressing barriers to the participation of human rights defenders in public life, including the lack of identity or travel documents;

(v) Ensuring the privacy of communications of human rights defenders who engage with multilateral institutions and international and regional human rights bodies and promptly investigating any allegations of actions to the contrary;

(vi) Ensuring that online media are not used to violate the rights to privacy of human rights defenders through, for example, the publication of private contact information by a third party, identity theft or threats of sexual violence.

## **C. Indigenous peoples**

31. States and non-State actors should ensure that:

(a) Indigenous and tribal peoples enjoy the full measure of the right to privacy without hindrance or discrimination on the basis of gender, with indigeneity and gender being self-defined;

(b) The social, cultural, religious and spiritual values and practices of indigenous and tribal peoples are recognized and protected and that the nature of the gender privacy issues facing them as groups and as individuals is taken into account;

(c) The specific vulnerability of indigenous women and gender-diverse individuals, which contributes to ongoing abuses of their privacy rights, is addressed in the context of both individual and collective rights;

(d) The rights of indigenous peoples to own, control, have access to and possess data that derive from themselves, which pertain to their members, knowledge systems, customs or territories, including on gender, are recognized in a manner that is more respectful of the distinctiveness and dignity of indigenous cultures;

(e) Non-indigenous populations are educated on the privacy rights of indigenous women and gender-nonconforming individuals and that materials on such matters are integrated into school curricula and human rights training for officials who provide services to indigenous peoples, including the police, border guards, the judiciary and health and education professionals;

(f) Judicial mechanisms are the primary means by which corporate violations of privacy rights, regardless of gender, are remedied, while allocating adequate legislative attention to providing safeguards and remedies as a matter of substantive and procedural law, and that the legitimization of voluntary, private forms of remedy that do not provide effective access to justice is avoided.

## **D. Persons with disabilities**

32. States and non-State actors should ensure that:

(a) The personal, health and rehabilitation information of persons with disabilities, regardless of their gender, are protected on an equal basis with others;

(b) The systems that assist with the exercise of legal capacity by persons with disabilities fully respect those persons' right to privacy, regardless of their gender;

(c) Forced, non-consensual medical treatment, such as reproductive health procedures, including involuntary sterilization, is not undertaken;

(d) Persons with disabilities are closely consulted, including in the development and implementation of legislation, policies and other decision-making processes.

## **E. Children and young people**

33. States and non-State actors should:

(a) Recognize and apply the values and provisions of the Convention on the Rights of the Child, regardless of gender;

(b) Take all measures necessary to provide a safe environment by protecting the right to privacy to enable the child to develop freely, to provide space to reflect and deliberate on moral and ethical choices and to enable social and intimate relationships and the enjoyment of other human rights;

(c) Take all necessary measures against any practice that infringes upon any dimension of privacy and hinders or endangers a child's normal growth and physical, emotional and psychological development;

(d) Educate children and teenagers about safety on social media platforms and the Internet; protecting their privacy online; the risks of sharing intimate images and footage; and the fact that the non-consensual dissemination of such images and footage can be considered a form of gender-based violence<sup>4</sup>, and possibly, in some jurisdictions, a crime;

(e) Include in curricula, in accordance with the evolving capacity of the child, comprehensive and accurate material on sexual, biological, physical and psychological diversity and the human rights of people of all genders;

(f) Ensure that children can acquire the knowledge and skills to protect themselves and others as their sexuality develops;

(g) Undertake privacy and gender impact assessments before introducing innovations, including those intended to reduce the risks of online exploitation and abuse of children and young people, to avoid inadvertent and harmful impacts, including reducing access to gender information for lesbian, gay, bisexual, transgender and intersex young persons;

(h) Ensure, in relation to research on gender, that:

(i) Personal information of and about children, accessed through research, is used only for the purpose for which consent was given;

(ii) Children, in accordance with their evolving capacities, participate in decisions on research priorities;

(iii) Where appropriate and necessary, once the child has reached the age of legal majority, consent (or reconsent) to participate in the research should be sought;

(iv) A supportive environment is created for children participating in research;

(i) Ensure, in relation to health care, that:

(i) Health services employ trained personnel who fully respect the rights of children to privacy and non-discrimination on the basis of gender;

(ii) Rights-based, lifetime health-care protocols for intersex children and effective independent oversight are developed and implemented;

(iii) Children are informed and fully consulted regarding modifications to their sex characteristics necessary to avoid or remedy proven serious physical harm and that such modifications have the consent of the child concerned, in accordance with the evolving capacity of the child;

(iv) The confidentiality of test results is protected and not disclosed to third parties, including parents, without the child's consent;

(j) Protect the right to privacy of children who are sold, trafficked, prostituted or abused, including by avoiding the dissemination of information by which child victims are identified;

(k) Ensure that business enterprises protect and promote human rights by:

(i) Integrating child rights considerations into all corporate policies and management processes;

(ii) Developing standard processes to handle child sexual abuse material in conjunction with public authorities;

(iii) Creating safer online environments;

<sup>4</sup> In some jurisdictions even the consensual sharing of images and footage can be considered a form of gender-based violence and is possibly subject to criminal law. Without endorsing the validity of such a position, the recommendation would, in that context, need to be interpreted as meaning that educational authorities in those jurisdictions would be bound to educate children and teenagers about the legal position in that particular jurisdiction.

(iv) Educating children, parents and teachers about the responsible use of information and communications technologies (ICT);

(v) Promoting the safe use of digital technology to increase civic and social engagement.

34. States should ensure that:

(a) Birth certificates are issued for children upon birth, including for indigenous and tribal children, and that they reflect the self-defined gender identity of the parents;

(b) Court records containing sensitive details of the sex characteristics of intersex children, addresses, details of genitalia and surgical procedures, among other personal information, are not accessible by search engines;

(c) There are limitations on the authority of parents of intersex children to authorize medically unnecessary genital plastic surgery that cosmetically "normalizes" variations in the children's sex characteristics, and that the involvement of the child concerned in such decisions is ensured, in accordance with the evolving capacity of the child;

(d) Privacy protocols are adopted so that children are fully consulted and informed regarding modifications to their sex characteristics necessary to avoid or remedy proven serious physical harm, and the consent of the child concerned to such modifications is ensured, in accordance with the evolving capacity of the child;

(e) Gender recognition procedures for minors are compatible with human rights and:

- (i) Are swift, transparent and based on self-determination;
- (ii) Have the best interest of the child as the primary consideration;
- (iii) Are not medicalized;
- (iv) Protect the child's identity;

(f) They take measures in relation to the rights of the child in HIV/AIDS contexts in order to:

(i) Implement child-centred and rights-based national and local HIV/AIDSrelated policies, action plans, strategies and programmes;

(ii) Allocate financial, technical and human resources, insofar as possible, to support national and community-based action that, where appropriate, is within the framework of international cooperation;

(iii) Expressly prohibit discrimination based on real or perceived HIV/AIDS status;

(g) They include HIV/AIDS action plans, strategies, policies and programmes in the work of national mechanisms responsible for monitoring and coordinating children's rights and provide a procedure for complaints of neglect or violation of those rights in relation to HIV/AIDS;

(h) They ensure that HIV-related data collections and evaluations adequately cover children, are disaggregated by age and gender and include, insofar as possible, children belonging to vulnerable groups and those in need of special protection;

(i) They enable all children to:

(i) Obtain, in a manner that protects their privacy, adequate information related to HIV/AIDS prevention and care through formal educational opportunities and childtargeted media and informal channels, such as those targeting street children, institutionalized children or children living in difficult circumstances;

(ii) Have private access to voluntary, confidential HIV counselling, testing and test results;

(j) They guarantee the confidentiality and security of information concerning:

(i) A child's involvement in justice processes, through privacy standards and protocols, including closed court proceedings;

(ii) Child victims of sexual and economic exploitation, trafficking and sale;

(iii) Participants in services designed for those subjected to such treatment;

(k) They ensure that child pornography laws are not susceptible to being used to compound the negative social stigma already disproportionately borne by those whose sexualized self-representations are distributed beyond their intended recipient and that discourage reporting and prosecution of the exploitative and abusive redistributions that the statute was enacted to address.

## **F. Gender identity and legal recognition**

35. States and non-State actors should:

(a) Facilitate formal recognition of identity, regardless of an individual's gender, by ensuring that:

(i) Requirements for information on sex or gender are relevant, reasonable and necessary, as required by law for a legitimate purpose in the circumstances in which it is sought, and that they respect everyone's right to self-determine their name and gender;

(ii) Changes to the name or gender marker are not disclosed without the prior, free and informed consent of the person concerned, unless ordered by a court;

(b) Protect the data of individuals who have changed their sex and/or gender on official records by:

(i) Protecting their history of changes of sex and/or gender or name from interference;

(ii) Ensuring that such data are recorded and accessed only when the history is relevant to decision-making;

- (iii) Requiring robust security controls;
- (iv) De-identifying or destroying such information when no longer required;

36. States should ensure that:

(a) Government digital identity programmes are not used to monitor and enforce societal gender norms or for purposes that are not lawful, necessary or proportionate in a democratic society;

(b) Official identity documents include only relevant, reasonable and necessary personal information relating to sex and gender, as required by law for a legitimate purpose;

(c) Comprehensive legislation is enacted and administrative and technological systems are implemented to establish a swift, transparent and accessible mechanism, based on self-determination by the person, that legally recognizes and affirms each person's chosen name and self-defined gender identity;

(d) No eligibility criteria, such as surgical, medical or psychological interventions, psychomedical diagnosis, minimum or maximum ages, economic status, civic records, immigration, health, marital or parental status or any other third-party opinion, are prerequisites for or barriers to changing one's name, legal sex or gender;

(e) A multiplicity of gender marker options is made available while moving to end the registration of sex and gender in identity documents, such as birth certificates, identification cards, passports and drivers' licences;

(f) Robust privacy protections are provided for the legal recognition of name changes in identity documents and, where there is a requirement to publicly report such changes, including by online means, options are provided for affected individuals to seek the non-release of public records, judicial notices and decisions concerning name or gender identity changes;

(g) Gender-appropriate terms and titles are used in forms and personal records, policies are developed to assist staff in managing relationships with members of the intersex, transgender and/or gender-diverse community and guidance and training are provided on rights and procedures for name and gender identity changes;

(h) Clear and publicly accessible information is provided on how sex and gender information can be changed on personal records.

## **G. Civic, recreational and cultural activities**

37. States and non-State actors should:

(a) Review their legal frameworks and policies to facilitate the inclusion of all genders and the protection of their privacy in the enjoyment of their cultural and civic rights;

(b) Facilitate the ability of all individuals, regardless of gender, to be able to participate fully in civic and public life and to have reasonable expectations that their privacy will not be violated by such participation and confidence that there is meaningful redress for, protection from and consequences for perpetrators of such privacy breaches;

(c) Implement affirmative action programmes to prevent infringements of privacy that restrict public and political participation;

(d) Remove all:

(i) Barriers that exclude women and gender-nonconforming individuals from public spaces, such as stadiums, mixed concerts, cafés, places of worship and heritage sites;

- (ii) Gender-specific regulation of clothing to be worn in public;
- (iii) Prohibition of cross-dressing in public places;

(e) Design and maintain public spaces and facilities with gender needs and responsibilities in mind, including well-lit pedestrian walkways, family restrooms, public toilets and sanitation facilities with sufficient privacy to enable safety when attending to basic human needs;

(f) Ensure the protection of members of the lesbian, gay, bisexual, transgender and intersex community from exclusion, abuse and shaming in public spaces by sending strong messages of inclusion and official support;

(g) Ensure that information contained in mandatory notifications to public authorities of the use of public spaces is held securely and that any personal information, in particular concerning sex and gender, is protected from disclosure;

(h) Implement comprehensive laws and policies to prevent and respond to genderbased violence in public spaces, including on public transport and in educational institutions, whether perpetrated by State agents or private persons;

(i) Train officials on the concept of inclusive public spaces and respect for the dignity of users of such places, regardless of gender;

(j) Recognize that some indigenous or cultural traditions, languages, rituals, festivals and sites have gender significance where, when consistent with applicable international human rights law, privacy is expected;

(k) Mainstream privacy and gender perspectives into all functions, including the handling of complaints and human rights education, and encourage gender diversity among leadership and staff teams;

(l) Make sure that sports organizations integrate the Yogyakarta Principles and the update thereto of 2017 and all relevant human rights norms and standards into their policies and practices, in particular by:

(i) Ensuring that all individuals can participate in sport in line with the gender with which they identify, subject only to reasonable, proportionate and non-arbitrary requirements and without gender-based discrimination;

(ii) Installing appropriate changing rooms and increasing awareness in the sporting community of privacy and any anti-discrimination laws for persons of diverse sexual orientations, gender identities, gender expressions and sex characteristics;

(iii) Removing, and refraining from introducing, policies that force, coerce or otherwise pressure women athletes into undergoing unnecessary and harmful medical examinations, testing and/or procedures in order to participate as women athletes;

(iv) Taking measures to encourage the general public to respect diversity based on gender in sports and to eliminate privacy incursions;

(m) Ensure, when it is a matter of important public interest to enquire into past events arising from or associated with infringements of privacy on the basis of gender, that:

(i) The right to privacy of individuals as being necessary, proportionate and lawful is protected;

(ii) There is effective access to information concerning the facts related to violations, including archived material;

(iii) Individuals have full access to their complete health histories;

(iv) Independent and impartial investigation, remedies, redress and reparation, including, where appropriate, psychological support and restorative treatments, are available;

(v) Documentary evidence of infringements of the right to privacy based on gender is preserved;

(n) Prohibit the use of mass surveillance techniques for indiscriminate genderbased surveillance of those exercising the right to peaceful assembly and association, in physical spaces and online;

(o) Protect the privacy of those involved in advocacy for and on behalf of individuals and communities subject to gender-based infringements of privacy;

(p) Design and implement a protocol for the military service of lesbian, gay, bisexual, transgender and intersex individuals in which their gender identities are identified, military service is enabled and there is protection from discrimination and violence.

## **H. Housing and education**

38. States and non-State actors should:

(a) Ensure that:

(i) Housing and educational programmes protect the privacy of all, regardless of gender, age, indigeneity or disability, among other factors;

(ii) These programmes do not discriminate on the basis of gender;

(b) Establish privacy-respectful and gender-inclusive policies, programmes and services that address issues such as single-sex facilities, toilets and changing rooms and clothing in educational institutions, introduce gender-appropriate official documents and records and reform discriminatory education policies, regulations, curriculums and teaching materials and practices;

(c) Take action to prevent, reduce and penalize prejudice and violence, such as bullying, harassment and exclusion based on gender;

(d) Raise public awareness through education programmes that provide comprehensive, accurate information regarding sexuality and diverse gender identities and the right to privacy and implement safety and support measures;

(e) Conduct studies and collect statistical data, where appropriate and necessary, disaggregated by gender, to inform policy development.

## **I. Physical autonomy, reproductive rights and well-being**

39. States and non-State actors should:

(a) Recognize that:

(i) The ability of women to exercise control of their reproductive capacity is central to their lives and dignity and that such control enables them to participate in and contribute to the economic and social life of their societies;

(ii) A woman's decision to voluntarily terminate her pregnancy is not a matter of public or general interest;

(iii) A woman's right to privacy cannot be violated by mandating the disclosure of the name and particulars of the biological father of her child or by requiring health personnel to report women who have undergone terminations;

(iv) Violations of the right to privacy include forced and coercive medical interventions and therapies, as well as traditional practices such as female genital mutilation;

(b) Ensure:

(i) The elimination of all forms of sexual and reproductive violence on the basis of gender, including forced marriage, so-called corrective rape and forced pregnancy;

(ii) Access, including for minors, to safe, affordable and effective contraceptives and to information and education on family planning, sexual and reproductive health and privacy;

(iii) The decriminalization of abortion, with provisions for a declaration by the medical practitioner of conscientious objection, with the option to refer a pregnant woman to a government health service, with her health records, for assistance;

(iv) Confidential treatment by health professionals and personnel who receive requests for the voluntary termination of pregnancy and respect for women's right to privacy and dignity;

(c) Prevent the disclosure of personal health data related to reproductive health, sexual orientation, gender identity, gender expression and sex characteristics, such as genderaffirming treatment, without the free, prior and informed consent of the person;

(d) Guarantee and protect the rights of everyone, including all children, to bodily and mental integrity, autonomy and self-determination, by prohibiting any practice and repealing any laws and policies so that no one is subjected to invasive or irreversible medical procedures that modify sex characteristics, including female genital mutilation, forced genital-normalizing surgery, involuntary sterilization, unethical experimentation, medical display and so-called reparative or conversion therapies, without free, prior and informed consent, unless necessary to avoid serious, urgent and irreparable harm to that person;

(e) Address stigma, discrimination and stereotypes based on gender and combat the use of gender stereotypes and other social, religious and cultural rationales to justify modifications to sex characteristics, including of children.

40. States should:

(a) Prohibit the use of vaginal ("two-finger" tests), anal and genital examinations in legal and administrative proceedings and criminal prosecutions unless required by law as being relevant, reasonable and necessary for a legitimate purpose;

(b) Repeal laws that deny individuals the opportunity to undergo surgical or other procedures to align physically with their gender identity;

(c) Ensure that legal provisions, regulations or administrative procedures relating to the donation of biological material, such as blood, gametes, embryos, organs, cells or other tissues, contain privacy provisions with exemptions and exceptions as lawfully provided;

(d) Ensure the inclusion of privacy rights and responsibilities in material relating to gender in health curricula and continuing professional development programmes;

(e) Repeal laws that:

(i) Criminalize consensual sexual activity between adults, including people of the same sex;

(ii) Prohibit the expression of gender identity;

(f) Release people held in pretrial detention or on the basis of a criminal sentence, if their detention is related to consensual sexual activity between people over the age of consent or to their gender identity.

## **J. Health care**

41. States and non-State actors should:

(a) Implement the provisions of the Special Rapporteur's recommendation on the use of health-related data, in particular by:

(i) Taking all administrative and other measures necessary to manage healthrelated data so as to ensure enjoyment of the right to health care, confidentially and regardless of gender;

(ii) Ensuring that free, prior and informed consent forms the basis of the provision of health care;

(iii) Not using health-related data concerning gender to restrict the enjoyment of human rights in either health or non-health contexts, unless medically indicated, as established by evidence and/or in compliance with a legal requirement;

(iv) Including provision for non-binary classifications in gender-marker categories in health records and health-related data;

(v) Taking all measures necessary to ensure that systems, procedures, records and data collection reflect all medical or other treatments, for example on intersex children or gender transitions;

(vi) Ensuring that health-related data systems for recording and processing familial relationships reflect, for example, same-sex partner recognition and, in the case of children, the self-defined gender of their parents, guardians or other family members;

(vii) Enabling access to high-quality information relevant to gender health-care needs, as well as full access to health records on the basis of the best interests of the individual and not subordinated to the claimed interest of the State or of the institution, or its employees, contractors or agents;

(viii) Ensuring that a person or an entity making a decision concerning the healthrelated data of an individual does so in a way that is consistent with that person's gender, in the person's best interests and with the person's knowledge and consent;

(ix) Providing particular protection of the health-related data of individuals subject to reports of notifiable diseases, such as sexually transmitted infections, so as not to subject individuals to opprobrium or discrimination;

(x) Reporting notifiable diseases with the ethical consideration of advising the persons concerned, regardless of their gender, while providing suitable and specific measures to safeguard their rights and freedoms;

(xi) Reviewing medical classifications to eradicate the conception of some forms of sexual orientation or gender identities as pathologies;

(b) Ensure that an individual's gender, whether in combination with age, disability, indigeneity or other factors, does not obviate application of the recommendation on the use of health-related data and does not nullify decisions made by individuals in relation to their health care or the use of their health-related data;

(c) Protect everyone from infringements of the right to privacy on the basis of gender in health-care settings, including through the design of facilities, the management of health-care services, staff practices and data processing;

(d) Remove barriers to access to health services by introducing, for example, socalled safe access zones around facilities, including clinics for sexually transmitted infections and women's health centres;

(e) Refrain from censoring, withholding or intentionally misrepresenting healthrelated information, including sexual education and information;

(f) Recognize the:

(i) Need for safe and private access, regardless of gender, to basic services such as adequate public sanitation facilities in schools, workplaces, public services and places of detention to ensure the safety of women, young girls and intersex and gender-diverse individuals;

(ii) Need for culturally gender-specific health care for communities such as indigenous and tribal women.

## **K. Data analytics**

42. States and non-State actors should ensure the highest attainable standard of data protection for all individuals, regardless of their gender, by:

(a) Adopting best practice data protection laws and regulation, including the establishment of a well-resourced, independent privacy or data regulator with appropriate powers and public reporting mechanisms;

(b) Developing systems for the effective protection and use of data in ways that benefit society and all individuals, regardless of their gender;

(c) Regularly engaging with the public to develop policies relating to data terminology, definitions and sensitivities associated with the intersex, transgender and gender-diverse communities;

(d) Reviewing legislative, regulatory or policy requirements relating to the collection of sex and/or gender information and amending them as required to ensure compliance with best practice data protection laws;

(e) Collecting and maintaining the data, disaggregated by sex and gender, necessary for the ongoing monitoring of gender equality and in accordance with best standards of data protection law;

(f) Removing biases in existing data sets through the identification of incomplete or non-existent gender categories;

(g) Employing the principles of data minimization, necessity and proportionality when aggregating gender data so that only the minimum necessary level of detail is included in a data set to achieve the intended positive outcome of the use of the data;

(h) Taking appropriate and necessary measures to guarantee the confidentiality and security of the personal data of individuals vulnerable on account of their gender, such as same-sex couples;

(i) Prohibiting the release of unit record data on sex or gender as open data;

(j) Protecting personal information relating to sex and gender through regular vulnerability assessments of information management systems and regular training for staff on data privacy and data security;

(k) Using privacy impact assessments and other mechanisms to ensure that data analytics do not result in inferences being drawn about individuals or groups according to their gender, which could lead to discrimination.

## **L. Online violence**

43. States and non-State actors should counter gender-targeted violence using privacyintrusive and technologically facilitated forms of abuse based on gender, by:

(a) Providing education, outreach and gender-sensitive training for Internet users on online violence in schools and communities;

(b) Including advocates, victims and support services in the design of strategies to counter technologically facilitated violence;

(c) Providing training and technical expertise for front-line staff, including dedicated hotlines and law enforcement support;

(d) Establishing data protection-compliant reporting of the incidence and outcomes of service interventions.

44. States should:

(a) Recognize online-facilitated violence targeted by gender as a human rights violation and form of discrimination and take measures to apply international human rights instruments, in conjunction with national laws, to prevent and mitigate its occurrence;

(b) Review, strengthen and devise policies and legal and regulatory privacy and data protection frameworks to address gender-based violence in online and offline contexts, in particular technologically interconnected violence, including smart home technologies;

(c) Reform criminal and civil laws to address technologically facilitated violence and establish criminal and civil causes of action to allow victims to pursue remedies with adequate protection of their privacy to avoid secondary victimization and to provide them with greater control;

(d) Allow victims to obtain orders of protection (e.g., restraining orders) in family or civil courts to prevent abusers from posting or sharing intimate images and footage without their consent or engaging in other unlawful harassment;

(e) Determine the rights or claims of perpetrators or alleged perpetrators during and after judicial proceedings with respect to privacy, in the light of a victim's or child's human rights to life and physical and sexual and psychological integrity, and guided by the principle of the best interests of the child;

(f) Collaborate with civil society organizations, technology companies, national human rights institutions, victims and activists to develop strategies, including legislation to prevent and mitigate online violence based on gender, technical support, counselling, legal guides, referral information and advice services;

(g) Promote and provide educational resources and training for magistrates, lawyers, the police, front-line workers and service providers on technologically facilitated gender violence;

(h) Develop specialized, clear, efficient and available protocols for law enforcement officials concerning online violence to improve existing investigative techniques and models with, for example, liaison officers trained to investigate and respond to such assaults using leading international practices;

(i) Increase prevention programmes to teach respect, boundaries and appropriate behaviour, with practical booklets, seminars and training for front-line agencies, survivors, practitioners, policymakers and technologists on technologically facilitated abuse and the safety and privacy of those experiencing domestic violence and sexualized violence;

(j) Explore, where appropriate and necessary, third-party liability options for platforms, including social media networks, that permit the redistribution of private images and the continuation of harassment;

(k) Sustainably fund service providers for continuing service provision, training and resource development;

(l) Introduce inclusive, appropriate, gender-sensitive and lawful data practices and ensure that information collected about violence targeted at certain genders is accurate, useful for policymakers and published;

(m) Require privacy and data protection regulators and regulators in related areas to regularly address, with civil society, the gender aspects of privacy in their work and to publicly report on it;

(n) Protect the personal data of gender-nonconforming individuals, such as transgender and intersex persons, in court documentation, including by having decisions revealing the personal data of transgender persons suppressed upon request, provided that that does not compromise the integrity of judicial processes and proceedings;

(o) Prohibit and criminalize the non-consensual distribution of intimate images in digital and offline spaces, with legislation encompassing all elements of this type of abuse, including by:

(i) Not limiting the scope to current or former intimate partners or to binary genders;

(ii) Criminalizing the distribution or resharing of such images;

(iii) Protecting victims in images depicting sexual acts or sexual conduct, not just nudity, and in so-called deep fakes;

(iv) Making it illegal to threaten to disseminate non-consensual intimate images;

(v) Enabling victims to request a court order to destroy harmful content, in addition to an interim order for perpetrators to promptly cease circulating the material pending the resolution of the legal case, in collaboration with Internet intermediaries;

(vi) Undertaking investigations in a timely and robust manner and enforcing penalties for those convicted of such abuse;

(p) Provide civil remedies and ensure that they and criminal prosecutions do not entail violations of privacy and revictimization that provide disincentives to victims to seek progress on such matters;

(q) Take measures to protect persons in conflict-affected areas who are vulnerable as a result of their gender from abuse of their right to privacy arising from sexual harassment and gender-based violence by business enterprises.

## **M. Digital technologies and online digital platforms**

45. States and non-State actors should:

(a) Recognize that for some people their gender means they have a greater dependency upon ICT to fully develop their social, educational and other capacities;

(b) Ensure, regardless of gender, that:

(i) Everyone has the right to access and use ICT, including the Internet, for private communications and other positive uses;

(ii) All necessary legislative, administrative, technical and other measures are taken, in accordance with relevant international standards and human rights law, in consultation with stakeholders, to prevent, remedy and eliminate online hate speech, harassment and technology-related violence targeted by gender and that such efforts ensure private sector accountability;

(c) Adopt best practice privacy and data protection standards for all individuals, regardless of gender, to enable them to control their personal information, in particular in relation to sex and gender;

(d) Implement the following in the design, construction and operation of products and all services, including profiling and digital welfare services:

(i) Gender-equality and privacy protection principles;

(ii) Privacy risk management and governance mechanisms, such as privacy by design/default approaches and gender impact analyses;

(e) Minimize and restrict data processing relating to gender and ensure that data collected, derived or inferred on gender are in accordance with international human rights law and are stored;

(f) Provide easy access to data profiles and monitor for gender bias through, for example, algorithmic auditing;

(g) Introduce provisions to enable individuals, regardless of their gender, to remove personal information;

(h) Establish guidelines on the development of artificial intelligence, incorporating gender, the right to privacy and principles of data protection;

(i) Engage more women and lesbian, gay, bisexual, transgender and intersex persons in the design, development and regulation of digital technologies to develop privacyenhancing technologies and reduce risks of gender-based infringements of privacy;

(j) Take all legal, administrative and other measures necessary to fully respect and recognize individuals' self-defined gender identity, and update privacy statements and redesign tools, systems and processes accordingly;

(k) Utilize strong encryption technologies to ensure the privacy of communications and resist requests for user data that do not comply with international human rights standards of lawfulness, proportionality and necessity;

(l) Adopt strong policies, procedures and complaint mechanisms for reporting and requesting the removal of harmful content from social media and disseminate such policies and procedures prominently in local languages;

(m) Provide training, in particular for front-line staff, on privacy, gender and measures taken to end infringements of privacy within business operations;

(n) Educate users on digital security and technological assistance, such as support services, information applications, design choices, terms of service and tools for reporting violations;

(o) Report complaints of online violence, by type and number of cases by country, and lawful actions to protect the right to freedom of expression that were taken to respond to incidents of online harassment based on gender;

(p) Support research into digital technologies and the experiences of women and the lesbian, gay, bisexual, transgender and intersex community on the extent, causes and effects of infringements of privacy and the harms arising, and on the effectiveness of measures to prevent, eradicate, prosecute and provide reparation for such harm.

46. Business enterprises should:

(a) Implement the Guiding Principles on Business and Human Rights and the accompanying guidance on gender to respect the human rights of all persons affected by their practices;

(b) Exercise human rights due diligence to identify, prevent, mitigate and address violations of the rights to privacy and non-discrimination based on gender, including through:

(i) Human rights impact assessments that incorporate the rights to privacy and gender non-discrimination, when developing or modifying their products and services, and include consultation with civil society organizations and other experts and validation by an accredited external third party with expertise in the area of privacy;

(ii) Integration of the findings of impact assessments, by:

a. Providing training and guidelines to managers, employees and others, including contractors;

b. Adopting policies and procedures setting out how the company will respond to restrictions on communications or access to content;

c. Establishing early warning systems within business processes to identify risks with regard to privacy and gender rights and respond in a timely fashion;

d. Challenging requests that unduly infringe upon the right to privacy;

e. Supporting research and development into appropriate technological solutions to online harassment, abuse and misogyny, including tools to detect and identify State-linked accounts and bots;

f. Monitoring specific concerns related to privacy and gender;

(c) Establish codes of conduct and terms of services to manage social media pages that promote gender violence, harmful gender stereotypes and the sharing of intimate images without consent;

(d) Take effective measures to ensure the transparency of their policies and practices, including the application of terms of service and computation-based review processes, and respect due process guarantees;

(e) Publish regular information on their official websites, unless contravening a necessary and proportionate law, regarding the legal basis of requests made by Governments and other third parties, the number or percentage of requests complied with and the content or accounts restricted or removed under the company's policies and applicable requirements;

(f) Introduce independent oversight mechanisms to monitor the outcome of content moderation decisions;

(g) Establish, in meaningful consultation with the communities affected, clearly available, accessible and effective operational-level grievance mechanisms;

(h) Collaborate with Governments and civil society to develop technology that promotes and strengthens human rights.

47. States should:

(a) Take all steps necessary to ensure that all State policies, legislation and regulations are aimed at preventing, investigating, penalizing and providing redress for all forms of gender-based infringements of privacy committed by business enterprises operating within their territory or jurisdiction;

(b) Encourage business enterprises, through effective incentives and disincentives, to integrate a gender perspective, the present recommendation and the guidance on gender accompanying the Guiding Principles on Business and Human Rights into their operations;

(c) Establish strong, independent oversight of the performance of business enterprises in the area of privacy and gender.

## **N. Work and employment**

48. States and non-State actors should:

(a) Respect human dignity, privacy and protect sex and gender information in the processing of personal data for work and employment purposes;

(b) Allow the free development of the personality of all employees, regardless of their gender, by:

(i) Ensuring all safeguards for workers' right to privacy and protection of their personal data;

(ii) Advising and consulting workers and their representatives at reasonable intervals and without excessive delay as to what data are being collected on them, the processing of such data and the right to have access to, rectify and delete inaccurate data collected about them and derived from work processes;

(c) Ensure that communications are:

(i) Lawful and do not infringe upon privacy and discriminate against or harass any workers on the basis of their gender;

(ii) Timely, in an intelligible form and inclusive of all relevant information on what is being collected, its origins, its purpose or purposes, retention periods, workers' rights of access and rectification, how those rights may be exercised and any other information to ensure transparent processing;

(d) Inform workers clearly and fully before the introduction of information systems;

(e) Ensure that:

(i) Any use of data analytics and predictive technologies is in accordance with relevant privacy and data protection laws and standards;

(ii) Data-predictive technologies, including those that use health data, do not discriminate by gender;

(iii) Technology that reveals workers' location is introduced only if necessary to achieve employers' legitimate purpose or purposes, such as health and safety, and does not lead to continuous monitoring of workers;

(iv) Monitoring is only an indirect consequence of protecting and enhancing operations, health and safety;

(v) The processing of biometric data is undertaken only if there are no other less intrusive means available and only if accompanied by appropriate safeguards, including scientifically recognized methods, and strict security and proportionality protocols;

(f) Develop appropriate measures to ensure that enterprise-wide practices comply with privacy principles and lawful obligations relating to data processing for employment purposes, regardless of gender, including by:

(i) Limiting data collection to what is necessary to achieve the objectives of the collection in question;

(ii) Conducting privacy impact assessments, as in the case of potential profiling or decisions taken by means of automated systems;

(iii) Consulting workers on possible infringements of their right to privacy based on gender;

(iv) Only providing personal data concerning gender to workers' representatives, consistent with national law and practice or the terms of collective agreements, to the extent that such data are necessary to allow proper representation of workers' interests or to meet obligations in collective agreements;

(v) Conducting investigations of employees with due regard to privacy and data protection laws;

(vi) Ensuring confidential procedures for appealing against wrongful dismissal based on gender.

49. States should ensure that employee records are not exempt from privacy and data protection regulation.

## **O. Social security protection**

50. States and non-State actors should recognize that all individuals, regardless of their gender, have the right to social security, the right to privacy in relation to receipt of that protection and the right to lawful processing of their personal information collected as part of the process of receiving such protection.

51. States should ensure that:

(a) All necessary legislative, administrative and other measures are taken to ensure that social security programmes and strategies enable the development of the personality and promote social and economic inclusion regardless of gender, without undue intrusion into the personal circumstances of recipients;

(b) Regulation of the receipt of social security benefits and assistance incorporates a human rights framework that stresses privacy, dignity, choice, self-respect, autonomy and self-determination, is grounded in law and is conducted transparently;

(c) The digitalization of welfare arrangements is accompanied by careful and transparent consideration of gender impacts, with programmes designed to promote and teach prerequisite digital skills; reasonable access to necessary equipment and effective online access; genuine non-digital options to gain access to benefits; consultation with intended users; and participatory evaluation;

(d) Effective action is taken to prevent societal biases relating to gender from being embedded through automated decision-making in social welfare programmes and systems, including predicting risk;

(e) Record system arrangements and data-collection practices, including crossmatching, data sharing and cross-verification across data sets underlying the creation, auditing and maintenance of data relating to gender are compliant with best practice data protection regulation;

(f) Access is provided to effective appeal mechanisms and remedies for exclusion from social security programmes or targeting and harassment based on gender;

(g) Where the provision of benefit and social assistance systems involves private entities, measures are taken to make sure that:

(i) Gender privacy protections are included in such contracts and contain remedial measures for breaches of such provisions;

(ii) No conflicts exist between the public interests that the systems serve and the private interests of corporations and their owners.

## **P. Security and surveillance**

52. States and non-State actors should:

(a) Protect the privacy of digital communications and enjoyment of the right to privacy by all individuals, regardless of their gender, by promoting tools such as encryption;

(b) Ensure that restrictions to the right to privacy, including through mass or targeted surveillance, requests for personal data or limitations on the use of encryption, pseudonymity and anonymity tools:

(i) Are on a case-specific basis;

(ii) Do not discriminate on the basis of gender or other factors, such as indigeneity;

(iii) Are reasonable, necessary and proportionate as required by law for a legitimate purpose and ordered only by a court.

53. States should:

(a) Amend cybercrime, surveillance and counter-terrorism laws for compliance with international human rights norms and standards applicable to the rights to privacy, freedom of opinion and expression, peaceful assembly and association;

(b) Enshrine the principles of gender non-discrimination in the design and implementation of all surveillance;

(c) Review, repeal and prohibit legislation that facilitates State surveillance designed to monitor gender-nonconforming communities;

(d) Ensure that the processing of personal data for profiling is consistent with relevant human rights standards and data protection;

(e) Provide legal protections against non-consensual, predatory, commercial surveillance that enables profiling, monitoring and marketing at a micro level and infringes upon privacy according to gender using big data techniques, such as mobile geofencing and geospatial location markers;

(f) Renounce the use of discriminatory, inaccurate, disproportionate or unevidenced gender stereotypes for profiling and promote human rights training to prevent and mitigate any stigma, harassment and discrimination arising from such profiling practices;

(g) Implement policies and procedures that specifically address gender and privacy implications of potentially sensitive closed-circuit television footage, including relevant training for data controllers and those who can access the footage;

(h) Implement data protection and security protocols to prevent the abuse, redistribution or degrading treatment of captured closed-circuit television images, including privacy impact and risk assessments and governance protocols with embargoes on face recognition or other algorithmic analyses of captured surveillance, without judicial permission and independent oversight;

(i) Establish all appropriate measures to oversee, investigate, document and monitor the impacts of surveillance infringements of privacy based on gender, including public reporting;

(j) Penalize egregious image-based abuse by law enforcement officials by internal and external disciplinary means, create protocols for victim redress and maintain communication with victims;

(k) Ensure that counter-terrorism measures do not disproportionately or unnecessarily affect women and lesbian, gay, bisexual, transgender and intersex asylum seekers, refugees and immigrants.

## **Q. Detention**

54. States and non-State actors should:

(a) Implement:

(i) Privacy policies relating to the placement and treatment of persons deprived of their liberty that reflect the needs and rights of persons of all genders, including sexual orientations, gender identities, gender expressions and sex characteristics;

(ii) Policies to combat violence, discrimination and other harm arising from gender-based infringements of privacy faced by people deprived of their liberty, including placement, body or other searches, items expressing gender or access to and continuation of gender-affirming treatment and health care, and so-called protective solitary confinement;

(iii) Programmes that address the gender-specific needs of indigenous people and their cultural, spiritual and religious requirements and others, such as individuals with disabilities;

(b) Ensure the effective independent oversight of detention facilities, both public and private, that addresses protection of the right to privacy, regardless of gender.

## **R. Asylum seekers**

55. States should ensure that asylum seekers are protected from infringements of their privacy committed on the grounds of gender, including during reception and the determination of their claims, by:

(a) Recording information about a person's sex and gender only where it is lawful, reasonable, necessary and proportionate;

(b) Storing such information securely;

(c) Prohibiting its release to anyone not directly involved in the refugee determination process;

(d) Accepting, as the starting point for consideration of an asylum claim, the selfidentified gender of the asylum seeker;

(e) Eschewing inappropriate, invasive, unnecessary or coercive medical or psychological testing or unlawfully obtained personal information to assess an asylum seeker's self-declared gender;

(f) Providing privacy protections for the health-related information of asylum seekers, in particular in relation to gender-sensitive information, such as reproductive health, HIV information and therapy, hormonal or other therapy, and gender-affirming treatment;

(g) Establishing, implementing and monitoring privacy guidelines;

(h) Providing training on taking privacy and gender into consideration for agents involved in determining refugee status and managing reception conditions.
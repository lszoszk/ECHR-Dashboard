![](_page_0_Picture_2.jpeg)

4 September 2013

Original: English

**Sixty-eighth session** Item 69 (b) of the provisional agenda\* **Promotion and protection of human rights: human rights questions, including alternative approaches for improving the effective enjoyment of human rights and fundamental freedoms** 

# **Promotion and protection of the right to freedom of opinion and expression**

## **Note by the Secretary-General**

 The Secretary-General has the honour to transmit to the General Assembly the report of the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression, Frank La Rue, submitted in accordance with Human Rights Council resolution [16/4.](http://undocs.org/A/RES/16/4)

\* [A/68/150](http://undocs.org/A/68/150).

![](_page_0_Picture_10.jpeg)

![](_page_0_Picture_11.jpeg)

# **Report of the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression**

#### *Summary*

 In the present report, the Special Rapporteur focuses on the right to access information. He describes how the right is established through international human rights law, emphasizing its interrelationships with the right to truth. Taking into account that framework, he discusses the permissible limitations to access to information, in particular the exceptions justified by national security concerns. He describes principles that may guide the design and implementation of laws on access to information and examines common obstacles noted in existing experience. He makes recommendations for the better translation of international human rights standards into national laws and practices that promote access to information.

## **I. Introduction**

1. The present report is submitted by the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression, pursuant to Human Rights Council resolution [16/4.](http://undocs.org/A/RES/16/4) It is focused on the right to access information and its relationship with the right to truth.

2. Global and regional human rights standards secure not only the right freely to impart information but also the right freely to seek and receive it as part of freedom of expression. The right to access information is one of the central components of the right to freedom of opinion and expression, as established by the Universal Declaration of Human Rights (art. 19), the International Covenant on Civil and Political Rights (art. 19 (2)) and regional human rights treaties.

3. Obstacles to access to information can undermine the enjoyment of both civil and political rights, in addition to economic, social and cultural rights. Core requirements for democratic governance, such as transparency, the accountability of public authorities or the promotion of participatory decision-making processes, are practically unattainable without adequate access to information. Combating and responding to corruption, for example, require the adoption of procedures and regulations that allow members of the public to obtain information on the organization, functioning and decision-making processes of its public administration.<sup>1</sup> In this sense, global commitments to promote development also reflect the centrality of access to information; for example, in its recent report ([A/67/890](http://undocs.org/A/67/890), annex), the High-level Panel of Eminent Persons on the Post-2015 Development Agenda calls for a transparency revolution.

4. National legal frameworks increasingly reflect this understanding and protect this right by establishing the right to government-held information, as well as procedures for the public to request and receive it. Over the past two decades, new instruments protecting the right to information have been adopted in more than 50 countries. This trend has often been a consequence of recent democratic transitions and certainly responds to the much more active participation of civil society organizations in public life around the world.

5. In the present report, particular attention is paid to the relationship between the right to access information and the right to truth. Elucidating past and present human rights violations often requires the disclosure of information held by a multitude of State entities. Ultimately, ensuring access to information is a first step in the promotion of justice and reparation, in particular in the aftermath of periods of authoritarianism. In the sections below, the Special Rapporteur describes how the rights to truth and to access information have been established through international human rights law and jurisprudence. Based on this same framework, he also addresses permissible limitations to the right to access information, including limitations aimed at the protection of national security.

6. In addition, in view of recent experience with national legislation on the right to information, the Special Rapporteur recalls basic principles developed to guide the design and implementation of national laws on the right to information and examines some common obstacles to the public's access to information. He

<sup>1</sup> See, for example, article 10 of the United Nations Convention against Corruption (General Assembly resolution 58/4, annex).

concludes by providing recommendations for the better translation of international human rights standards into the emerging norms and practices that promote access to information.

## **II. Activities of the Special Rapporteur**

7. During the reporting period, the Special Rapporteur continued to participate in national and international events relating to the right to freedom of opinion and expression. In June 2013, he presented his annual report to the Human Rights Council ([A/HRC/23/40](http://undocs.org/A/HRC/23/40) and Corr.1), in which he addressed the impact of mass surveillance of communications on the rights to privacy and freedom of expression.

8. The Special Rapporteur undertook a mission to Montenegro from 11 to 17 June and a mission to the former Yugoslav Republic of Macedonia from 18 to 21 June. His preliminary findings on both visits are available in the end-of-mission press statements; a full report will be submitted to the Human Rights Council in 2014. The Special Rapporteur was invited by the Government of Indonesia to visit that country in January 2013 but, only a few days before its agreed start, the authorities requested that the visit should be postponed. The Special Rapporteur regrets that, at the time of preparation of the present report, he has not received a response to his request for new dates. In 2011, the Government of Pakistan also extended an invitation to visit the country but dates for the visit have still not been agreed upon. The Government of Italy has invited the Special Rapporteur to visit the country in the first half of November 2013.

9. At the time of submission of the present report, the following States had not yet responded to requests for visits by the Special Rapporteur: Iran (Islamic Republic of) (visit requested in February 2010); Sri Lanka (visit requested in June 2009); Thailand (visit requested in 2012); Uganda (visit requested in May 2011); and Venezuela (Bolivarian Republic of) (visit requested in 2003 and in 2009).

10. In May, the Special Rapporteur participated in the World Press Freedom Day International Conference 2013, held in San José, and used the occasion to hold working meetings on mechanisms for the protection of journalists in Brazil, Colombia, Honduras and Mexico. Also in May, he visited Uruguay to participate in discussions on the new legislation on audiovisual services. In July, the Special Rapporteur participated in a public forum organized by the New America Foundation in Washington, D.C., at which the impact of State surveillance of communications was discussed.

11. For the purpose of the present report, the Special Rapporteur reviewed relevant studies and consulted experts on the right to access information and the right to truth. The Special Rapporteur organized two expert consultations focusing on the interrelationships between the right to access information and the right to truth. The first was held in Washington, D.C., in May and the second in Mexico City in July. In May, the Special Rapporteur participated in an expert meeting on the right to information and national security, convened in Pretoria by the Open Society Justice Initiative; the meeting resulted in the presentation of the Global Principles on National Security and the Right to Information.<sup>2</sup>

<sup>2</sup> Available from www.opensocietyfoundations.org/publications/global-principles-nationalsecurity-and-freedom-information-tshwane-principles.

# **III. The right to truth and the right to access information**

### **A. Right to truth**

12. Historically, in particular in countries that have experienced situations of serious and systematic human rights violations, lack of access to information and, often, the circulation of misinformation, have been central issues for subsequent governments and society as a whole when seeking to address the past and constitute an important challenge in the transitional justice process. Over the years, especially following the transition to democracy experienced by countries in Latin America and Eastern Europe in the 1980s and 1990s, the right to the truth has been recognized in a number of forums and documents as a distinct right.

13. In 2011, in establishing a specific mandate to monitor the promotion of truth, justice, reparation and guarantees of non-recurrence, the Human Rights Council emphasized the importance of a comprehensive approach incorporating the full range of judicial and non-judicial measures in order to, among other things, ensure accountability, serve justice, provide remedies to victims, and promote healing and reconciliation (Human Rights Council resolution [18/7\)](http://undocs.org/A/RES/18/7).

14. At the national level, the right to truth can be characterized as the right to know, to be informed or to freedom of information. In resolution [12/12](http://undocs.org/A/RES/12/12), its most recent on the right to truth, the Human Rights Council emphasized that the public and individuals were entitled to have access, to the fullest extent practicable, to information regarding the actions and decision-making processes of their Government.

15. International human rights bodies and mechanisms have recognized and developed the right to truth as a distinct right. Principle 4 of the updated set of principles for the protection and promotion of human rights through action to combat impunity [\(E/CN.4/2005/102/Add.1\)](http://undocs.org/E/CN.4/2005/102/Add.1) notes the existence of the right to know the truth, irrespective of any legal proceedings. Both the Inter-American Court of Human Rights and the Inter-American Commission on Human Rights have noted the importance of this right, separately from judicial proceedings. The Inter-American Commission has stated that the right to know the truth is a collective right which ensures society access to information that is essential for the workings of democratic systems, and is also a private right for relatives of the victims, which affords a form of compensation, in particular, in cases in which amnesty laws are adopted.<sup>3</sup>

16. The European Court of Human Rights has also recognized the importance of the right of victims and families to know the truth, in particular with regard to circumstances or events relating to serious violations of fundamental rights, such as the right to life.<sup>4</sup>

<sup>3</sup> Inter-American Commission on Human Rights, *Lucio Parada Cea and others v. El Salvador*, Report No. 1/99, Case 10.480, 27 January 1999, para. 151.

<sup>4</sup> European Court of Human Rights, *Association "21 December 1989" and others v. Romania*, Applications Nos. 33810/07 and 18817/08, Judgement of 24 May 2011, para. 135, and *Janowiec and others v. Russia*, Applications Nos. 55508/07 and 29520/09, Judgement of 16 April 2012, paras. 150-167.

17. Although the jurisprudence of the right to truth generally relates to situations in which there has been a failure to ensure justice and reparations, the right to truth is closely associated with the right to access information.

#### **B. Right to access information**

18. The right to seek and receive information is an essential element of the right to freedom of expression. It is, as noted in a previous report of the Special Rapporteur, a right in and of itself and one of the rights upon which free and democratic societies depend [\(E/CN.4/2000/63,](http://undocs.org/E/CN.4/2000/63) para. 42). Accordingly, the Special Rapporteur has, since the establishment of the mandate, carried out a number of studies regarding certain aspects of its implementation (see, for example, [E/CN.4/1999/64](http://undocs.org/E/CN.4/1999/64), [E/CN.4/2000/63,](http://undocs.org/E/CN.4/2000/63) [E/CN.4/2003/67,](http://undocs.org/E/CN.4/2003/67) [E/CN.4/2005/64](http://undocs.org/E/CN.4/2005/64) and Corr.1, [A/HRC/11/4](http://undocs.org/A/HRC/11/4) and [A/HRC/17/27](http://undocs.org/A/HRC/17/27)). In more recent reports, the Special Rapporteur has focused on rights and limitations regarding access to the Internet, which are in numerous respects closely linked to the right to seek and receive information ([A/HRC/17/27,](http://undocs.org/A/HRC/17/27) sects. II to VI, and [A/66/290,](http://undocs.org/A/66/290) sects. III to V).

19. The right to access information has many aspects. It encompasses both the general right of the public to have access to information of public interest from a variety of sources and the right of the media to access information, in addition to the right of individuals to request and receive information of public interest and information concerning themselves that may affect their individual rights. As noted previously, the right to freedom of opinion and expression is an enabler of other rights ([A/HRC/17/27,](http://undocs.org/A/HRC/17/27) para. 22) and access to information is often essential for individuals seeking to give effect to other rights.

20. Furthermore, public authorities act as representatives of the public, fulfilling a public good; therefore, in principle, their decisions and actions should be transparent. A culture of secrecy is acceptable only in very exceptional cases, when confidentiality may be essential for the effectiveness of their work. There is consequently a strong public interest in the disclosure of some types of information. Moreover, access to certain types of information can affect the enjoyment by individuals of other rights. In such cases, information can be withheld only in very exceptional circumstances, if at all.

21. A particular dimension of the right to seek and receive information concerns access to information on human rights violations. Such access often determines the level of enjoyment of other rights, is a right in itself and, as such, has been addressed by a number of human rights instruments and documents. It has also been the object of decisions and reports from various human rights mechanisms and bodies.

22. Notably, article 6 of the Declaration on the Right and Responsibility of Individuals, Groups and Organs of Society to Promote and Protect Universally Recognized Human Rights and Fundamental Freedoms (known also as the Declaration on Human Rights Defenders), adopted by the General Assembly in resolution [53/144,](http://undocs.org/A/RES/53/144) expressly provides for access to information on human rights, stating that everyone has the right, individually and in association with others, (a) to know, seek, obtain, receive and hold information about all human rights and fundamental freedoms, including having access to information as to how these rights and freedoms are given effect in domestic legislative, judicial or administrative systems; and (b) as provided for in human rights and other applicable international instruments, freely to publish, impart or disseminate to others views, information and knowledge on all human rights and fundamental freedoms.

23. Those seeking to gain access to information on human rights violations have, however, frequently been confronted with a number of obstacles, especially with regard to past grave and/or systematic violations. Reluctance by the authorities to carry out their duty to investigate the facts adequately often prevents persons accessing information. On various occasions, public authorities have also refused to disclose information, allegedly in order to protect national security concerns.

#### **C. Access to information on human rights violations**

24. The right to truth and the right to access information are clearly interrelated. The right to seek and receive information on human rights violations is not limited to past grave and/or systematic violations; countries that have experienced such situations have, however, faced particular challenges in that regard and, in a number of cases, developed processes and norms to address them.

25. The gravity and the scale of the practice of disappearances by the regimes that were in power in Latin America from the 1960s, and the subsequent struggle of family members and society in general to establish the fate of the victims and to ensure investigation into the facts and punishment of the perpetrators, was initially at the centre of the development of the right to truth. During those regimes, the justice systems of the countries in which such acts occurred were completely ineffective in carrying out investigations into the facts. Moreover, many of the countries concerned adopted amnesty laws that not only ensured impunity for the perpetrators but, in effect, also impeded investigations by the justice systems.

26. In an attempt to address this issue, in particular since the 1980s, numerous countries have created inquiry commissions, more commonly known as truth commissions, to, in most cases, carry out investigations, make public their findings and provide recommendations regarding reparations and reconciliation. These commissions have largely reported on both the general circumstances leading to and surrounding human rights violations and individual cases. Such commissions were first established in Latin America following the collapse of military regimes and/or the end of armed conflicts that had given rise to large-scale, serious and systematic human rights violations, such as extrajudicial executions, disappearances and even genocide.

27. Moreover, the existing human rights protection systems, at both the international and regional levels, have on a number of occasions also been confronted with the question of access to information in the context of human rights violations and have, over the years, outlined the obligations of States concerning several aspects of that right.

### **D. Obligation to inform the public and collective dimension of the right to truth**

28. The Special Rapporteur recalls that, as stated by the Human Rights Committee in its general comment No. 34 (2011), to give effect to the right to freedom of expression, States parties should proactively put in the public domain government information of public interest, and that, in ensuring access to such information, States parties should also enact the necessary procedures, such as by means of freedom of information legislation [\(CCPR/C/GC/34](http://undocs.org/CCPR/C/GC/34), para. 19).

29. In addition, in the context of serious human rights violations, there is a particular obligation which requires States to inform not only the victims and their families but also society as a whole of what has happened.

30. In this context, the pursuit of judicial investigations into human rights violations is a core responsibility of the State and a major starting point for the realization of the right to truth. The judicial investigation of individual cases is not sufficient in itself, however; the right to truth implies not only the clarification of the immediate circumstances of particular violations, but also the clarification of the general context, the policies and the institutional failures and decisions that enabled their occurrence. Beyond this, the realization of the right to truth may require the dissemination of information on violations in order to restore confidence in State institutions and ensure non-repetition.

31. Global and regional bodies for the protection of human rights have addressed the right to truth both from an individual perspective (the rights of victims and their families to know the truth about violations affecting their lives) and from a collective perspective (the right of society as a whole to know and the obligation of States to inform society of past violations).

32. The Inter-American Court has repeatedly recognized this right.<sup>5</sup> In addition, the Basic Principles on Reparations and Guidelines on the Right to a Remedy and Reparation for Victims of Gross Violations of International Human Rights Law and Serious Violations of International Humanitarian Law include, as a measure of satisfaction, verification of the facts and full and public disclosure of the truth to the extent that such disclosure does not cause further harm to the victims, as well as inclusion of an accurate account of the violations that occurred in international human rights law and international humanitarian law training and in educational material at all levels (General Assembly resolution [60/147](http://undocs.org/A/RES/60/147), annex, paras. 22 (b) and (h)).

33. The set of principles for the protection and promotion of human rights through action to combat impunity, as updated in 2005 by the independent expert appointed for that purpose ([A/CN.4/2005/102/Add.1\)](http://undocs.org/A/CN.4/2005/102/Add.1), also spells out the obligations of States to inform society of what has happened and recognizes the inalienable right of every people to know the truth (principle 2), emphasizing also the preservation and facilitation of access to archives (principles 14 and 15).

34. The set of principles provides also that a people's knowledge of the history of its oppression is part of its heritage and, as such, must be ensured by appropriate measures in fulfilment of the State's duty to preserve archives and other evidence

<sup>5</sup> See, for example, Inter-American Court of Human Rights, *Bámaca Velásquez v. Guatemala*, Judgement of 22 February 2002, Series C, No. 9, paras. 76 and 77; *Carpio-Nicolle and others v. Guatemala*, Judgement of 22 November 2004, Series C, No. 117, para. 128; *Gomes Lund and others ("Guerrilha do Araguaia") v. Brazil*, Judgement of 24 November 2010, Series C, No. 219, para. 200; *Massacres of El Mozote and nearby places v. El Salvador*, Judgement of 25 October 2012, Series C, No. 252, para. 320; and *García and family v. Guatemala*, Judgement of 29 November 2012, Series C, No. 258, para. 176.

concerning violations of human rights and humanitarian law and to facilitate knowledge of those violations, and that such measures shall be aimed at preserving the collective memory from extinction.

35. These principles outline guarantees to give effect to the right to truth, including judicial and non-judicial processes and detailed general principles for the setting up and functioning of truth commissions (principles 6 to 13).

36. As mentioned above, the right to truth affects and has many implications for other rights; for example, (a) it is in itself part of the reparation for the victims and their families, and it honours the memory of the victims; (b) it is the first step in eliminating impunity and striving towards the right to justice and reparation; (c) it is part of the guarantee of non-repetition; (d) it is essential for the individual and his or her social and mental health recovery; (e) it is part of the reconstruction of the social network of relationships, peaceful coexistence and reconciliation; and (f) it is part of the historical heritage of a nation and is, therefore, open to academic research and investigative journalism. Only people who have the right to fully acknowledge their past can be truly free to define their future.

37. As observed above, the State has an obligation to disclose information, and in particular, certain types of information, such as that regarding violations of human rights or humanitarian law. This is clearly information of public interest, engaging a high presumption of disclosure. The overriding public interest in the disclosure of information concerning serious violations of human rights and humanitarian law, in addition to the obligation of States to take proactive measures to ensure the preservation and dissemination of such information, is generally acknowledged. Limitations to these obligations, especially in situations of transitional justice, can be invoked only under very specific circumstances.

38. By its resolution [65/196,](http://undocs.org/A/RES/65/196) the General Assembly proclaimed 24 March as the International Day for the Right to the Truth concerning Gross Human Rights Violations and for the Dignity of Victims, in recognition of the work and values of Monsignor Oscar Arnulfo Romero of El Salvador, who was killed in 1980. In his message on the day in 2013,<sup>6</sup> the Secretary-General emphasized the individual and collective dimension of the right to truth, noting that each victim had the right to know the truth about violations against them, but that the truth also had to be told more widely as a safeguard to prevent violations from happening again.

### **E. Right of victims and their families to access information**

39. The right to seek and receive information comprises the right of individuals to access general information and, more particularly, information of public interest that can contribute to public debate.<sup>7</sup> Another aspect of this right is that of access by persons to personal data being held by public authorities.<sup>8</sup>



<sup>6</sup> Available from www.un.org/en/events/righttotruthday/2013/sgmessage.shtml. 7 European Court of Human Rights, *Youth Initiative for Human Rights v. Serbia*, Application No. 48135/06, Judgement of 25 June 2013, para. 24, and *Claude Reyes and others v. Chile*, Judgement of 19 September 2006, Series C, No. 151, paras. 77 and 87; and Human Rights Committee, general comment No. 34 (CCPR/C/GC/34), paras. 18 and 19).

<sup>8</sup> Human Rights Committee, general comment No. 34, para. 18.

40. In the context of human rights violations, and especially in cases of serious violations, the rights of victims and their families to access information can have several aspects. First, gaining access to information regarding the circumstances surrounding a human rights violation is usually essential in order to give effect to other rights, such as due process, guarantees to a fair trial and the right to a remedy. Moreover, clarifying what occurred is in itself one of the elements of reparations for victims and family members.<sup>9</sup> Lastly, in cases of violations such as disappearances, the violation is continuing and ceases only once family members are able to ascertain the facts and determine the fate of the disappeared person. The refusal of the State to provide information, or the provision by it of false information, constitutes an additional violation because it prolongs and deepens the anguish, in addition to the moral and emotional pain.

41. Human rights bodies at the global and regional levels have in a number of instances concluded that States should carry out investigations and provide information on serious human rights violations to victims or their family members and, in particular, ensure that those responsible do not go unpunished and that the victims obtain redress through the courts.<sup>10</sup>

42. The Inter-American Court has developed extensive jurisprudence regarding the various aspects of the right to know and to seek and receive information in the context of human rights violations. The Court has consistently recognized victims' and/or their families' rights to access information regarding violations suffered. In its findings, the Court has often associated the right to seek and receive information with basic human rights and State obligations, such as the obligation of the State to protect and ensure human rights, and the right to judicial protection and a fair trial and/or due diligence guarantees.<sup>1</sup>1

43. The Inter-American Court has recently has found that violations of the right to know the truth can be a breach of the right to access information set forth in article 13 of the American Convention on Human Rights, which recognizes freedom of expression.<sup>1</sup>2

<sup>9</sup> See, for example, the Basic Principles and Guidelines on the Right to a Remedy and Reparation for Victims of Gross Violations of International Human Rights Law and Serious Violations of International Humanitarian Law (General Assembly resolution 60/147, annex), article 16 of which includes, as a measure of satisfaction, verification of the facts and full and public disclosure of the truth.

<sup>10</sup> See, for example, Human Rights Committee, *Ali Bashasha and Hussein Bashasha v. Libyan Arab Jamahiriya*, Communication No. 1776/2008 (views adopted on 20 October 2010, 100th session), para. 9; European Court of Human Rights, *Tanis and others v. Turkey*, Application No. 65899/01, Judgement of 2 August 2005, para. 225; and *Aksoy v. Turkey*, Application No. 21987/93, Judgement of 18 December 1996, para. 98; Inter-American Court of Human Rights, *Massacres of El Mozote and nearby locations v. El Salvador*, Judgement of 25 October 2012, Series C, No. 252, para. 242; and African Commission on Human and Peoples' Rights, *Zimbabwe Human Rights NGO Forum v. Zimbabwe*, Communication No. 245/2002, Decision of 21 May 2006, paras. 211 and 215.

<sup>11</sup> See, for example, Inter-American Court of Human Rights, *Bámaca Velásquez v. Guatemala*, Judgement of 22 February 2002, Series C, No. 91, paras. 76 and 77; *Blake v. Guatemala*, Judgement of 24 January 1998, Series C, No. 36, para. 97; *Barrios Altos v. Peru*, Judgement of 14 March 2001, Series C, No. 75, para. 43; *Almonacid Arellano and others v. Chile*, Judgement of 26 September 2006, Series C, No. 154, para. 126; and *Massacres of El Mozote and nearby* 

*places v. El Salvador*, Judgement of 25 October 2012, Series C, No. 252, para. 298. 12 Inter-American Court of Human Rights, *Gomes Lund and others ("Guerrilha do Araguaia") v. Brazil*, Judgement of 24 November 2010, Series C, No. 219, para. 225.

44. As described above, the right of victims and their families to access information and know the truth has different aspects and principles.

45. In its considerations, the Court has emphasized that the State must demonstrate a certain amount of due diligence in searching and providing information. For example, it was of the view that the State could not seek protection in arguing the lack of existence of the requested documents but, to the contrary, must establish the reason for denying the provision of the said information, demonstrating that it had adopted all the measures within its power to prove that, in effect, the information sought did not exist. Furthermore, the Court deemed it essential that, in order to guarantee the right to information, the public powers should act in good faith and diligently carry out the actions necessary to ensure the effectiveness of that right, especially when it dealt with the right to the truth of what had occurred in cases of gross violations of human rights, such as those of enforced disappearances and extrajudicial execution in the case under consideration.<sup>13</sup>

46. The Court has also considered judicial proceedings to be essential to the right to know the truth, holding that States may establish truth commissions, which contribute to the creation and preservation of historical memory, elucidation of the facts and the determination of institutional, social and political responsibilities during certain historical periods in society. Nevertheless, the Court considers that this does not complete, or substitute for, the State's obligation to establish the truth through judicial proceedings; hence, the State has the obligation to open and expedite criminal investigations in order to determine the corresponding responsibilities.<sup>1</sup>4

47. Lastly, the circulation of false information has been considered in certain cases to be a violation in itself, especially where individuals or groups of individuals have been submitted to odium, stigmatization, public scorn, persecution or discrimination by means of public declarations by public officials.<sup>15</sup>

#### **F. Limitations to the right to access information**

48. As with aspects of the right to freedom of expression, the right to access information is subject to limitations. Article 19 (3) of the International Covenant on Civil and Political Rights sets out the areas in which restrictions are permissible. These, and the conditions under which they can be applied, were further addressed in some detail by the Human Rights Committee in its general comment No. 34 ([CCPR/C/GC/34](http://undocs.org/CCPR/C/GC/34), para. 22).

49. The Special Rapporteur has, in previous reports, examined limitations to the right to freedom of opinion and expression and proposed a set of general principles for determining the conditions that must be satisfied for a limitation or a restriction

**\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_** 

14 Inter-American Court of Human Rights, *Massacres of El Mozote and nearby places v. El Salvador*, Judgement of 25 October 2012, Series C, No. 252, para. 298. 15 See for example, Inter-American Court of Human Rights, *Ríos and others v. Venezuela*,

<sup>13</sup> Ibid., para. 211.

Judgement of 28 January 2009, Series C, No. 194, paras. 148 and 149; *Perozo and others v. Venezuela*, Judgement of 28 January 2009, Series C, No. 195, para. 160; and *Gómez-Paquiyauri Brothers v. Peru*, Judgement of 8 July 2004, para. 182.

to freedom of expression to be permissible, which he considers to be generally applicable ([A/HRC/14/23,](http://undocs.org/A/HRC/14/23) para. 79, and [A/67/357](http://undocs.org/A/67/357), paras. 41-46).

50. The overarching notion is that all information in the possession of the State belongs to the public, with limited and qualified exceptions that must be justified by State authorities. Nonetheless, the application of limitations to the right to access information on human rights violations raises a number of specific issues that require greater analysis.

51. The Special Rapporteur wishes to recall that, whenever a State imposes restrictions on the exercise of the right to freedom of expression, such restrictions may not put in jeopardy the right itself,<sup>16</sup> much less when the information requested relates to human rights violations. Restrictions must be defined by law that is accessible, concrete, clear and unambiguous, and compatible with the State's international human rights obligations. They must also strictly conform to tests of necessity and proportionality.<sup>1</sup>7

52. For a restriction to be necessary, it must be based on one of the grounds for limitations recognized by the International Covenant on Civil and Political Rights and address a pressing public or social need. Any restriction must also be proportionate to the aim invoked and must not be more restrictive than is required for the achievement of the desired purpose or protected right.

53. When invoking a legitimate ground for restriction of freedom of expression, the authorities must demonstrate, in specific and individualized fashion, the precise nature of the imminent threat, as well as the necessity for and the proportionality of the specific action taken. A direct and immediate connection between the expression (or the information to be disclosed) and the alleged threat must be established.<sup>18</sup>

54. Moreover, there must be recourse to a review of a refusal to provide information in national legislation. This review must include a prompt, comprehensive and efficient judicial review of the validity of the restriction by an independent court or tribunal [\(A/HRC/14/23](http://undocs.org/A/HRC/14/23), para. 79; see also [A/HRC/16/48,](http://undocs.org/A/HRC/16/48) para. 39).

55. In a number of instances, States have continued to limit access to information concerning action carried out under previous regimes, even when they took place many years before. In the absence of detailed justification, allegations that information regarding such past violations can affect national security have little credibility. The Special Rapporteur considers that it is difficult to justify a continuing public interest in imposing limitations to information from former regimes.<sup>19</sup> As noted, authorities in countries undergoing a process of transitional justice have a particular obligation to proactively ensure the preservation and dissemination of information on serious violations of human rights and humanitarian law that took place in the past.

<sup>16</sup> See A/HRC/14/23, para. 79 (a), and Human Rights Committee, general comment No. 34, para. 21.

<sup>17</sup> A/HRC/14/23, paras. 79 (c), (d) and (g), and Human Rights Committee, general comment No. 34, para. 22.

<sup>18</sup> See Human Rights Committee, general comment No. 34, para. 35. 19 See European Court of Human Rights, *Turek v. Slovakia*, Application No. 57986/00, Judgement of 14 February 2006, para. 115.

### **G. National security and the right to access information**

56. The protection of national security explicitly appears in international human rights law as an acceptable reason to limit a number of freedoms, including freedom of expression. On the other hand, as detailed above, restrictions to the exercise of basic freedoms, including all possible restrictions to the right to access information, must still be clearly and objectively established by law and must also conform to the strict tests of necessity and proportionality.<sup>20</sup>

57. The recurrent use of national security concerns as a justification for the denial of access to various types of information predicates a need to study carefully the promotion of confidentiality on such grounds. Widespread secrecy justified on national security grounds is particularly problematic in the context of investigations of human rights violations because it may represent one of the main obstacles to the clarification of responsibilities and consequences of serious violations, ultimately becoming a barrier to the promotion of justice and reparation.

58. Although national security is a legitimate State concern, one of the main challenges faced when information is classified on national security grounds has frequently been the lack of transparency of the process as a whole. In cases of human rights violations, the situation may occur whereby those who decide to classify such information could belong or be linked to the entities allegedly responsible for the violations. The persistent denial of information on human rights violations potentially involving national security bodies often weakens public trust in these institutions, ultimately reversing the alleged justification for secrecy.

59. In this context, the Inter-American Court has stated that, in cases of human rights violations, the State authorities cannot resort to mechanisms such as declaring the information an official secret or confidential, or using reasons of public interest or national security, to refuse to supply the information required by the judicial or administrative authorities in charge of the ongoing investigation or proceeding.<sup>21</sup>

60. A State therefore cannot refuse to provide information to judicial or other authorities investigating gross violations of human rights or humanitarian law on the grounds of national security. In cases of other human rights violations, restrictions should not be applied in a manner that would prevent accountability or deprive a victim or family members of an effective remedy. Decisions to classify must be subjected to external judicial control and recourse must be made available.

61. Another serious issue in this context is the lack of outside control and of the possibility to challenge decisions that deny access to information. The authorities usually do not provide specific information on the precise nature of the threat, or on the necessity for and proportionality of such a measure.

62. The Inter-American Court has also noted that, when a punishable fact is being investigated, the decision to define the information as secret and to refuse to submit it can never depend exclusively on a State body whose members are deemed responsible for committing the illegal act. Thus, what is incompatible with the rule

<sup>20</sup> Human Rights Committee, general comment No. 34, para. 22.

<sup>21</sup> Inter-American Court of Human Rights, *Myrna Mack Chang v. Guatemala*, Judgement of 25 November 2003, Series C, No. 101, para. 180; and *Tiu Tojín v. Guatemala*, Judgement of 26 November 2008, Series C, No. 190, para. 77.

of law and effective judicial protection is not that there are secrets, but rather that they are outside legal control.<sup>2</sup>2

63. The Special Rapporteur understands that legitimate national security interests can be protected fully only through the respect of all human rights, including the right to freedom of expression. The most secure nations are those that pay greater attention to their human rights obligations. The importance of respecting all human rights and fundamental freedoms in responses to terrorism, for example, is widely recognized by States (see Commission on Human Rights resolution 2005/80). Promoting access to information, besides being an obligation, is a basic requirement for the rapid identification of malpractice and for the consequent enhancement of the work of all public bodies, including those working in the promotion of national security.

64. Bearing in mind these concerns, civil society organizations and academic centres, in consultation with experts from more than 70 countries, developed the Global Principles on National Security and the Right to Information (known as the Tshwane Principles).<sup>2</sup> The principles provide detailed guidance to those engaged in drafting, revising or implementing national norms relating to the State's authority to withhold information on national security grounds or to punish in cases of disclosure of such information. While preparing the present report, the Special Rapporteur participated in various consultations relating to these principles.

65. The Special Rapporteur considers that the Tshwane Principles provide a key tool for States to ensure that national laws and practices regarding the withholding of information on national security grounds fully comply with international human rights standards.

66. The Special Rapporteur wishes to highlight the importance of the references made to the disclosure of information on violations of human rights and humanitarian law, stipulated in section A of principle 10 of the Tshwane Principles, namely:

 (a) There is an overriding public interest in disclosure of information regarding gross violations of human rights or serious violations of international humanitarian law, including crimes under international law, and systematic or widespread violations of the rights to personal liberty and security. Such information may not be withheld on national security grounds in any circumstances;

 (b) Information regarding other violations of human rights or humanitarian law is subject to a high presumption of disclosure, and in any event may not be withheld on national security grounds in a manner that would prevent accountability for the violations or deprive a victim of access to an effective remedy;

 (c) When a State is undergoing a process of transitional justice, during which the State is especially required to ensure truth, justice, reparation and guarantees of non-recurrence, there is an overriding public interest in disclosure to society as a whole of information regarding human rights violations committed under the past regime. A successor government should immediately protect and preserve the integrity of, and release without delay, any records that contain such information that were concealed by a prior government.

<sup>22</sup> Inter-American Court of Human Rights, *Myrna Mack Chang v. Guatemala*, Judgement of 25 November 2003, Series C, No. 101, para. 181.

67. In the context of access to information on violations of human rights, the references made in the Tshwane Principles to public interest disclosures (part VI) and limits on measures to sanction or restrain the disclosure of information to the public (part VII) are of particular relevance. Among various recommendations, it is proposed that national law should protect from retaliation public personnel who make disclosures of information showing wrongdoing (such as human rights violations), regardless of whether the information is classified or otherwise confidential. It is further suggested that public bodies establish internal procedures and designate specific persons to receive protected disclosures.

68. Information on human rights violations involving the activities of national security and intelligence bodies that operate under strict secrecy procedures are often only disclosed by those working within these entities (see [A/HRC/10/3](http://undocs.org/A/HRC/10/3)). In this regard, the Special Rapporteur has recalled the importance of ensuring the protection of whistle-blowers, that is, persons with a connection to the State who, having a legal obligation to ensure confidentiality, disclose to the public information that they reasonably consider to reveal human rights violations. The Special Rapporteur has indicated that a whistle-blower should not be subjected to legal, administrative or disciplinary sanctions as long as he or she has acted in good faith, pursuant to international standards on the subject.<sup>2</sup>3 In fact, every person who is involved in or witnesses a human rights violation should assume the moral responsibility to denounce it.

69. Furthermore, the Special Rapporteur has highlighted<sup>24</sup> the fact that, under no circumstances, may journalists, members of the media or members of civil society who have access to and distribute classified information on alleged violation of human rights be subjected to subsequent punishment. Equally, confidential sources and materials relating to the disclosure of classified information must be protected by law. In this context, journalistic self-regulatory mechanisms and codes can significantly contribute to drawing attention to eventual risks in the communication of complex and sensitive issues.

## **IV. Promoting the right to access information at the national level**

70. Over the past 20 years, numerous national norms have been adopted with the aim of promoting the right to access information. It is currently estimated that more than 50 national constitutions guarantee a right to information or of access to documents, or impose an obligation on State institutions to make information available to the public. More than 90 countries have adopted national laws

<sup>23</sup> Special Rapporteur on the Protection and Promotion of the Right to Freedom of Opinion and Expression and Special Rapporteur for Freedom of Expression of the Inter-American Commission on Human Rights, "Joint declaration on surveillance programmes and their impact on freedom of expression", June 2013, para. 16. Available from www.oas.org/en/iachr/expression/ showarticle.asp?artID=927&lID=1.

<sup>24</sup> Ibid., para 15.

establishing the right to request information and procedures for the public to obtain government-held information,<sup>2</sup>5 thus responding to their human rights obligations.

71. These efforts were frequently stimulated by the democratic transitions experienced in various regions over the past decades. The increasing pressure for broader access to information is also a result of the work of international and national non-governmental organizations. Lastly, the rapid evolution of information technology has significantly expanded the capacity of States and individuals to process and communicate all types of information in a timely manner. Naturally, this has raised expectations that public entities (and other private actors) proactively disclose relevant information to society regularly.

72. Acknowledging the relevance of access to information in democratization and development efforts, international organizations have encouraged the adoption of national norms regulating access to information and produced publications aimed at assisting national processes with, for example, a description of the features of a freedom of information regime<sup>2</sup>6 and tools for measuring the impact of right to information models.<sup>2</sup>7

73. Described below are the principles developed to guide the design and implementation of national legislation on access to information, in addition to common obstacles to the implementation of such laws.

### **A. Principles guiding the design and implementation of national laws on access to information**

74. Notwithstanding the positive steps taken by a number of States, as reflected in the many national legal instruments regulating access to information, multiple obstacles are frequently encountered in their implementation. Altering long-standing practices of government workforces is a complex process, especially when public bodies have been established or subjected to reforms during a previous authoritarian rule. The provision of information in a timely manner requires not only improvement of the technical capacity of public bodies to process and share information, but also the training and awareness-raising of public officials at all levels with regard to their duty to respond to public requests for information, while assigning absolute priority to information relating to human rights violations.

75. While reviewing multiple experiences that promote the right to access information, experts have developed some core principles to guide the design and implementation of relevant laws and practices.<sup>28</sup> The same principles had been endorsed and presented to the Commission on Human Rights by the Special Rapporteur on the right to freedom of opinion and expression in 2000 and were further reflected in other declarations prepared by international mechanisms for

<sup>25</sup> See www.right2info.org/access-to-information-laws/access-to-information-laws-overview-andstatutory#\_ftn7; and Toby Mendel, *Freedom of Information: A Comparative Legal Survey*, 2nd ed. (Paris, United Nations Educational, Scientific and Cultural Organization (UNESCO), 2008).

<sup>26</sup> See Toby Mendel, *Freedom of Information, A Comparative Legal Survey*, 2nd ed. (Paris, UNESCO, 2008), pp. 31-43.

<sup>27</sup> United Nations Development Programme, *A Guide to Measuring the Impact of Rights to* 

*information Programmes*, Practical Guidance Note (April 2006). 28 Article 19 Global Campaign for Free Expression, *The Public's Right to Know: Principles on Freedom of Information Legislation* (London, 1999).

promoting freedom of expression.<sup>2</sup>9 The Special Rapporteur considers that these principles continue to represent a crucial tool for translating into practice the various human rights obligations concerning the right to information.

76. The core principles include:

 (a) **Maximum disclosure**. National legislation on access to information should be guided by the principle of maximum disclosure. All information held by public bodies should be subject to disclosure and this presumption may be overcome only in very limited circumstances;

 (b) **Obligation to publish**. Freedom of information implies not only that public bodies accede to requests for information, but also that they widely publish and disseminate documents of significant public interest, subject only to reasonable limits based on resources and capacity;

 (c) **Promotion of open government**. The full implementation of national laws on access to information requires that the public be informed about their rights and that government officials adhere to a culture of openness. Dedicated efforts are required to disseminate information to the general public on the right to access information and to raise the awareness of and train government staff to respond appropriately to public demands;

 (d) **Limited scope of exceptions**. Reasons for the denial of access to information should be clearly and narrowly designed, bearing in mind the three-part test suggested in the interpretation of the right to freedom of opinion and expression.<sup>30</sup> Non-disclosure of information must be justified on a case-by-case basis. Exceptions should apply only where there is a risk of substantial harm to the protected interest and where that harm is greater than the overall public interest in having access to the information;

 (e) **Processes to facilitate access**. Procedures to request information should allow for fair and rapid processing and include mechanisms for an independent review in cases of refusal. Public bodies should be required to establish open, accessible internal systems for ensuring the public's right to receive information. The law should provide for an individual right of appeal to an independent administrative body in respect of a refusal by a public body to disclose information;

 (f) **Costs**. Individuals should not be deterred by excessive cost from making requests for information;

 (g) **Open meetings**. In line with the notion of maximum disclosure, legislation should establish a presumption that meetings of governing bodies are open to the public;

 (h) **Disclosure takes precedence**. To ensure maximum disclosure, laws which are inconsistent with this principle should be amended or repealed. The

<sup>29</sup> Joint declarations by the Special Rapporteur on Freedom of Opinion and Expression, the Organization for Security and Cooperation in Europe Representative on Freedom of the Media and the Organization of American States Special Rapporteur on Freedom of Expression, 1999 (E/CN.4/2000/63, annex I) and 2004 (www.oas.org/en/iachr/expression/showarticle.asp?artID=319&lID=1).

<sup>30</sup> Human Rights Committee, general comment No. 34, para. 22.

regime of exceptions provided for in the freedom of information law should be comprehensive and other laws should not be permitted to extend it;

 (i) **Protection for individuals who disclose relevant information (whistleblowers)**. National laws on the right to information should provide protection from liability for officials who, in good faith, disclose information pursuant to right to information legislation. Individuals should be protected from any legal, administrative or employment-related sanctions for releasing information on wrongdoing, including the commission of a criminal offence or the failure to comply with a legal obligation. Special protection should be provided for those who release information concerning human rights violations.

### **B. Challenges in the implementation of national laws on access to information**

77. As indicated in a comprehensive comparative study of national experiences promoting access to information,<sup>31</sup> the adoption of national laws should be regarded only as the first step: full implementation requires political will (full endorsement by various relevant authorities of the principles enshrined by the new normative framework), an active civil society (advocating and monitoring the implementation of the norms) and respect for the rule of law. In fact, a number of frequent obstacles can be noted in the review of national practices implementing legal frameworks protecting the right to information.<sup>3</sup>2

#### **1. Lack of technical capacity**

78. The overall lack of capacity to process information is an obvious problem for public institutions. Some public institutions have no human or technical capacity to manage and communicate data adequately. Technological advances notwithstanding, officials are also often unaware of the information stored by the bodies that they service and are unable to locate it.

#### **2. Unreasonable delays and lack of responses**

79. Unreasonable delays in responding to requests for information are a very frequent concern. National laws often establish the requirement for public institutions to respond to a request without delay, setting in some cases a maximum time frame for response. These deadlines, however, are sometimes not enforced.

80. The absence of any response by the public authorities responsible for the provision of information is also critical. The lack of mechanisms to monitor independently the compliance of public bodies with regulations on access to information and the lack of specific sanctions for wrongful denial of access or the destruction of information by public officials certainly contribute to the limited enforcement of some national laws.

<sup>31</sup> Toby Mendel, *Freedom of Information, A Comparative Legal Survey*, 2nd ed. (Paris, UNESCO, 2008), principles 1 to 9.

<sup>32</sup> Ibid., and David Banisar, *Freedom of Information around the World 2006: A Global Survey of Access to Government Information Laws* (Privacy International, 2006).

#### **3. Restrictive procedures**

81. There are concerns regarding the inclusion of unnecessary procedural formalities that unreasonably restrict possibilities for submitting demands for information. This can include, for example, requirements for those who request information to show a specific legal interest or to submit separate requests to each of the multiple entities involved in providing a response to a given request.

#### **4. Imposition of fees**

82. There are financial costs related to the collection of information and national laws often allow public institutions to charge fees to the requestor. Some fees can cover costs relating to, for example, applications, searching or copying. The charging of fees for gaining access to information can also, however, be a barrier to such access, in particular for those living in poverty. In the absence of any oversight, some fees can be imposed abusively.

#### **5. Inclusion of vague and inappropriate exceptions within the law**

83. The inclusion of vaguely defined or inappropriate exceptions in national laws on access to information is also a common obstacle that seriously compromises the impact of the instruments. Inappropriate exceptions include, for example, reference to the protection of good relations with other States and intergovernmental organizations. As mentioned above, the widespread and unspecified use of national security concerns as a reason for the denial of access to information is another common occurrence. Some laws explicitly exclude some public bodies from the ambit of national norms, preventing consideration of whether information pertaining to those bodies should be disclosed at all.

#### **6. Conflict with other norms providing grounds for secrecy**

84. In some cases, the continued use of parallel national laws and regulations justifying multiple grounds for secrecy, some predating the adoption of the laws regulating access to information, continues to hamper information access.

85. The review of national experiences also demonstrates important positive elements in existing laws and practices. It is clear that provisions establishing objective procedural guarantees which detail the processes required to request and obtain information, in addition to the responsibilities of public bodies in these processes, are a central element for the successful implementation of national norms. The establishment of a broad scope for the right to access to information in national laws is central to the success of the norms. The inclusion of pragmatic instructions among principles, such as that of ensuring that access is rapid, inexpensive and not unduly burdensome, is also positive.

86. There are also good practices regarding the appointment of dedicated officials to assist in the implementation of national laws on access to information. These can be established through the appointment of information officers, or the establishment of an office, such as the Mexican Federal Institute for Access to Information. Such mechanisms may undertake multiple functions relating to the promotion of access to information, such as processing requests, ensuring the proactive publication of information by public bodies, providing assistance to applicants, proposing adapted procedures to implement the law, training and raising the awareness of other officials, monitoring the implementation of the law, and reporting.

## **V. Conclusions and recommendations**

87. **Notwithstanding the different historical processes that marked the development of the right to truth and the right to access information, the right to truth should be understood as directly connected to the right to access information, as established by the right to freedom of opinion and expression.**

88. **Over the past three decades, the right to truth has most often been invoked in situations relating to the failure of the State to ensure accountability for systematic violations of human rights and to provide appropriate reparations. It has also commonly been related to the right of victims and their relatives to demand investigations and information as a first step in achieving justice. As international jurisprudence has evolved, it has become evident that the right to truth has also a clear, collective dimension. There is a shared interest in the clarification of human rights violations and in the dissemination of information on the context in which they occurred, especially so as to re-establish trust in State institutions and to ensure non-repetition of the violations. The realization of the right to truth, at both the individual and the collective levels, requires access to and, often, also the dissemination of information on human rights violations.**

89. **In parallel, the global recognition of the overall importance of transparency of public institutions in the consolidation of peace, democracy and development is unquestionable. Explicitly included as a component of the right to freedom of expression, the right to access information is increasingly protected by national laws. Technological advances, democratic transitions and the expansion of civil society activity have contributed to a significant increase in the demand for all types of information held by public bodies.**

90. **If State officials act as representatives of the people of the nation and seek the common good, every decision or initiative taken by them should, in principle, be publicly known. The right to access information, however, can in exceptional circumstances be subject to limitations so as to protect the rights of others and the effectiveness of some State initiatives. Nevertheless, such limitations cannot override the public interest to know and to be informed.**

91. **Given that the promotion, protection and guarantee of human rights and fundamental freedoms are the ultimate responsibility of any State, there is a greater responsibility in the disclosure of information held by public bodies concerning human rights violations, as identified in the jurisprudence relating to the right to truth.**

92. **In this context, the Special Rapporteur concludes that the right to access information on human rights violations, as enshrined by the right to freedom of expression, should be considered to be part of the right to truth in all circumstances — whether it relates to past or present situations, is claimed by victims, their relatives or by anyone in the name of public interest, in situations of political transition or not, and irrespective of the existence of legal proceedings, including when judicial action has expired.**

93. **Given that the enjoyment of human rights also implies responsibilities, and is based on the principles of universality, equality and interdependence, there is a shared responsibility in denouncing human rights violations whenever they occur. Such responsibility is of greater importance in the case of public officials. Therefore, the disclosure in good faith of relevant information relating to human rights violations should be accorded protection from liability. On the other hand, the silence of State officials on violations that they witness can be interpreted as complicity. Transitions to peace and democracy based on silence over past crimes, atrocities or impunity are not sustainable.**

94. **The adoption of national laws protecting access to information in all regions of the world is a positive step that reflects international human rights principles and norms. These processes, however, have mostly been disconnected from the debate on the right to truth and a number of obstacles to access information relating to past and present human rights violations persist.**

95. **The effective implementation of national laws on information continues to be limited by the reluctance of public bodies and officials to comply with the new norms and the continued acceptance of multiple grounds for secrecy. Particular attention should therefore be paid to overseeing the steps taken to institutionalize norms regulating access to information and to examining the true relevance of confidentiality. Ultimately, legitimate national security interests can be fully protected only through respect of all human rights, including the right to access information.**

96. **In this regard, and based on previous considerations, the Special Rapporteur wishes to recall a number of recommendations that should continue to guide State efforts in the consolidation of norms and practices concerning the realization of the right to information.**

97. **The Special Rapporteur calls upon States to implement the measures set out below.**

 **Revision or adoption of national laws to ensure the right to access information** 

98. **The adoption of a national normative framework that objectively establishes the right to access information held by public bodies in the broadest possible terms is crucial to give effect, at the national level, to the right to access information. Legislation should be grounded by the principle of maximum disclosure.**

99. **National laws should contain a clearly and narrowly defined list of exceptions or an explanation of the grounds for refusing the disclosure of information. Exceptions should apply only where there is a risk of substantial harm to the protected interest and where that harm is greater than the overall public interest in having access to the information, and should be determined by an independent body, preferably a court, and not the body holding the information.**

100. **Alternative laws establishing additional grounds for secrecy must be revised or revoked in order to ensure that they meet the norms on access to information.**

101. **National laws should establish the right to lodge complaints or appeals to independent bodies in cases in which requests for information have not been dealt with properly or have been refused.**

 **Ensuring that national norms and practices for access to information allow for simplified procedures** 

> 102. **The effectiveness of national legislation on the right to information depends on the establishment and implementation of procedures that ensure that access is rapid, inexpensive and not unduly burdensome.**

> 103. **States should, in particular, consider the appointment of a focal point, such as an information commissioner, to assist in the implementation of national norms on access to information or the creation of a State institution responsible for access to information. Such mechanisms could be mandated to process requests for information, assist applicants, ensure the proactive dissemination of information by public bodies, monitor compliance with the law and present recommendations to ensure adherence to the right to access information.**

 **Enhancement of the capacity of public bodies and officials to respond adequately to demands for information and ensure accountability in case of non-compliance** 

> 104. **The adoption of national norms should be followed by concerted efforts to enhance the technical capacity of State institutions to manage and disseminate information. Moreover, public officials must be trained and have their awareness raised in order to fulfil their responsibilities regarding the adequate maintenance of records and dissemination of information. Further efforts are also necessary to raise public awareness of the right to access information and the existing mechanisms to exercise it.**

> 105. **Public bodies and officials who wilfully obstruct access to information must be held accountable and, when appropriate, sanctioned. The quality of the responses of public bodies to information requests should be monitored periodically.**

 **Revision of norms regarding the promotion of secrecy on national security grounds and ensuring the protection of whistle-blowers** 

> 106. **Information regarding gross violations of human rights must not be withheld on national security grounds. When limitations are deemed absolutely necessary, the State has the burden of proof in demonstrating that the exceptions are compatible with international human rights law. Information regarding other violations of human rights must be subject to a high presumption of disclosure and, in any event, may not be withheld on national security grounds in a manner that would prevent accountability, or deprive a victim of access to an effective remedy. The Tshwane Principles are an important instrument for guiding efforts to revise norms and practices aimed at promoting secrecy on national security grounds.**

> 107. **Government officials who release confidential information concerning violations of the law, wrongdoing by public bodies, grave cases of corruption, a serious threat to health, safety or the environment, or a violation of human rights or humanitarian law (i.e. whistle-blowers) should, if they act in good faith,**

**be protected against legal, administrative or employment-related sanctions. Other individuals, including journalists, other media personnel and civil society representatives, who receive, possess or disseminate classified information because they believe that it is in the public interest, should not be subject to liability unless they place persons in an imminent situation of serious harm.**

108. **Only if the information released is related to the above principles should the person be considered a whistle-blower and, therefore, bear no liability.**
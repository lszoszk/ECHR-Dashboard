![](_page_0_Picture_2.jpeg)

# General Assembly Distr.

GENERAL

A/HRC/7/14 28 February 2008

Original: ENGLISH

HUMAN RIGHTS COUNCIL Seventh session Agenda item 3

# **PROMOTION AND PROTECTION OF ALL HUMAN RIGHTS, CIVIL, POLITICAL, ECONOMIC, SOCIAL AND CULTURAL RIGHTS, INCLUDING THE RIGHT TO DEVELOPMENT**

**Report of the Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression, Ambeyi Ligabo**\\*

GE.08-11210

 **\*** The present document is submitted late in order to reflect the most recent information.

#### **Summary**

This report is submitted by the Special Rapporteur on the right to freedom of opinion and expression, Ambeyi Ligabo, pursuant to Human Rights Council resolution 5/1. This is the last annual report that will be submitted by the current mandate-holder, whose term expires in August 2008. This report presents a review of the main trends and issues tackled during the Special Rapporteur's tenure. In particular, it highlights the most important patterns and challenges that emerge for the implementation of the right to freedom of opinion and expression.

Chapter I summarizes the main activities of the Special Rapporteur undertaken in 2007, including an analysis of communication trends in the period. Chapter II presents an overall review of the main issues addressed by the Special Rapporteur throughout his mandate, specifically in the realms of the right of access to information, safety and protection of media professionals, legal restrictions on freedom of opinion and expression as well as the impact of freedom of expression on the realization of other human rights. Section III presents the general conclusions and recommendations of the Special Rapporteur.

This report contains as an addendum the summary of communications sent by the Special Rapporteur from 1 January to 4 December 2007 and replies received thereto from Governments by 21 January 2008. Addenda 2 and 3 are the reports of the Special Rapporteur's country visits to Ukraine and Azerbaijan, respectively.

The main conclusions and recommendations presented by the Special Rapporteur include:

 - The Special Rapporteur urges Governments to conduct an in-depth assessment of existing national legislation as well as judicial practices related to all forms of freedom of opinion and expression and to commence, whenever necessary, reform processes in order to guarantee conformity with international human rights norms and standards. The Special Rapporteur also recommends that Governments focus on the protection and the promotion of media independence as a priority, in order to ensure a constant advancement in the field of freedom of opinion and expression;

- The Special Rapporteur recommends that Governments adopt legislation that unambiguously prohibits all forms of censorship in media outlets, both in the traditional media and the Internet. Defamation, libel and insult charges, particularly when stemming from public figures and specifically State authorities, do not justify any form of prior censorship;

 - The Special Rapporteur urges Governments to extend the measures to protect freedom of opinion and expression to the Internet, in particular to website contributors and bloggers, who should be granted with the same level of protection as any other type of media;

 - The Special Rapporteur reiterates his call to the Human Rights Council to pay increased attention to the issue of the safety and protection of journalists, in particular in situations of armed conflicts. The Council may wish to consider the opportunity, as previously suggested, of entrusting the Rapporteur with the preparation of a study on the causes of violence against media professionals, based, inter alia, on information from and the experiences of Governments, intergovernmental and non-governmental organizations, and including a comprehensive set of conclusions and recommendations and the drafting of guidelines for the protection of journalists and other media professionals.

The Special Rapporteur urges media professionals, as well as the public at large, to be conscious of the potential impact that the ideas they express may have in raising cultural and religious sensitivities. The dissemination of intolerant and discriminatory opinions ultimately promotes discord and conflict and is not conducive to the promotion of human rights. The Special Rapporteur further emphasizes that, although limitations to the right to freedom of opinion and expression are foreseen in international instruments to prevent war propaganda and incitement of national, racial or religious hatred, these limitations were designed in order to protect individuals against direct violations of their rights. These limitations are not intended to suppress the expression of critical views, controversial opinions or politically incorrect statements.

# **CONTENTS**

| Introduction | | | 1 - 3 |
|--------------|--------|--------------------------------------------------------------|---------|
| I. | | ACTIVITIES | |
| | A. | Analysis of information, communications and trends | 4 - 8 |
| | B. | Press releases | 9 - 14 |
| | C. | Participation in meetings and seminars | 15 - 17 |
| | D. | Country visits | 18 - 20 |
| II. | ISSUES | | 21 - 66 |
| | A. | Implementing the right of access to information | 21 - 31 |
| | B. | Safety and protection of journalists and media professionals | 32 - 38 |
| | C. | Legal restrictions on freedom of opinion and expression | 39 - 53 |
| | D. | Freedom of opinion and expression and the realization | |
| | | of other human rights | 54 - 66 |
| III. | | CONCLUSIONS AND RECOMMENDATIONS | 67 - 85 |
| | | | |

Annex

Joint declaration on promoting diversity in the broadcast media.

# **Introduction**

1. This report is submitted by the Special Rapporteur on the right to freedom of opinion and expression, Ambeyi Ligabo, pursuant Human Rights Council resolution 5/1. This is the last annual report that will be submitted by the present mandate-holder, whose term expires in August 2008.

2. Chapter I summarizes the main activities of the Special Rapporteur undertaken in 2007, including an analysis of communication trends in the period. Chapter II presents an overall review of the main issues addressed by the Special Rapporteur throughout his tenure. It thus intends to highlight the different trends observed by the Special Rapporteur over the past six years, pointing to the main challenges for the effective implementation of the right to freedom of opinion and expression. Chapter III presents the general conclusions and recommendations of the Special Rapporteur.

3. This report contains as its addendum 1 the summary of communications sent by the Special Rapporteur from 1 January to 4 December 2007 and replies received thereto from Governments by 21 January 2008. Addenda 2 and 3 are the reports of the Special Rapporteur's country visits to Ukraine and Azerbaijan, respectively.

# **I. ACTIVITIES**

# **A. Analysis of information, communications and trends**

4. The Special Rapporteur relies on communications received from various sources as a means to identify trends, reiterate issues already discussed in previous reports and bring to the attention of the international community a number of policies, practices and measures having an impact on the respect for freedom of opinion and expression.

5. To effectively implement his mandate, the Special Rapporteur focuses on information received from a variety of sources, including Governments; local, national, regional or international governmental and non-governmental organizations; associations of media professionals and writers; trade unions; etc. The quality and the quantity of information received are essential to the discharge of the mandate of the Special Rapporteur. Furthermore, they are a significant indicator of the degree of implementation of the right to freedom of

opinion and expression in a given country. The Special Rapporteur may also decide to take initiative *motu proprio* on issues of general concern that he considers relevant to his mandate.

6. The majority of cases received by the Special Rapporteur concern threats, aggressions, harassment, murder or other sorts of attacks on the physical and psychological integrity of journalists, students, human rights activists and unionists as retaliation for their exercise of their right to freedom of opinion and expression. In many cases, these attacks were linked to the repression of peaceful protests conducted to express disagreement with some governmental policy, at the national or local level, or with the actions of large corporations. While the extent of the repression, its duress and length may substantially vary, allegations received are not confined to countries where the political, social and economic situation is particularly difficult, but also concern violations occurring in transitional or longestablished democracies.

7. Analysis of communications also shows a large number of cases of prosecution or imprisonment of media professionals or ordinary citizens on charges of defamation, libel and slander, despite the decriminalization of these offenses by some countries. Another important trend in many regions has been the adoption of legislation that unduly limits freedom of expression by fostering State interference in editorial independence; by creating subjective licensing procedures that are used to shut down media outlets; by restricting the ability of journalists, particularly foreign correspondents, to perform their work freely; and by imposing severe limitations on the operation, including funding, of civil society organizations.

8. From 1 January to 4 December 2007, the Special Rapporteur sent 241 communications: 114 urgent appeals, 89 of which were signed jointly with other special procedures mandate-holders, and 127 allegation letters, 55 of which were co-signed with other mandates. These communications referred to the situation of 596 individuals. The geographical division of the communications was as follows: 31.5 per cent in Asia and the Pacific; 20.7 per cent in Africa; 18.2 per cent in Latin America and the Caribbean; 17 per cent in the Middle East and North Africa; and 12.4 per cent in Europe, North America and Central Asia.

# **B. Press releases<sup>1</sup>**

9. The Special Rapporteur regularly issues press releases to signal his concern about current events. In 2007, he issued five press releases concerning issues of safety of journalists and legislation that restricts the right to freedom of opinion and expression.

10. On 23 January, the Special Rapporteur expressed his concern over the murder of Hrant Dink, a respected Turkish journalist and intellectual who had developed important critical work concerning a sensitive period in the history of Turkey. He expressed his hopes that the investigations would shed light on all aspects of this crime.

11. On 12 March, the Special Rapporteur called for the immediate and unconditional release of Italian journalist Daniele Mastrogiacomo and his aides, who had been arrested in Afghanistan. He argued that this crime underscored the importance of intensifying efforts to ensure the safety of journalists, particularly in conflict areas. Mr. Mastrogiacomo was released on 20 March, but an Afghan journalist who was travelling with him, Ajmal Naqshbandi, was brutally executed on 8 April.

12. On 27 June, the Special Rapporteur called for the release of British journalist Alan Johnston of BBC, who had been abducted in Gaza City on 12 March. He once again highlighted the importance of ensuring the safety of media professionals as an indispensable conduit for the enjoyment of the right to freedom of expression.

13. On 28 September, the Special Rapporteur, along with several other special procedures mandate-holders, strongly condemned the crackdown of public demonstrations in Myanmar, in particular the brutal measures taken by the security services, including the use of deadly force. They also welcomed the decision to hold a special session of the Human Rights Council on the situation in Myanmar. They called for the release of the detained, an investigation of the killings, steps to alleviate the economic hardship of the majority of the population and the introduction of serious reforms and dialogue with the opposition.

**<sup>1</sup>** The full text of the statements is available at:

www2.ohchr.org/english/press/newsFrameset-2.htm.

14. On 30 November, the Special Rapporteur, along with the Special Representative of the Secretary-General on human rights defenders and the Special Rapporteur on the independence of judges and lawyers, released a statement expressing concern about the constitutional referendum that would be held in Venezuela. The three independent experts underlined their concern that some provisions submitted to popular vote, particularly concerned states of emergency and the operation of non-governmental organizations, could undermine a set of fundamental rights that should be enjoyed at all times.

# **C. Participation in meetings and seminars**

15. From 18 to 22 June 2007, the Special Rapporteur participated in the 14th annual meeting of special procedures, held in Geneva. The meeting primarily discussed the institution-building process conducted by the Human Rights Council and the new methods of work of mandate-holders, as well as issues such as cooperation with civil society, national human rights institutions and among special-procedures mandates.

16. On 5 December 2007, the Special Rapporteur submitted a statement to the expert meeting organized by the Office of the High Commissioner for Human Rights in Geneva to discuss and outline indicators to measure respect for the right to freedom of opinion and expression. In the statement he transmitted, the Special Rapporteur highlighted the importance of defining concrete yardsticks to monitor freedom of expression and violations that take place around the world. He underscored the importance of avoiding the risk, when employing these indicators, of creating crude comparisons between countries that are fundamentally different. Rather, he suggests that the indicators should be seen as an attempt to assess a country's progress compared to its own historical trajectory, following the approach used by the United Nations Millennium Development Goals.

17. On 7-8 December 2007, the Special Rapporteur also transmitted a statement to the Expert seminar on diversity in the broadcast media, organized by the non-governmental organization (NGO) Article 19 and the Institute of Information Law in Amsterdam. In his statement, the Special Rapporteur made a broad review of issues related to diversity in the media, including licensing, State advertising as well as diversity of outlets and content. At the same meeting, a joint declaration on promoting diversity in the broadcast media, signed by the Special Rapporteur, along with the Organization for Security and Development (OSCE) Representative on Freedom of the Media, the Organization of American States (OAS) Special Rapporteur on Freedom of Expression and the African Commission on Human and Peoples' Rights (ACHPR) Special Rapporteur on Freedom of Expression, was drafted. (The joint declaration appears as an annex to this report.)

## **D. Country visits**

18. From 22 to 28 April 2007, the Special Rapporteur carried out an official visit to Azerbaijan, at the Government's invitation, where he met a broad range of social and political actors to evaluate the current status of the right to freedom of opinion and expression. The Special Rapporteur underlined his impression that the country was endeavouring to establish and consolidate its democratic structures, a message that was conveyed by many of his counterparts. In his preliminary conclusions, he called upon the Government and civil society to take a number of steps to fully implement the right to freedom of expression, including the decriminalization of defamation offenses, ensuring the safety of media professionals and, more broadly, guaranteeing the independence of the media.

19. From 14 to 18 May 2007, the Special Rapporteur visited Ukraine at the invitation of the Government in order to assess the implementation of the right to freedom of opinion and expression in the country. In the conclusions of his visit, the Special Rapporteur highlighted the progresses achieved by the country after it gained independence from the Soviet Union. In particular, he underlined the important improvements that have taken place in the country since 2004. He also called upon the Government of Ukraine to further strengthen the independence, professionalism and diversity of the media as well as to tackle the issue of incitement to racial, ethnic and religious hatred.

20. From 26 to 30 November 2007, the Special Rapporteur carried out an official visit to Honduras at the invitation of the Government in order to examine issues of relevance to his mandate. In his conclusions on the visit, he pointed to the need for strengthening protection and safety measures for journalists and media professionals as well as the need to combat impunity for the perpetrators of crimes against the media. He also called for a rapid adaptation of national legislation on freedom of expression to international standards, particularly concerning the decriminalization of defamation offenses.

# **II. ISSUES**

# **A. Implementing the right of access to information**

#### **Censorship, suspension, closing or banning of media outlets**

21. The Special Rapporteur remains concerned at the widespread resort to censorship, direct or indirect, which remains in many regions of the world. Apart from direct censorship, many Governments have resorted to indirect ways to censor or shut down media outlets that express independent voices. The Special Rapporteur has received a number of communications concerning cases where Governments use overly subjective administrative regulations, particularly licensing and taxation, in order to close or suspend media outlets. Ultimately, the main impact of these policies is to create an uncertain environment for media professionals, thus fostering self-censorship and shunning any meaningful criticism of public policies and authorities.

22. Throughout 2007, the Special Rapporteur followed closely and with concern a substantial number of cases in which Governments suspended the operation of media outlets, particularly news channels that broadcast internationally, during large-scale public protests, electoral processes, states of emergency or public disorder. In most cases, these practices were designed to insulate the countries in question from the rest of the world, making invisible the human rights violations committed by State institutions, thus avoiding international criticism and pressure.

23. The new media, especially the Internet, have not remained free of censorship and direct repression. In past years, the Special Rapporteur has noted a growing trend of censorship and the banning of websites and Internet contributors, particularly bloggers. Due to the low cost, decentralized nature and great reach of the Internet, it has become an important outlet for the circulation of independent opinions about State authorities and policies. Many Governments therefore have developed an interest in controlling, monitoring and censoring the digital media, in particular the Internet, including by punishing hundreds of so-called cyber-dissidents around the world. In some cases, Internet use in private home

connections has been completely banned, thus allowing for total government oversight over Internet use by its citizens.

24. The Special Rapporteur further highlights the facts that, in several cases, these illegal restrictions on the right to freedom of opinion and expression have been accepted and even facilitated by leading Internet corporations, the majority of which are based in democratic countries. Search engines, for example, have accepted many Governments' imposition for strict controls and censorship, such as blocking "politically sensitive terms" of search results presented to individuals. Furthermore, the Special Rapporteur is deeply worried about many large Internet corporations who have disclosed personal information of their users to allow Governments to identify and convict internet writers.

#### **Diversity**

25. The Special Rapporteur emphasizes the importance of promoting diversity in the media. In particular, he stresses three fundamental dimensions of diversity that should be promoted: (a) diversity of outlets, in particular the establishment of a free environment for the creation and dissemination of outlets; (b) diversity of sources, especially taking advantage of the full benefits of digital platforms, in particular the Internet, to strengthen the right to freedom of opinion and expression; and (c) diversity of content, allowing for different communities and vulnerable groups to have access to media outlets and find ways to effectively disseminate their voice.

26. One of the central problems relating to the promotion of diversity refers to the licensing of media outlets. State-controlled licensing procedures have, in many countries, become a technical means of curbing media independence, particularly through normal and periodic procedures of renewal of licenses. These procedures have been used systematically by some Governments not as a regular administrative practice, but rather as a policy tool to wield influence over editorial content. The Special Rapporteur reiterates that, in order to guarantee freedom of the press, licensing should always be conducted by an independent authority, free from political interference by government officials. Furthermore, licensing procedures are only justified as a response to problems of scarcity, thus restricted to the broadcast media.

27. The exclusion of marginalized and vulnerable groups from the media is a key issue that needs to be addressed by the international community. Minorities, indigenous peoples, migrant workers, refugees and many other vulnerable communities have faced higher barriers, some of them insurmountable, to be able to fully exercise their right to impart information. For these groups, the media plays the central role of fostering social mobilization, participation in public life and access to information that is relevant for the community. Without a means to disseminate their views and problems, these communities are in effect shut down from public debates, which ultimately hinders their ability to fully enjoy their human rights.

28. The Special Rapporteur further stresses that diversity of content – in the broadcast, digital and printed media – is a desirable goal that should be encouraged. The strengthening of educational and cultural content and the increase in the space given to minorities and vulnerable groups to express their views, for example, can greatly increase the quality of the media outlets themselves. However, utmost care must be taken in order to prevent these goals from ultimately threatening the right to freedom of opinion and expression. The promotion of content diversity must not be used under any circumstances as a means to influence, directly or indirectly, the fundamental principle of editorial independence. The Special Rapporteur emphasizes that the most adequate means to promote diversity is not direct interference with media outlets, but rather more general measures to set up a free environment where independent media outlets and content producers can emerge and flourish. In this regard, the benefits of the Internet, particularly the way it allows even individual users to disseminate content on a global scale, should be duly taken into account and strengthened.

#### **Internet governance**

29. The issue of Internet governance has been a key focus of the Special Rapporteur in the implementation of his mandate, particularly in the preparation and follow-up of the World Summit on the Information Society, whose final phase was held in Tunis in 2005. Although the Summit itself focused chiefly on technical and business matters, overlooking human rights issues, it served as an opportunity for a number of NGOs to organize parallel events

and, ultimately, create networks for the implementation of a human rights-based approach to the information society.

30. The Internet, as well as other information and communication technologies, offers an unprecedented possibility to disseminate information, opinion and ideas to people who had traditionally been excluded from other media. However, the Special Rapporteur notes that the Internet also gives rise to important problems, such as child pornography, hate speech and privacy issues, which can only be addressed through a serious discussion focusing on governance.

31. The Special Rapporteur has suggested the establishment of an international organization to govern the Internet with a firm human rights approach as a priority for the United Nations and the international community. In particular, this organization would develop global norms and principles to guarantee that the Internet can be developed as a democratic medium of expression that is in full compliance with human rights principles. Ultimately, such an organization would develop, in cooperation with national institutions, the private sector and the civil society, common principles, norms and rules that should guide the future evolution and use of the Internet.

# **B. Safety and protection of journalists and media professionals**

32. In 2007, concern for the safety and protection of journalists remained one of the key obstacles for the full implementation of the right to freedom of opinion and expression. A total of 67 media professionals were kidnapped and 1,511 were physically attacked or threatened throughout the year. Even more worrying, 86 journalists and 20 other media workers were killed, which represents an increase of 244 per cent over the past five years and is the highest figure since 1994.**<sup>2</sup>**

33. Armed conflicts provide by far the highest threat to the security of media professionals. Over half of the journalists killed last year died in Iraq, the vast majority of whom worked for the local media. A number of reports reached the Special Rapporteur concerning deliberate attempts to target journalists, particularly by members of warring

**2** Reporters Without Borders, *Press Freedom Round-up 2007*; see www.rsf.org/article.php3?id\_article=24909, last accessed on 17 January 2008.

militia. As the clashes between Ethiopian-backed forces and the Islamist militia in Somalia grew, the country also saw a drastic increase in the number of journalists who were killed, totalling eight in 2007. In particular, two popular journalists, Ali Iman Sharmarke and Bashir Nor Gedi, were reportedly targeted and murdered by hired assassins, which illustrates the atmosphere of fear and pressure surrounding the work of media professionals operating in areas of armed conflict. Journalists were also killed in Afghanistan, Sri Lanka and the Democratic Republic of Congo, other areas of ongoing armed conflict.

34. The main provisions protecting journalists and other media professionals in situations of armed conflict come from humanitarian law, in particular from special measures contained in article 79 of Protocol I to the Geneva Conventions of 12 August 1949, relating to the protection of victims of international armed conflicts. This article establishes that "journalists engaged in dangerous professional missions in areas of armed conflict shall be considered as civilians" and "shall be protected as such under the Conventions and this Protocol, provided that they take no action adversely affecting their status as civilians". The civilian status of journalists transcends any type of contractual arrangement that the journalist may have; equal protection is granted to freelance, independent or to journalists belonging to any media.

35. In 2006, the Security Council passed resolution 1738 (2006) whereby it expressed its deep concern "at the frequency of acts of violence in many parts of the world against journalists, media professionals and associated personnel in armed conflict", and condemned intentional attacks against this group. It also underlined the obligation under humanitarian law to grant civilian status to journalists during armed conflicts, as established by the Geneva Conventions.

36. The Special Rapporteur emphasizes that States have an obligation to ensure the safety and protection of journalists and other media professionals in time of armed conflict. In these situations, journalism has a particularly important function, which is to convey the brutality and havoc created by war. Accurate reports from war zones are a fundamental component in establishing historical truths and allowing post-war reconciliation.

37. Apart from armed conflicts, the Special Rapporteur underscores the need to focus on the protection of journalists during electoral processes and public crises, particularly during states of emergency. Throughout 2007, the Special Rapporteur has received several reports of journalists who were directly targeted in physical attacks, both by government and opposition forces, in political demonstrations taking place during electoral processes. In various cases, harassment by the security forces, including arrests and detention, has been a common practice adopted against journalists who are reporting on human rights violations during these events.

38. The Special Rapporteur has recommended the establishment of a relief fund to benefit the relatives of media professionals killed in the line of duty because of their professional activities. Not only would such a fund provide needed reparation to families, but it would also serve to place the safety of journalists as a central human rights issue within the United Nations system.

## **C. Legal restrictions on freedom of opinion and expression**

#### **Defamation**

39. Defamation offenses have been one of the main sources of imprisonment of journalists around the world. Defamation laws were originally designed with a legitimate goal, which was to protect people against false statements of fact that could damage their reputation. In particular, they reflect the legitimate view that the exercise of freedom of expression, in particularly by media professionals, should be subject to responsibility, good judgement and professionalism. However, the subjective character of many defamation laws, their overly broad scope and their application within criminal law have turned them into a powerful mechanisms to stifle investigative journalism and silent criticism.

40. The Special Rapporteur is also concerned about the trend of increasing the scope of defamation laws to include the protection of subjective values, such as a sense of national identity, religions, State symbols, institutions or even representatives such as the Head of State. The Special Rapporteur reiterates that the provisions on protection of reputation contained in international human rights law are designed to protect individuals, not abstract values or institutions.

41. International human rights instruments recognize the right to a reputation (e.g. art. 12 of the Universal Declaration of Human Rights, which states that "No one shall be subject … to attacks upon his honour and reputation"). However, three clear-cut conditions must be respected for any limitation on the right to freedom of expression: (a) restrictions must be established in law; (b) they should pursue an aim recognized as lawful, and (c) they must be proportional to the accomplishment of that aim. A number of problems are often present in the actual implementation of these three conditions.

42. The Special Rapporteur is concerned about the large number of cases of journalists who are imprisoned after being convicted on criminal defamation charges. Apart from outright imprisonment and preventive detention, other common measures that have been taken against media professionals include the imposition of heavy fines, often completely inconsistent with a journalist's income, the suspension of the journalist's professional licence and even the suspension or closing of media outlets. The Special Rapporteur considers these measures as inconsistent with the principle of proportionality and therefore an undue restriction of press freedom. Furthermore, these measures are even more harmful for independent, local or freelance journalists, who are generally unable to afford the expenses of long judicial proceedings, legal counsel and fines.

43. In this regard, the Special Rapporteur, along with the OSCE Representative on Freedom of the Media and the OAS Special Rapporteur on Freedom of Expression, in a joint declaration issued in December 2002, stated that "criminal defamation is not a justifiable restriction on freedom of expression; all criminal defamation laws should be abolished and replaced, where necessary, with appropriate civil defamation laws". The Special Rapporteur notes with satisfaction that many countries have recently decided to abolish their criminal defamation laws. He reiterates that, while awaiting the entry of force of this legislation, emergency measures such as amnesty or pardon should be taken to ensure that no media profession or any other citizen is incarcerated on charges of defamation. Furthermore, any fines arising from civil defamation procedures should also respect the principle of proportionality and should never surpass reasonable amounts.

#### **States of exception and emergency**

44. The imposition of a state of emergency has led on many occasions to actions that are incompatible with the right to freedom of expression and, in particular, to a free media. The Special Rapporteur is concerned that, immediately after the imposition of a state of emergency, many Governments take aggressive action against freedom of expression in many different forms: by suspending TV news channels, blocking websites and telephone services, attacking detaining and arresting journalists covering protests and appointing government officials to monitor, and in effect censor, the content of newspapers. The Special Rapporteur has observed with concern how, in many of these cases, States have introduced laws giving government officials the authority to take unilateral action against media organizations.

45. Regulations under states of emergency often allow for arbitrary detentions and arrests, the banning of demonstrations which could lead to "public disorder" and the suspension of local assemblies or governments if they block or impede the legal actions of the public authorities. The right to freedom of opinion and expression is usually violated under situations of states of emergency. Journalists and other media practitioners face persecutions and attacks and it is difficult to obtain independent and reliable information, which is essential for society in these situations.

46. The Special Rapporteur emphasizes that emergency powers may be legitimate only in cases of extreme national crises which threaten the life of the nation. Those powers are defined and limited by articles 4 and 19, paragraph 3, of the International Covenant of Civil and Political Rights and, therefore, restrictions placed on rights are to be limited in both scope and duration "to the extent strictly required by the exigencies of the situation" (art. 4). In this context, a state of emergency is by definition a temporary legal response to an exceptional and grave threat to the nation, and must be treated as such. The principle of proportionality must be respected with respect to the duration and geographical and material scope of the state of emergency.

#### **Countering terrorism**

47. Throughout his mandate, the Special Rapporteur has paid close attention and strongly condemned the critical threat posed by terrorism in the contemporary world, whilst also noting the negative implications that some policies designed to fight terrorism have had on the full enjoyment of human rights. Counter-terrorism and national security legislation approved in recent years have on many instances exceeded the bounds of what is permissible

under international law and resulted in human rights violations. In this context, the right to freedom of opinion and expression is particularly vulnerable to legislation that de facto legitimates limitations on the free circulation and expression of ideas and opinions, directly affecting the work of media professionals, human rights defenders, political groups and civil society more broadly. Journalists and media professionals have become common targets of unlawful attempts to restrict freedom of expression.

48. The restrictions brought about by counter-terrorism legislation on human rights in general, and the right to freedom of opinion and expression in particular, have taken many forms. A number of allegations were brought to the Special Rapporteur's attention in this regard, including instances where Governments have passed laws that restrict individual liberties such as the right to privacy and to due process; arbitrary arrests and detentions conducted by the security apparatus; banning the publication of information that is, without justification, defined as being threatening to national security; forcing the disclosure of journalistic sources; censoring media outlets and journalists on the basis of an alleged proximity to terrorist or rebel groups.

49. The Special Rapporteur recalls that restrictions to the right to freedom of opinion and expression can only be imposed in rather exceptional circumstances. In this respect, the Special Rapporteur has referred in his previous reports, to General Comment No. 29 (CCPR/C/21/Rev.1/Add.11) of the Human Rights Committee, which establishes the conditions that must be met for a State to invoke article 4,paragraph 1, of the International Covenant on Civil and Political Rights (ICCPR), dealing with derogations to the rights enumerated thereto. Derogations established under article 4, paragraph 1, of the Covenant are exceptional in nature and can only be invoked when the situation within a State amounts to a public emergency which threatens the life of the nation and when the State party has officially declared a state of emergency. These restrictive measures imposed by the State must, inter alia, be strictly limited in time, provided for in a law, necessary for public safety or public order, serve a legitimate purpose, not impair the essence of the right, and conform to the principle of proportionality. The principles of legitimacy, necessity and proportionality must always be respected.

50. The Special Rapporteur also refers to Security Council resolution 1624 (2005) of 14 September 2005, which states that any restrictions to the right of freedom of expression, as reflected in article 19 of the Universal Declaration of Human Rights, must be in accordance with article 19, paragraph 3 (b), of the ICCPR, which states that any restrictions shall be those provided by law and necessary "for the protection of national security or of public order".

51. In many of the cases brought to the attention of the Special Rapporteur, most, if not all of the conditions that are required under article 4, paragraph 1, and 19, paragraph 3, of the ICCPR to derogate from the right to freedom of opinion or expression, are not being met. He has noted that there are cases in which the feeling of insecurity caused by terrorist attacks provides States with an opportunity to adopt measures in which national security is used as justification to allow for direct attacks against the free media, investigative journalism, political dissidence, and human rights monitoring and reporting.

52. The rights to peaceful assembly and to freedom of association, regulated under articles 21 and 22 of the ICCPR, are also often violated under counter-terrorism legislation. These rights should be considered essential to any democratic society. The Special Rapporteur has witnessed how, on certain occasions, peaceful actions or demonstrations have been considered terrorist acts by certain Governments. As such, peaceful demonstrators have been charged with acts of terrorism under counter-terrorism legislation, which gives the State legitimacy to suppress dissent.

53. The effective enjoyment of the right to freedom of opinion and expression, the right to peaceful assembly and freedom of association are central elements that mark the difference between democracy and terror. In this regard, in their legitimate fight to eradicate terrorism, democratic States must see that freedom and pluralism, two crucial parts of their very democratic foundations, are preserved at all times.

#### **D. Freedom of opinion and expression and the realization of other human rights**

# **HIV/AIDS**

54. Although the number of people dying from HIV/AIDS and related illnesses has declined in the last two years, the disease is among the leading causes of death globally, and

remains the primary cause of death in Africa. According to UNAIDS, there are over 5,700 deaths each day in the world due to HIV/AIDS.

55. The Special Rapporteur has stated in his previous reports that, without a vaccine or a cure, the main hope of reducing the devastating consequences of this disease resides – in parallel to making available universal affordable treatment in developing countries – is the widespread access to information and preventive education for HIV/AIDS. Prevention, treatment, care and support are mutually reinforcing elements that integrate an effective response to HIV/AIDS. Making information and education available are essential to effective efforts to combating this disease, as recognized by UNAIDS.

56. The Commission on Human Rights, in its resolution 2003/47 of 23 April 2003, recognized the importance of sharing knowledge, experiences and achievements concerning HIV-related issues, and urged States to promote effective programmes for the prevention of HIV/AIDS, including through education and awareness-raising campaigns. The Special Rapporteur has welcomed this resolution and has raised in several of his reports the relationship between access to information and HIV/AIDS prevention, calling upon States to facilitate access to information on HIV/AIDS for all their citizens.

57. Information and education do not only refer exclusively to issues that are directly related to HIV/AIDS transmission and prevention, but also to all those issues that have a clear impact on the spread of the epidemic, even if these are indirect. The Special Rapporteur has noted that the most successful campaigns seem to be those that are tailored to specific vulnerable groups. It is thus important that data collection methods be developed in such a manner as to precisely identify these groups, allowing for information and education campaigns to be targeted to their specific context

58. The Special Rapporteur is concerned that, according to statistics, some 2 million young people aged 15-24 years become infected with HIV every year. In sub-Saharan Africa and South Asia, about 65 per cent of young people living with HIV/AIDS are female. The Special Rapporteur has observed that in many countries women continue to be discriminated against, and he has emphasized the importance of promoting effective programmes of

information, particularly in rural areas. In this context, the Special Rapporteur calls upon States to allocate resources for programmes that are directed at adolescents and women for the prevention and treatment of this disease.

59. In most countries, people living with HIV/AIDS face discrimination. The Special Rapporteur places special importance on the promotion of campaigns that combat discriminatory attitudes and stigmatization of people living with HIV/AIDS. In this context, he encourages communities, teachers, journalists, doctors and, in particular, Governments to disseminate information addressing all HIV/AIDS-related issues, its modes of transmission and the means of protection. In particular, information on topics that may be considered as taboo or private – such as safe sex or drug abuse – should be explicit and made available in formats adapted and accessible to the society.

60. The United Nations, its agencies, funds and programmes have placed the fight against HIV/AIDS very high on the development agenda. The Special Rapporteur also notes with satisfaction that many donor countries have included HIV/AIDS among their priorities for development assistance. The Special Rapporteur encourages such trends and wishes to emphasize that it is only through a global response that the fight against HIV/AIDS can be addressed. The exchange of good practices between countries and the support to developing countries while implementing information and education programmes is crucial.

# **The 'digital divide'**

61. Throughout his mandate, the Special Rapporteur has seen an unprecedented expansion of communication and information technologies around the world. However, the promises of the information society still are not being shared among all. A wide gap between the information-rich and the information-poor still remains (the "digital divide") and does not show any encouraging signs of being reduced. It is important to note that the impact of the digital divide is not felt exclusively in developing and least developed countries, but also in vulnerable communities living in the industrialized world.

62. Narrowing the digital divide requires more than only technical efforts to extent the new communication and information technologies to marginalized communities, thus connecting them to the information society. Unfortunately, hundreds of millions of people around the world are illiterate, and many more are not proficient in the new technologies. In this regard, educational measures, in particular widespread literacy programmes, need to be promoted as the sole alternative for empowering people and prepare them to become active members of the information society. Besides traditional literacy programmes, new policies and programmes should be promoted in order to foster education for the new media as the most important empowerment tool for the twenty-first century.

# **Freedom of opinion and expression and freedom of religion**

63. In recent years, and with increased frequency, particularly due to events that dominated international politics recently, an alleged dichotomy between the right to freedom of opinion and expression and the right to freedom of religion or belief has been purported. In particular, it has been argued that the dogmatic use of freedom of expression as a fundamental human right has undermined people's ability to fully enjoy other human rights, in particular freedom of religion. The Special Rapporteur strongly rejects such a view, as it contradicts the clearly established notion and widely accepted principle that human rights are indivisible rather than rival principles. In particular, the ensemble of human rights can only be fully enjoyed in an environment that guarantees freedom and pluralism.

64. Practices such as stereotyping and insulting ethnic, national, social or religious groups have serious and damaging consequences for the promotion of dialogue and living together among different communities. To fight intolerance and discrimination and to create a solid basis for the strengthening of democracy, broad-based and long-lasting programmes and actions need to be developed to promote respect for diversity, multiculturalism and human rights education.

65. The Special Rapporteur also emphasizes that existing international instruments establish a clear limit on freedom of expression. In particular, the International Covenant on Civil and Political Rights provides that "any propaganda for war" and "any advocacy of national, racial or religious hatred that constitutes incitement to discrimination, hostility or violence shall be prohibited by law". The main problem thus lies in identifying at which point exactly these thresholds are reached. The Special Rapporteur underscores that this decision, which is ultimately a subjective one, should meet a number of requirements. In particular, it

should not justify any type of prior censorship, it should be clearly and narrowly defined, it should be the least intrusive means in what concerns limitations to freedom of expression and it should be applied by an independent judiciary. The Special Rapporteur reiterates that these limitations are designed to protect individuals rather than belief systems, guaranteeing that every person will have all of his or her human rights protected.

66. The Special Rapporteur notes that a broader interpretation of these limitations, which has been recently suggested in international forums, is not in line with existing international instruments and would ultimately jeopardize the full enjoyment of human rights. Limitations to the right to freedom of opinion and expression have more often than not been used by Governments as a means to restrict criticism and silent dissent. Furthermore, as regional human rights courts have already recognized, the right to freedom of expression is applicable not only to comfortable, inoffensive or politically correct opinions, but also to ideas that "offend, shock and disturb".**<sup>3</sup>** The constant confrontation of ideas, even controversial ones, is a stepping stone to vibrant democratic societies.

#### **III. CONCLUSIONS AND RECOMMENDATIONS**

67. **The right to freedom of opinion and expression, and the related rights of freedom of association and assembly, are fundamental human rights with far-reaching consequences for the enjoyment of all other rights. When freedom of opinion and expression is respected, Governments are held accountable, public policies are designed more effectively and people's voices are heard. Limiting the free circulation of ideals not diminishes plurality and diversity, but undermines democracy entirely.** 

68. **The Special Rapporteur urges Governments to conduct an in-depth assessment of existing national legislation as well as of judicial practices related to all forms of freedom of opinion and expression and to commence, whenever necessary, reform processes in order to guarantee conformity with international human rights norms and standards. The Special Rapporteur also recommends Governments to focus on the protection and the promotion of media independence as a priority, in order to ensure a constant advancement in the field of freedom of opinion and expression.** 

**<sup>3</sup>** *Arslan v. Turkey*, European Court of Human Rights, 1999.

#### **On censorship**

69. **The Special Rapporteur recommends that Governments adopt legislation that unambiguously prohibits all forms of censorship in media outlets, both in the traditional media and the Internet. Defamation, libel and insult charges, particularly when stemming from public figures and specifically State authorities, do not justify any form of prior censorship.** 

70. **Administrative and bureaucratic regulations of media outlets, including licensing, should be clearly established by law and overseen by independent institutions. The Special Rapporteur urges Governments not to make subjective use of these regulations as a means to exert undue pressure, suspend or ban media outlets.** 

71. **The Special Rapporteur urges Governments to extend the measures to protect freedom of opinion and expression to the Internet, in particular to website contributors and bloggers, who should be granted with the same level of protection as any other type of media. Internet providers and website registration with national authorities should not be subject to any specific requirement. The right to privacy of Internet users should be protected in all circumstances, except cases of child pornography and incitement to racial, religious and ethnic hatred. Any legal dispute arising from the use of the Web should be dealt with in the country where the website has its origin.**

#### **On diversity**

72. **The Special Rapporteur urges Governments to take the appropriate measures to create a free and enabling environment where a plurality of media outlets can exist. In this regard, adequate measures need to be taken to prevent the phenomenon of media concentration, in particular the creation of media monopolies that could endanger pluralism, affect media independence and increase the cost of information. These measures should be taken by independent institutions that are protected against political or other forms of interference, particularly from the Government. The legitimate aim of preventing media concentration should not be used as a justification to exert undue pressure on outlets that are critical or independent.** 

73. **Licensing should only be used when strictly necessary, as a technical tool to administer the scarcity of the airwaves. Licensing for abundant media, such as the Internet and the print media, is not a legitimate policy tool and violates the right to freedom of opinion and expression. Licensing should only be administered by an independent body that is insulated from government pressure and should not be used subjectively to ban or suspend independent media outlets, particularly television and radio channels.** 

#### **On Internet governance**

74. **The Special Rapporteur invites Governments to consider the possibility of establishing an international organization with a specific mandate to improve governance of the Internet. The mandate of the organization would be to develop norms and principles of conduct to guarantee that the Internet will continue to be a democratic medium of expression in full compliance with human rights principles. The Special Rapporteur vigorously emphasizes that any new intergovernmental body administering, partially or totally, Internet governance must ensure freedom of opinion and expression and promote it in the light of article 19 of the Universal Declaration of Human Rights.** 

**On the safety and protection of media professionals** 

75. **The Special Rapporteur recommends that Governments take the necessary measures to increase the safety and protection of journalists and other media workers, regardless of their professional and political affiliation. Protection must be ensured at all times, and particularly during armed conflicts, states of emergency and public disorder and electoral processes. Governments should also ensure the protection of other categories at risk, such as trade unionists, social workers, students and teachers, writers and artists. Eliminating impunity for the perpetrators of crimes against media professionals will function as an important deterrent against the repetition of these crimes.** 

76. **Governments and State institutions should, as appropriate, envisage the creation of ad hoc protection schemes, which would allow journalists to continue their activities with an acceptable level of security, while maintaining their independence. Media enterprises should also consider covering the expenses of flexible protection for** 

**endangered journalists. Media professionals should not, under any circumstances, be obliged to bear the economic burden of their physical protection, in addition to the mental stress of being at risk.** 

77. **The Special Rapporteur reiterates his call to the Human Rights Council to pay increased attention to the issue of the safety and protection of journalists, in particular in situations of armed conflicts. The Council may wish to consider the opportunity, as previously suggested, of entrusting the Special Rapporteur with the preparation of a study on the causes of violence against media professionals, based, inter alia, on information from and the experiences of Governments, intergovernmental and nongovernmental organizations, and including a comprehensive set of conclusions and recommendations and the drafting of guidelines for the protection of journalists and other media professionals. This study could represent the first step towards a debate, within the Human Rights Council, on this crucial issue, following the discussions held by other bodies, including the Security Council.**

## **On defamation offences**

78. **The Special Rapporteur strongly recommends that Governments decriminalize defamation and similar offences, confining them to the domain of civil law. The amount of fines to be paid as compensation should be reasonable and allow the continuation of professional activities. The Special Rapporteur also urges Governments to release immediately and unconditionally all journalists detained because of their media-related activities. Prison sentences should be excluded for offences concerning the reputation of others, such as defamation and libel.** 

79. **Governments should also refrain from introducing new norms which will pursue the same goals as defamation laws under a different legal terminology such as disinformation and dissemination of false information. Under no circumstances should criticism of the nation, its symbols, the Government, its members and their action be seen as an offence. Elected officials and authorities should accept the fact that because of their prominent and public role, they will attract a disproportionate amount of** 

**scrutiny from the press. Governments should also make sure that the right to privacy, especially in relation to family life and minors, is sufficiently protected without curtailing the right to access to information, which contributes to transparency and democratic control of public affairs.**

#### **On freedom of expression and HIV/AIDS**

80. **The Special Rapporteur underlines that the level of protection of human rights in a country has a direct impact on the spread of the AIDS epidemic. In this regard, the right to freedom of opinion and expression, in particular the right to receive information concerning HIV/AIDS, is a central aspect of efforts to tackle the problem.** 

81. **The Special Rapporteur urges Governments to rely on preventive education and information strategies as one of the main defences, alongside care and treatment, against the spread of the HIV/AIDS epidemic. The extensive use of the mass media is necessary to ensure the widest coverage of information campaigns. More generally, information and education should be provided through all available and accessible means. The Special Rapporteur encourages States to cooperate with the media, NGOs and community-based organizations in this endeavour.** 

82. **The Special Rapporteur strongly believes that general respect for and protection of freedom of opinion and expression have a direct impact on the effectiveness of education and information policies, programmes and campaigns for the purpose of HIV/AIDS prevention. He therefore urges Governments to set a framework for the better protection of freedom of opinion and expression and for free flow of information and communications vis-à-vis the general public, as well as specific groups and communities.** 

#### **On the 'digital divide'**

83. **The Special Rapporteur urges Governments to take measures to increase the affordability and availability of new communication and information technologies, particularly the Internet, to poor and vulnerable communities (to bridge the "digital divide"). Furthermore, apart from technical efforts to increase access, computer literacy programmes should be devised and widely disseminated in order to prepare the** 

**less favoured segments of the population to take the full benefits of the new technologies.**

**On freedom of expression and freedom of religion** 

84. **The Special Rapporteur urges media professionals, as well as the public at large, to be conscious of the potential impact that the ideas they express may have in raising cultural and religious sensitivities. The dissemination of intolerant and discriminatory opinions ultimately promotes discord and conflict and is not conducive to the promotion of human rights. Media corporations and journalists' associations, in cooperation with national and international organizations, should organize regular human rights training programmes in order to enhance professional ethics and sensitivity to cultural diversity of media professionals.** 

85. **The Special Rapporteur further emphasizes that, although limitations to the right to freedom of opinion and expression are foreseen in international instruments to prevent war propaganda and incitement of national, racial or religious hatred, these limitations were designed in order to protect individuals against direct violations of their rights. These limitations are not intended to suppress the expression of critical views, controversial opinions or politically incorrect statements. Finally, they are not designed to protect belief systems from external or internal criticism.** 

#### **ANNEX**

#### **Joint declaration on** promoting diversity in the broadcast media

 The United Nations Special Rapporteur on freedom of opinion and expression, the Organization for Security and Cooperation in Europe (OSCE) Representative on Freedom of the Media, the Organization of American States (OAS) Special Rapporteur on Freedom of Expression and the African Commission on Human and Peoples' Rights (ACHPR) Special Rapporteur on Freedom of Expression and Access to Information,

 *Having met* with representatives of NGOs, academics and other experts in Amsterdam on 7-8 December 2007, under the auspices of ARTICLE 19, the Global Campaign for Free Expression, and assisted by the Institute for Information Law (IViR), University of Amsterdam,

 *Recalling and reaffirming* our Joint Declarations of 26 November 1999, 30 November 2000, 20 November 2001, 10 December 2002, 18 December 2003, 6 December 2004, 21 December 2005 and 19 December 2006,

 *Stressing* the fundamental importance of diversity in the media to the free flow of information and ideas in society, in terms both of giving voice to and satisfying the information needs and other interests of all, as protected by international guarantees of the right to freedom of expression,

 *Cognizant*, in particular, of the importance of diversity to democracy, social cohesion and broad participation in decision-making,

 *Aware* of the potential of new technologies both to serve as vehicles for promoting diversity but also to pose new threats to diversity, including as a result of the digital divide,

 *Emphasizing* the complex nature of diversity, which includes diversity of outlet (types of media) and source (ownership of the media), as well as diversity of content (media output),

 *Recognizing* the varied contributions that different types of broadcasters – commercial, public service and community – as well as broadcasters of different reach – local, national, regional and international – make to diversity,

 *Noting* that undue concentration of media ownership, direct or indirect, as well as government control over the media, pose a threat to diversity of the media, as well as other risks, such as concentrating political power in the hands of owners or governing elites,

 *Stressing* that independent public service broadcasters will continue to play an important role in promoting diversity in the new digital broadcasting environment, including through their unique role in providing reliable, high-quality and informative programming,

 *Mindful* of the potential for abuse of regulatory systems for the media to the detriment, among other things, of diversity, particularly where oversight bodies are not sufficiently protected against political or other interference,

 *Concerned* about the growth of a number of threats to the viability of public service broadcasting in different countries, which undermine its ability to fulfil its potential to contribute to media diversity, as well as the failure of many countries to recognize community broadcasting as a distinct type of broadcasting,

 *Adopt*, on 12 December 2007, the following declaration on promoting diversity in the broadcast media:

# **General points**

 -Regulation of the media to promote diversity, including governance of public media, is legitimate only if it is undertaken by a body which is protected against political and other forms of unwarranted interference, in accordance with international human rights standards;

 - Broad public education and other efforts should be undertaken to promote media literacy and to ensure that all members of society can understand and take advantage of new technologies with a view to bridging the digital divide;

- Transparency should be a hallmark of public policy efforts in the area of broadcasting;

 - This should apply to regulation, ownership, public subsidy schemes and other policy initiatives;

 - Low-cost technologies that are widely accessible should be promoted with a view to ensuing broad access to new communications platforms. Technological solutions to traditional problems of access – including in relation to hearing or visual disabilities – should be explored and promoted;

 - Measures should be put in place to ensure that government advertising is not used as a vehicle for political interference in the media;

#### **On diversity of outlets**

 - Sufficient 'space' should be allocated to broadcasting uses on different communications platforms to ensure that, as a whole, the public is able to receive a range of diverse broadcasting services. In terms of terrestrial dissemination, whether analogue or digital, this implies an appropriate allocation of frequencies for broadcasting uses;

 - Different types of broadcasters – commercial, public service and community – should be able to operate on, and have equitable access to, all available distribution platforms. Specific measures to promote diversity may include reservation of adequate frequencies for different types of broadcasters, must-carry rules, a requirement that both distribution and reception technologies are complementary and/or interoperable, including across national frontiers, and non-discriminatory access to support services, such as electronic programme guides;

 - Consideration of the impact on access to the media, and on different types of broadcasters, should be taken into account in planning for a transition from analogue to digital broadcasting. This requires a clear plan for switchover that promotes, rather than limits, public interest broadcasting. Measures should be taken to ensure that digital transition costs do not limit the ability of community broadcasters to operate. Where appropriate, consideration should be given to reserving part of the spectrum for analogue radio broadcasting for the medium-term. At least part of the spectrum released through the "digital dividend" should be reserved for broadcasting uses;

 - The least intrusive effective system for the administration of broadcasting to promote diversity should become used, taking into account reductions in the problem of scarcity. Licensing, justified by reference to the airwaves as a limited public resource, is not legitimate for Internet broadcasting;

 - Special measures are needed to protect and preserve public service broadcasting in the new broadcasting environment. The mandate of public service broadcasters should be clearly set out in law and include, among other things, contributing to diversity, which should go beyond offering different types of programming and include giving voice to, and serving the information needs and interests of, all sectors of society. Innovative funding mechanisms for public service broadcasting should be explored which are sufficient to enable it to deliver its public service mandate, which are guaranteed in advance on a multi-year basis, and which are indexed against inflation;

- Community broadcasting should be explicitly recognised in law as a distinct form of broadcasting, should benefit from fair and simple licensing procedures, should not have to meet stringent technological or other licence criteria, should benefit from concessionary licence fees and should have access to advertising;

#### **On diversity of sources**

 - In recognition of the particular importance of media diversity to democracy, special measures, including anti-monopoly rules, should be put in place to prevent undue concentration of media or cross-media ownership, both horizontal and vertical. Such measures should involve stringent requirements of transparency of media ownership at all levels. They should also involve active monitoring, taking ownership concentration into account in the licensing process, where applicable, prior reporting of major proposed combinations, and powers to prevent such combinations from taking place;

 - Consideration should be given to providing support, based on equitable, objective criteria applied in a non-discriminatory fashion, to those wishing to establish new media outlets;

## **On diversity of content**

 - Policy tools could be used, where this is consistent with international guarantees of freedom of expression, to promote content diversity among and within media outlets;

 - Consideration should be given to providing support, based on equitable, objective criteria applied in a non-discriminatory fashion, for the production of content which makes an important contribution to diversity. This might include measures to promote independent content producers, including by requiring public service broadcasters to purchase a minimum quota of their programming from these producers;

 - An appropriate balance should be struck between protection of copyright and adjacent rights, and promoting the free flow of information and ideas in society, including through measures which result in a strengthening of the public domain.

Signed,

#### Ambeyi Ligabo

United Nations Special Rapporteur on freedom of opinion and expression

Miklos Haraszti OSCE Representative on Freedom of the Media

Ignacio Alvarez OAS Special Rapporteur on Freedom of Expression

Faith Pansy Tlakula ACHPR Special Rapporteur on Freedom of Expression

- - - - -
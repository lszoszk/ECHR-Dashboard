![](_page_0_Picture_2.jpeg)

# **Economic and Social Council**

Distr. GENERAL

E/CN.4/1995/32 14 December 1994

ENGLISH Original: ENGLISH/FRENCH

COMMISSION ON HUMAN RIGHTS Fifty-first session Item 10 of the provisional agenda

> QUESTION OF THE HUMAN RIGHTS OF ALL PERSONS SUBJECTED TO ANY FORM OF DETENTION OR IMPRISONMENT

> > Promotion and protection of the right to freedom of opinion and expression

Report of the Special Rapporteur, Mr. Abid Hussain, pursuant to Commission on Human Rights resolution 1993/45

# CONTENTS

| | | | Paragraphs | Page |
|--------------|-------|------------------------------------------------------------------------------------------------------------|---------------|------|
| Introduction | | | 1<br>-<br>11 | 3 |
| I. | TERMS | OF<br>REFERENCE | 12<br>-<br>55 | 4 |
| | A. | The<br>nature<br>and<br>scope<br>of<br>the<br>right<br>to<br>freedom<br>of<br>opinion<br>and<br>expression | 14<br>-<br>37 | 5 |
| | B. | Restrictions<br>and<br>limitations<br>to<br>the<br>right<br>to<br>freedom<br>of<br>expression | 38<br>-<br>55 | 10 |
| II. | | METHODS<br>OF<br>WORK | 56<br>-<br>70 | 14 |
| | A. | Information | 58<br>-<br>59 | 14 |
| | B. | Communications | 60<br>-<br>65 | 15 |
| | C. | Consultations | 66 | 15 |

## CONTENTS (continued)

| | | Paragraphs | Page |
|------|---------------------------------------------------------------------|-----------------|------|
| | D.<br>Visits | 67 | 16 |
| | E.<br>Cooperation<br>with<br>other<br>human<br>rights<br>procedures | 68<br>-<br>69 | 16 |
| | F.<br>Other<br>activities | 70 | 16 |
| III. | ACTIVITIES | 71<br>-<br>95 | 16 |
| | A.<br>Information | 71<br>-<br>75 | 16 |
| | B.<br>Communications | 76<br>-<br>80 | 17 |
| | C.<br>Consultations | 81 | 18 |
| | D.<br>Visits | 82<br>-<br>89 | 18 |
| | E.<br>Cooperation<br>with<br>other<br>human<br>rights<br>procedures | 90 | 20 |
| | F.<br>Other<br>activities | 91 | 20 |
| | G.<br>Resources | 92<br>-<br>95 | 20 |
| IV. | COUNTRY<br>SITUATIONS | 96<br>-<br>128 | 21 |
| | Algeria | 96<br>-<br>100 | 21 |
| | Bangladesh | 101<br>-<br>103 | 25 |
| | China | 104<br>-<br>106 | 26 |
| | India | 107<br>-<br>109 | 28 |
| | Ethiopia | 110<br>-<br>112 | 30 |
| | Hungary | 113<br>-<br>115 | 31 |
| | Republic<br>of<br>Korea | 116<br>-<br>118 | 32 |
| | Tunisia | 119<br>-<br>121 | 33 |
| | Turkey | 122<br>-<br>128 | 36 |
| V. | CONCLUSIONS<br>AND<br>RECOMMENDATIONS | 129<br>-<br>146 | 43 |
| | | | |

## Introduction

1. At its forty-ninth session, the Commission on Human Rights decided by its resolution 1993/45 of 5 March 1993, to appoint, for a period of three years, a special rapporteur on the promotion and protection of the right to freedom of opinion and expression.

2. In the same resolution the Commission on Human Rights requested the Special Rapporteur to gather all relevant information, wherever it might occur, of discrimination against, threats or use of violence and harassment, including persecution and intimidation, directed at persons seeking to exercise or to promote the exercise of the right to freedom of opinion and expression as affirmed in the Universal Declaration of Human Rights and, where applicable, the International Covenant on Civil and Political Rights, taking into account the work being conducted by other mechanisms of the Commission and Sub-Commission on Prevention of Discrimination and Protection of Minorities which touched on that right, with a view to avoiding duplication of work.

3. The Commission on Human Rights also requested the Special Rapporteur, as a matter of high priority, to gather all relevant information, wherever it might occur, of discrimination, threats or use of violence and harassment, including persecution and intimidation, against professionals in the field of information seeking to exercise or to promote the exercise of the right to freedom of opinion and expression as affirmed in the Universal Declaration of Human Rights and, where applicable, the International Covenant on Civil and Political Rights.

4. The Commission further requested the Special Rapporteur to seek and receive credible and reliable information from Governments, non-governmental organizations and any other parties who had knowledge of those cases.

5. Finally, the Commission requested the Special Rapporteur to submit to the Commission, beginning at its fiftieth session, a report covering the activities relating to his or her mandate, noting the work being conducted by other mechanisms of the Commission and Sub-Commission which touches on the right to freedom of expression and opinion, containing recommendations to the Commission and providing suggestions on ways and means to better promote and protect the right to freedom of opinion and expression in all its manifestations, as affirmed in the Universal Declaration of Human Rights and, where applicable, the International Covenant on Civil and Political Rights.

6. The Commission on Human Rights urged all Governments to cooperate with and assist the Special Rapporteur in the performance of his tasks and to furnish all information requested, and requested the Secretary-General to provide the Special Rapporteur with all necessary assistance, in particular the staff and resources deemed necessary, within existing overall United Nations resources, to fulfil his mandate.

7. On 2 April 1993, Mr. Abid Hussain (India) was appointed Special Rapporteur on the promotion and protection of the right to freedom of opinion and expression.

8. The Economic and Social Council, in its decision 1993/268, of 28 July 1993, approved the Commission's decision to appoint a special rapporteur and its request to the Secretary-General to provide him with all necessary assistance. Resources were made available to the Centre for Human Rights in November 1993 enabling the Special Rapporteur to initiate his work at the end of 1993.

9. On 26 January 1994, the Special Rapporteur presented a report to the fiftieth session of the Commission on Human Rights (E/CN.4/1994/33) in which he presented some initial observations on the terms of reference and methods of work of his mandate and in which he requested that attention be paid by the Commission on Human Rights at its fiftieth session to the critical situation concerning the resources available to him which the Special Rapporteur felt did not meet the minimum required to carry out his work in a satisfactory manner.

10. In its resolution 1994/33 of 4 March 1994, the Commission welcomed the observations contained in the report of the Special Rapporteur on the methods of work, in particular on the means of responding effectively to information which comes before him and requested him to submit to the Commission at its fifty-first session a report covering the activities relating to his mandate.

11. In chapter I of the present report the Special Rapporteur presents observations on the terms of reference that constitute the legal framework within which he will carry out his mandate. Chapter II sets out the methods of work that he is using or envisages using in the fulfilment of his mandate. In chapter III the Special Rapporteur elaborates on the activities he has undertaken in the fulfilment of his mandate. Chapter IV deals with country situations. In the last section of the report the Special Rapporteur presents preliminary conclusions and recommendations.

#### I. TERMS OF REFERENCE

12. As the Special Rapporteur indicated in paragraph 40 of his previous and first report (E/CN.4/1994/33), he would like to touch on certain more basic questions in determining the nature and scope of the right to freedom of expression as a prerequisite for action to be undertaken by him. In this chapter the Special Rapporteur makes a beginning with this component of his work. He presents some considerations on the nature and scope of the right to freedom of expression, as well as on its permissible restrictions, for the purpose of clarifying the legal framework within which he will carry out his mandate and that he has previously considered in paragraphs 7-23 of his last report.

13. As the Special Rapporteur indicated in paragraph 25 of his previous report, his work will also involve the study of phenomena related to the enjoyment of the right to freedom of opinion and expression. In this report the Special Rapporteur presents some preliminary considerations on these phenomena, as yet only in relation to his visit to Malawi. He intends to take up this aspect in greater detail in his next report.

## A. The nature and scope of the right to freedom of opinion and expression

14. The right to freedom of opinion and expression is a core right of the International Covenant on Civil and Political Rights. It is both a civil right, in its capacity of protecting this sphere of life of the individual against undue infringements of the State, and a political right, in its capacity of guaranteeing the participation of the individual in political life, including that of State institutions. As such, the right to freedom of expression can be described as an essential test right, the enjoyment of which illustrates the degree of enjoyment of all human rights enshrined in the United Nations Bill of Rights, that comprises the Universal Declaration of Human Rights, the International Covenant on Economic, Social and Cultural Rights and the International Covenant on Civil and Political Rights. The respect for this right reflects a country's standard of fair play, justice and honesty.

15. Article 19 of the International Covenant on Civil and Political Rights reads:

"1. Everyone shall have the right to hold opinions without interference.

"2. Everyone shall have the right to freedom of expression; this right shall include freedom to seek, receive and impart information and ideas of all kinds, regardless of frontiers, either orally, in writing or in print, in the form of art, or through any other media of his choice.

"3. The exercise of the rights provided for in paragraph 2 of this article carries with it special duties and responsibilities. It may therefore be subject to certain restrictions, but these shall only be such as are provided by law and are necessary:

"(a) For respect of the rights or reputations of others;

"(b) For the protection of national security or of public order (ordre public), or of public health or morals."

16. The right to freedom of opinion and expression comprises a number of basic elements that define its content and which the Special Rapporteur would like to consider in order to determine the nature and the scope of this right. These basic elements include the terms "freedom", "opinion", "expression", "information and ideas" and "duties and responsibilities".

17. In order to better grasp the boundaries of the scope of protection offered by the right to freedom of expression the Special Rapporteur addresses the question of restrictions and limitations to this right, including the permissible purposes of these restrictions and limitations. The Special Rapporteur envisages, at a later stage, addressing the question of sanctions affecting persons who express their opinions.

18. The Special Rapporteur furthermore considers the right to freedom of opinion and expression in relation to a number of articles other than article 19 of the International Covenant on Civil and Political Rights, notably article 20 on the prohibition of propaganda for war and advocacy of

hatred; article 18 on freedom of thought, conscience, religion and belief; and article 17 on the right to privacy. He envisages considering at a later stage the right to freedom of opinion and expression in relation to the general provisions of the Covenant in its Part II (arts. 2-5).

#### The notion of freedom

19. At the outset of the Special Rapporteur's attempt at clarifying the nature and scope of the right to freedom of opinion and expression, he would like to address the question of the nature of the freedom concerned. Fundamental to the right to freedom of expression is the dual conception of freedom on which it is founded. From this dual conception of freedom flows much of the scope of protection of this right. The two fundamental elements of the conception of freedom are the freedom of access to the State and the freedom from the State. The former refers to the participation of the individual in matters of the State. It has a collective connotation and leads into the realm of the freedom of individuals to assemble and organize among themselves. The latter refers to the realm of privacy of the individual and requires absolute protection against any undue external interference. Here, in principle, the State is not obligated to guarantee the right with positive measures. Only in cases where the expression of an opinion interferes directly with the rights of others or where it constitutes a direct threat to the society is the Government obligated to intervene.

20. These two fundamental elements of the conception of freedom can be traced to liberal thinking. They have been magnificently captured by John Stuart Mill in an often quoted passage from his "Essay on Liberty" (1859). He writes, when discussing the appropriate region of human liberty:

"It comprises, first, the inward domain of consciousness; demanding liberty of conscience, in the most comprehensive sense; liberty of thought and feeling; absolute freedom of opinion and sentiment on all subjects, practical or speculative, scientific, moral, or theological. The liberty of expressing and publishing opinions may seem to fall under a different principle, since it belongs to that part of the conduct of an individual which concerns other people; but, being almost of as much importance as the liberty of thought itself, and resting in great part on the same reasons, is practically inseparable from it. Secondly, the principle requires liberty of tastes and pursuits; of framing the plan of our life to suit our own character; of doing as we like, subject to such consequences as may follow: without impediment from our fellow-creatures, so long as what we do does not harm them, even though they should think our conduct foolish, perverse, or wrong. Thirdly, from this liberty of each individual, follows the liberty, within the same limits, of combination among individuals; freedom to unite, for any purpose not involving harm to others: the persons combining being supposed to be of full age, and not forced or deceived." (In: Walter Laqueur and Barry Rubin (eds.), The Human Rights Reader, New York (revised edition), 1990; p. 87.)

21. Next to the liberal conception of freedom its socialist counterpart should be considered. In this conception freedom should be understood as a directive to be free and its aim is not so much warding off interference of the State in the private realm of the individual but rather the social integration of the individual in society.

22. Both conceptions of freedom have been the subject of abuse for immediate political purposes. In many instances, and until this day, the liberal conception of freedom has led to the neglect in practice by many States of the necessity for many of the developing countries to begin by building up a political and legal framework before being able to properly guarantee civil and political rights. Many developing countries argue that such efforts require not only political commitment but also resources on the part of the State. Alternatively, the socialist conception of freedom has led to the subjugation, even in constitutional and statutory law, of the legitimate enjoyment of those aspects of freedom that are related to a private sphere of the individual as completely distinct from and beyond the legitimate interference by the State. Socialist government has thus allowed for undue and virtually unchecked domination of the State over the private lives of its citizens.

23. Both conceptions of freedom have, in a more positive light, contributed to the understanding that the protection and promotion of human rights require - and, in legal terms, obligate - the State to take action or refrain from doing so whenever human rights so require, either to protect individuals from undue interference by the State or by third parties, or to safeguard their effective participation in the social, cultural, civil, economic and political life of society. This understanding resulted from the clash of the ideas of liberalism and socialism where they touched upon the issue of human rights. It will guide the Special Rapporteur in his endeavours to promote and protect the right to freedom of opinion and expression.

#### Freedom of opinion

24. During the discussion at the Commission on Human Rights on the formulation of article 19, freedom of opinion was said to be strictly a private matter while freedom of expression was said to be a public one. The freedom to form an opinion was held to be absolute and, in contrast to freedom of expression, not allowed to be restricted by law or any other power. It is for these reasons that the Covenant in article 19 (1) declares an independent right to hold opinions without interference. The absolute character of the protection offered by article 19 (1) is furthermore underlined by article 19 (3), which stipulates that special duties and responsibilities are only carried with the exercise of the rights provided for in paragraph 2 of article 19, i.e. solely the right to freedom of expression and not the right to hold opinions.

25. Exactly what aspects of the private realm of the individual are covered by the notion of "opinion" is unclear. It is clear, however, that freedom of opinion should be distinguished from, yet at the same time is closely linked to, the freedom of thought that is protected in article 18 of the Covenant. On the relationship between opinion and thought one knowledgeable author has remarked that the notion of thought may be nearer to religion or other beliefs and the notion of opinion nearer to political convictions. Another knowledgeable author noted that the expression of an opinion relates to

secular and political matters rather than religious ones and the expression of a thought relates to religious matters rather than secular ones. The Special Rapporteur notes that these interpretations appear to be linked primarily to the articles of the Conventions wherein we find the notions of thought and opinion. He stresses that he finds the frontiers between the notions of thought and opinion not very clear. As a consequence the protection of the freedom of opinion calls for the careful consideration of the specific aspects of each individual case.

26. The prohibition to interfere with the freedom of opinion is directed not only at interference by the State but also at interference by private parties. The Special Rapporteur recalls in this respect that the majority of the delegates that were involved in the drafting of article 19 (1) voiced support for protection against every form of interference. This recognition of horizontal effects implies that States parties to the Covenant are also obligated pursuant to article 2 (1) to protect freedom of opinion against interference by third parties.

27. What exactly constitutes an impermissible interference with the freedom of opinion is not an easy matter to determine. In general, it is possible to speak of such an interference when an individual is influenced against his will and when this influence is exerted by threat, coercion or the use of force.

#### Freedom of expression

28. At the outset of the attempt to clarify the notion of "expression", that is referred to in article 19 (2), the Special Rapporteur would like to remark that in his opinion it is hard to see how the act of seeking or receiving information can be included in the act of expression as is suggested by the wording of article 19 (2). Having said this, the Special Rapporteur notes that the scope of protection by article 19 (2) leads into the area of public life and thereby touches upon a fundamental aspect of democracy. This scope is clarified by the following jurisprudential considerations.

29. The European Court of Human Rights expressed the opinion that freedom of expression is applicable not only to information and ideas that are favourably received or regarded as inoffensive or as a matter of indifference, but also to those that offend, shock or disturb the State or any sector of the population. The European Court furthermore stated that such are the demands of pluralism, tolerance and broadmindedness without which there can be no democratic society.

30. A judge from India held that there can indeed be no freedom unless thought is free and unrestricted; not free thought for those who agree but freedom for the thought others or we ourselves dislike. It is only from the clash of ideas that truth can emerge, for the best test of truth is the power of thought to get itself accepted in the competition of the market of ideas. Freedom of expression is central to that competition.

31. Freedom of expression is protected in article 19 (2) with respect to "information and ideas of all kinds". This implies that every communicable type of idea, information, opinion, news, advertising, art, critical political commentary, etc. falls within the scope of protection. Also, as the travaux préparatoires of the International Covenant on Civil and Political Rights indicate, the anonymous publication of an opinion or of information is protected by article 19 (2). Most importantly, it is impossible, in view of the wording of article 19 as a whole, to attempt to exclude undesirable opinions or expressions, such as blasphemy or pornography, solely by restrictively defining or interpreting the scope of protection offered by article 19 (2). On the other hand, the exercise of the right to freedom of expression carries with it special duties and responsibilities on the question of which the Special Rapporteur elaborates below.

32. With respect to the ways in which information and ideas of all kinds can be sought, received or imparted, the relationship between articles 19 and 17 of the Covenant should be borne in mind. Article 17 refers to correspondence as such a means. Letters and conversations, however, do fall within the scope of protection of article 19. As does, it can be imagined, the expression of feelings. Article 19 furthermore expressly mentions oral, written and printed communication as well as works of art and "any other media of his choice". The scope of protection offered by article 19 is therefore quite comprehensive, as is also confirmed by the travaux préparatoires of the Covenant.

33. To guide his future interpretation of article 19, the Special Rapporteur notes that the travaux préparatoires indicate a strong will on the part of the negotiating parties to the Covenant to protect the content of messages imparted by the media. No provision, for example, was included in the article dealing with the licensing of media enterprises. Here it should be added that with the age of soap-box oratory and political pamphleteering coming to an end, television has become the most powerful medium for the communication of ideas and the dissemination of information. The enjoyment of freedom of expression therefore includes the freedom to use such a medium.

## Information

34. The freedom to seek information is guaranteed in article 19 (2). It entails the right to seek information inasmuch as this information is generally accessible. It is subject to debate whether the press and other media can derive any privileged right to seek information above and beyond generally accessible information. In this respect the Special Rapporteur would like to note the important role the press and other media have to play in imparting information, and thereby informing the general public of all events to their interest. Bearing in mind the aforementioned dual notion of freedom, its element concerning the freedom of the individual from the State necessarily entails that the individual in his private realm is protected against undue interference by the State with respect to information only or mainly accessible to the State. The Special Rapporteur notes that this aspect of the freedom to seek information touches on the right to privacy as protected under article 17 of the Covenant and begets added weight in our era of information and electronic means of communication.

35. In contemporary society, because of the social and political role of information, the right of everyone to receive information and ideas has to be carefully protected. This right is not simply a converse of the right to

impart information but it is a freedom in its own right. The right to seek or have access to information is one of the most essential elements of freedom of speech and expression. Freedom will be bereft of all effectiveness if the people have no access to information. Access to information is basic to the democratic way of life. The tendency to withhold information from the people at large is therefore to be strongly checked.

#### Duties and responsibilities

36. In article 19 (3) reference is made to special duties and responsibilities. The Special Rapporteur notes that the emphasis on special duties and responsibilities in article 19 contrasts with the general nature of the Covenant that establishes rights of the individual and duties of States. The special duty and responsibility referred to can therefore be said to be part of the general principle that is embodied in human rights that are horizontally effective. This means that the exercise of freedom of expression might entail a violation of the rights of others. Examples of such horizontal effects can be found in the realm of privacy, the influencing of public opinion, or the monopolization of the press. Thus, these responsibilities obligate the opinion makers not to abuse their power at the expense of others and obligate the State to interfere in such cases where the rights of others are violated. Also, they obligate the State to take action in those instances where a concentration of the media threatens the diversity of opinion or the access to published opinion. As indicated in the travaux préparatoires of the Covenant, the reference to special duties and responsibilities was included in article 19 for the purpose of offering States the possibility to counter such abuse of power by mass media.

37. The issue of duties and responsibilities was subject to some debate during the travaux préparatoires. Those who opposed proposals stipulating that the right to freedom of expression carries with it duties and responsibilities contended that the general purpose of the Covenant was to set forth civil and political rights and to guarantee and protect them rather than to lay down duties and responsibilities and to impose these upon individuals. It was furthermore contended that since each right carried with it a corresponding duty and since in no other article was this corresponding duty of any right set out, article 19 should not be an exception to this rule. It was principally upon the argument that the modern media could exert a powerful influence on the exercise and enjoyment of freedom of expression that those supporting proposals to include a reference to duties and responsibilities in the article maintained their position. It was for these reasons that in the ultimately adopted text of article 19 the word "special" was included before the words "duties and responsibilities".

## B. Restrictions and limitations to the right to freedom of expression

38. Article 19 (3) lists the permissible purposes for State interference with the right to freedom of expression. A closer look at the travaux préparatoires reveals that at a given point in time during the negotiating process a choice had to be made between inserting a general limitations clause in the article or inserting an exhaustive listing of all permissible purposes for interference. Article 19 (3) results from a compromise arrived at between these two different positions.

39. The entire discussion on permissible restrictions to the right to freedom of opinion and expression related to freedom of expression and excluded freedom of opinion. In this respect, paragraph 3 of article 19 leaves no room for misunderstandings. No interference with the right to hold opinions is allowed.

40. Article 19 (3) of the Covenant refers only to "restrictions" which may, in the eyes of the Special Rapporteur, include procedural matters and formalities such as taxation of printed works and the licensing of broadcasting companies, or penalties such as on criminal offences for the purpose of protecting the rights of others. In this respect, the Special Rapporteur notes that, contrary to the Covenant, the European Convention on Human Rights more explicitly permits "formalities, conditions, restrictions or penalties".

41. Article 19 (3) allows for the restriction of the right to freedom of expression and information only under certain conditions. Most importantly, any restriction or limitation must be provided by law, must serve one of the listed purposes mentioned in the article and must be necessary for attaining this purpose.

42. The term "provided by law" implies that restrictions and limitations on the right to freedom of expression must have been formally enacted in law. Such act should specify the permissibility of interference by enforcement organs. The degree of such specification is important. Any interference that is solely based on administrative provisions prima facie violates article 19.

43. Any permissible limitation to the right to freedom of expression must not only be provided by law, it must also be necessary to attain one of the following purposes:

- (a) To respect the rights or reputations of others;
- (b) To protect national security;
- (c) To protect public order;
- (d) To protect public health;
- (e) To protect public morals.

44. The Special Rapporteur recalls the importance of the principle of proportionality in the process of establishing whether any limitation of the right to freedom of expression is necessary. In this respect, the general rule is the protection of the freedom; restriction of such freedom should be the exception to this rule. The restriction may not be applied in such a way that the expression of an opinion on any particular matter is merely suppressed. It may be restricted only in so far as it is necessary to attain one of the above-mentioned purposes.

45. The Special Rapporteur notes that, in spite of the fact that article 19 (3) refers to "restrictions" only, there are wider purposes for interference with the right to freedom of expression. Notably, article 20

of the Covenant obligates States to interfere with the right to freedom of expression as well as with other rights enumerated in the Covenant by prohibiting propaganda for war and the advocacy of racial hatred.

46. The Special Rapporteur also notes that during the travaux préparatoires concerning article 19 of the Covenant, more than 30 proposals for restrictions and limitations were tabled. These proposals related to expressions instigating to criminal actions or the violent overthrow of the Government, or expressions that infringe on the rights of others to mental and moral integrity. Thus, the issues of pornography and blasphemy were subject to debate. The fact that the final wording of article 19 (3) does not include a reference to these matters does, of course, not imply that interference on the part of the State for the purpose of protecting these interests is prohibited without exception. The limited scope for permissible interference that we find in article 19 (3) - limited especially as compared to regional human rights instruments - suggests to the Special Rapporteur that any interference, and especially restriction or limitation, should be interpreted narrowly in case of doubt.

#### To respect the rights or reputations of others

47. Respect for the rights and reputations of others may justify certain restrictions on the right to freedom of expression for purposes including the protection of freedom of religion, the protection against discrimination and the protection of minorities. Most importantly, however, as experience in practice suggests, the protection of the right to freedom of opinion and expression of others may justify such restrictions. Regarding the respect of the reputations of others, the Special Rapporteur notes that article 19 (3) when read in conjunction with article 17 obligates the State to provide legal protection against any intentional infringement on the honour and reputation by untrue assertions. In all cases, the principle of proportionality must be strictly observed for the purpose of preventing the undermining of the freedom of expression.

#### To protect national security

48. For the purpose of protecting national security, the right to freedom of expression and information can be restricted only in the most serious cases of a direct political or military threat to the entire nation.

49. The Special Rapporteur would like to refer in this connection to the passionate and eloquent speech which Sir Winston Churchill delivered in defence of the freedom to criticize the Government in the House of Commons at the moment when Britain was under severe threat of defeat at the hands of Nazi Germany's forces.

50. Replying to this historic moment of censure, Sir Winston Churchill said that the criticism that he and his Government had received were a remarkable example of the unbridled freedom of Britain's parliamentary institutions in time of war. He remarked that everything that could be thought of or made up had been used in weakening the confidence in the Government, in proving that Ministers are incompetent and in making the army feel distressed. He furthermore remarked that this served to weaken the confidence workers in

weapons factories had in themselves and had undermined the Prime Minister in his own heart. All these criticisms, Sir Winston Churchill furthermore remarked, were poured out by cable and radio to all parties of the world to the distress of all of Britain's friends and to the delight of all of Britain's foes. At the close of his address, Sir Winston Churchill remarked, however, that he was in favour of this freedom even in times of mortal peril such as those through which Britain was at that moment passing.

51. In the eyes of the Special Rapporteur, these words stand out as a beacon light to all who believe in human rights. They furthermore serve to underline the strongly held opinion of the Special Rapporteur that the purpose of protecting national security, which is in itself a legitimate one, should not be called upon too lightly by Governments in an attempt to justify infringements on the right to freedom of expression that might be unnecessary and impermissible because they do not serve its stated purpose.

#### To protect public order

52. Restrictions on the right to freedom of expression can be imposed for the purpose of protecting public order (ordre public). The Special Rapporteur notes that, whereas the notion of public order is in itself somewhat vague, it is possible to include in it the more narrow notion of the "prevention of disorder or crime", which is in use in article 10 (2) of the European Convention on Human Rights. In addition to the prevention of disorder and crime, one can also include under the notion of public order the universally accepted fundamental principles on which a democratic society is based and that are consistent with respect for human rights.

53. In view of the vagueness that inheres in the notion of public order, the danger exists that its application undermines the right to freedom of expression itself. To safeguard the protection of the freedom of expression as a general rule, as opposed to an exception, any appeal on the part of the State to restrict the exercise of the freedom of expression on the grounds of protecting public order should, in the eyes of the Special Rapporteur, meet strict requirements indicating its necessity. Any minimum requirements flowing from a common international standard for the protection of this right may not be set too low. For example, national legislation permitting the exercise of the right to freedom of expression only in the interest of a specific purpose such as a belief or religion would violate this international minimum standard. As a general rule, States should not invoke any custom, tradition or religious consideration to avoid meeting their obligations with respect to the safeguarding of the right to freedom of opinion and expression. In these instances, limitations on freedom of expression can be justified only when the public order of the State is truly compromised. Such a limitation may then be in effect only for a limited period of time and under certain specific circumstances, and any restrictions must be clearly established so that everyone may know precisely what is prohibited, and what is subject to such limitations.

#### To protect public health

54. The protected interest of public health allows for the prohibition of misleading publications on health-threatening substances or on social or

culturally inspired practices negatively affecting health. In this respect, the Special Rapporteur refers to traditional practices affecting the health of women and children. These practices include female genital mutilation, dowry debts and bride-burning. Publications on these matters that can be considered as misleading entail a positive obligation on the part of the Government to take steps to protect the interests of public health, if necessary by curtailing the right to freedom of expression.

## To protect public morals

55. The protected interest of public morals is a further ground on which States can interfere with the right to freedom of expression. Typical examples of restrictions in this domain relate to pornography and blasphemy. The Special Rapporteur notes that public morals differ widely and depend in large measure on the national context that includes matters of politics and culture. A margin of appreciation must therefore be accorded to the State. The Special Rapporteur would like to note, however, that restrictions applied on the freedom of expression should not be applied in such a manner as to promote prejudice and intolerance. He furthermore recognizes the importance to protect the freedom of expression of minority views including those views that might be offensive or disturbing to a majority.

## II. METHODS OF WORK

56. In this chapter the Special Rapporteur describes the methods of work adopted by him. The activities resulting from his approach are described in the next chapter.

57. As indicated in his previous report, the methods of work of the Special Rapporteur have been drawn from the practice established by and the experience acquired through the various thematic mechanisms of the Commission on Human Rights. They include in particular those on enforced or involuntary disappearances, extrajudicial, arbitrary or summary executions, torture, religious intolerance, and arbitrary detention. The Special Rapporteur adopts the methods of work that he deems most appropriate for his specific tasks. This implies a combined approach wherein country situations in general and individual cases are considered. The Special Rapporteur will furthermore study phenomena facilitating or impeding the enjoyment of the right to freedom of opinion and expression, and take action on concrete cases reported to him.

## A. Information

58. Following the request of the Commission on Human Rights, the Special Rapporteur seeks credible and reliable information from Governments, non-governmental organizations and other parties who have knowledge of pertinent situations and cases. A wide range of sources is being used.

59. By the sending of circular letters the Special Rapporteur contacts Governments, specialized agencies and non-governmental organizations which are concerned with the promotion and protection of the right to freedom of opinion and expression, and seeks pertinent information.

## B. Communications

60. Upon the receipt of prima facie credible and reliable information, the Special Rapporteur transmits the information to the Government concerned and requests it to provide him with comments and observations. In resolution 1993/47 the Commission on Human Rights encouraged Governments to respond expeditiously to such requests so that the special rapporteurs with thematic mandates might carry out these mandates effectively.

61. Upon the receipt of replies from the Governments concerned, the Special Rapporteur establishes whether the information received can be considered as explaining to his satisfaction the circumstances of the case, the applicable laws and regulations and the reasons for the act or omission on the part of the State that provided the initial ground for an allegation of an impermissible infringement on the right to freedom of opinion and expression.

62. The Special Rapporteur subsequently decides to either consider the case as closed to his satisfaction, or to seek and exchange further information or clarification with the Government concerned.

63. It should be stressed that the dialogue established with Governments by the Special Rapporteur and the transmission of allegations concerning their countries in no way implies any kind of accusation on the part of the Special Rapporteur, but constitutes a request for clarification with a view to finding, along with the Government concerned, ways and means to promote and protect the right to freedom of opinion and expression.

64. The Special Rapporteur adopts an urgent action procedure for cases that are of a life-threatening nature, as is used in several other special procedures of the United Nations for the protection and promotion of human rights.

65. Finally, the Special Rapporteur would like to stress that in implementing his mandate, he is keen to respond effectively to credible and reliable information coming before him, and to carry out his work with discretion and independence. In this context, he refers to the many difficulties he encounters as a result of a lack of financial and human resources, as described in chapter III of this report, that impede the effective discharging of the Special Rapporteur's mandate.

## C. Consultations

66. The Special Rapporteur seeks to hold consultations with all persons and organizations that can be of interest to him in the fulfilment of his mandate. Unfortunately, the absence of resources for this purpose as well as the strict regulations governing the activities he can undertake in the exercise of his work do not allow him to actively engage himself in the organization of such consultations. For these reasons, the Special Rapporteur expresses the hope that those organizations that can contribute to his work will not hesitate to contact him for the purpose of holding consultations. He expresses his appreciation to those organizations that have already done so.

#### D. Visits

67. The Special Rapporteur views on-site visits as an essential component of his mandate. He undertook a mission to Malawi from 3 to 6 October 1994, as described in chapter III of this report.

#### E. Cooperation with other human rights procedures

68. The Special Rapporteur reiterates the need for close cooperation with related mandates as he has noted in the concluding observations of his previous report (sect. IV, para. 43). He mentions in this respect the Special Rapporteur on religious intolerance, the Special Rapporteur on the question of torture, the Special Rapporteur on violence against women, the Working Group on Arbitrary Detention and the Working Group on Enforced or Involuntary Disappearances.

69. The Special Rapporteur notes that some overlap exists between his mandate and that of other United Nations procedures in the promotion and protection of human rights. Inasmuch as this overlap can be attributed to the scope of protection offered by the right to freedom of opinion and expression itself, it is unavoidable. It is the case, for example, with the work of the Special Rapporteur on religious intolerance, inasmuch as it concerns the non-religious beliefs that fall within the scope of protection of article 18 of the International Covenant on Civil and Political Rights. The Special Rapporteur notes that these rights do not exist in isolation and that what is done in one area to protect them has more than a merely psychological effect on the protection of other rights.

## F. Other activities

70. Part of the other activities undertaken by the Special Rapporteur in the fulfilment of his mandate is the granting of interviews to the press so as to make his work better known to the general public and to gather support from the public for his work.

#### III. ACTIVITIES

## A. Information

71. By circular letters dated 25 January, 10 February and 23 March 1994, the Special Rapporteur has contacted Governments, specialized agencies and non-governmental organizations which are concerned with the promotion and protection of the right to freedom of opinion and expression, and has sought to receive information pertinent to his mandate from them.

72. As at 31 October 1994, the following 23 Governments have responded: Belarus, Burkina Faso, China, Cuba, El Salvador, Germany, Greece, Haiti, Israel, Jamaica, Japan, Lesotho, Madagascar, Mexico, Monaco, Nepal, Nigeria, Norway, Pakistan, Philippines, Sudan, Sweden and Yugoslavia.

73. Of these Governments, some have acknowledged receipt of the circular letter only. Others have brought their national legislation on the right to freedom of opinion and expression to the attention of the Special Rapporteur or have responded referring to their report to the Human Rights Committee. At a later stage the Special Rapporteur wishes to present some thoughts on these replies.

74. The Special Rapporteur has furthermore received replies and information from the following nine non-governmental organizations in consultative status with the Economic and Social Council or with specialized agencies or other United Nations bodies: Amnesty International, Article XIX: The International Centre Against Censorship, Carnegie Council on Ethics and International Affairs, Inc., Human Rights Watch, International Federation of Journalists, International PEN, International Press Institute, International Union of Lawyers, and Reporters Without Borders - International.

75. The Special Rapporteur wishes to express his appreciation for the replies to his circular letters and other information he received from Governments and non-governmental organizations. He strongly encourages Governments and non-governmental organizations that as yet have not been in a position to respond to his circular letter to do so at their earliest convenience. He also expresses the sincere wish that non-governmental organizations which have already offered him information will continue to do so.

## B. Communications

76. As of September 1994 the Special Rapporteur had received a large number of detailed allegations concerning cases of violations of the right to freedom of opinion and expression. Owing to constraints of time and lack of human resources he was able to transmit only a few summaries of these cases to some of the Governments concerned.

77. The Special Rapporteur requested 47 Governments for information, in accordance with paragraphs 12, 13, 14 and 15 of Commission on Human Rights resolution 1993/45 (see paras. 2-4 and 6).

78. Communications were transmitted to the following 47 Governments: Albania, Algeria, Argentina, Bangladesh, Bosnia and Herzegovina, Brazil, Cameroon, China, Colombia, Cuba, Egypt, Ethiopia, Gabon, Georgia, Guatemala, Haiti, Hungary, India, Indonesia, Iran (Islamic Republic of), Ireland, Kenya, Lebanon, Malaysia, Mexico, Morocco, Myanmar, Nepal, Nigeria, Pakistan, Paraguay, Peru, Poland, Sierra Leone, South Africa, Sri Lanka, Sudan, Tajikistan, the former Yugoslav Republic of Macedonia, Tunisia, Turkey, United States of America, Yemen, Yugoslavia, Viet Nam, Zaire and Zambia.

79. In these communications the Special Rapporteur requested the views and comments of the Governments concerned on the facts reported to him and requested them furthermore to provide him with the results of any investigations which might have been carried out.

80. As of 31 October 1994, the Governments of the following 10 countries had replied to the allegations transmitted to them: Algeria, Bangladesh, China, Ethiopia, Hungary, India, Republic of Korea, Sudan, Tunisia and Turkey. The situations in these countries are the subject of chapter IV of this report.

## C. Consultations

81. The Special Rapporteur visited Geneva from 7 to 10 November 1994 for the purpose of holding consultations with the Secretariat. During the first year of his mandate he met with some special rapporteurs, with representatives of Governments and non-governmental organizations, and with persons who in their individual capacity provided him with pertinent information.

#### D. Visits

## Visit to Malawi

82. Pursuant to Commission on Human Rights resolution 1993/45, the Special Rapporteur has visited Malawi from 3 to 6 October 1994 following an invitation by the Malawi Government. The Special Rapporteur undertook his mission on the basis of information received from a number of non-governmental organizations that are active in the field of his mandate concerning allegations of threats of violence, harassment and intimidation of persons seeking to exercise or to promote the exercise of the right to freedom of opinion and expression. Of special interest to him was the emerging democratic climate as a result of recent and profound political changes in the country. The Special Rapporteur met with officials of the Government and administration, members of Parliament, members of the press corps, religious leaders, members of the business community, members of the academic community and practising lawyers. The Special Rapporteur also met with representatives of diplomatic missions as well as with aid workers active in the country.

83. The Special Rapporteur has found that the Malawi population at present enjoys the right to freedom of opinion and expression as enshrined in the Universal Declaration of Human Rights and the International Covenant on Civil and Political Rights. In those instances where allegations were made concerning infringements on this right, all persons with whom the Special Rapporteur was in contact agreed that such allegations were, or could be, tested as to their legality under the rule of law that is currently being established in Malawi. The Special Rapporteur has found that the current gap between the long-term stated goals and principles enshrined in the preliminary Constitution and the existing statutory laws and practices of the previous political era are a major concern of many persons.

84. The Special Rapporteur also noted that in many instances the enjoyment to its fullest possible extent of the right to freedom of opinion and expression met with constraints of a structural nature. For example, the country has no more than one Government-operated radio station and a few privately owned printing presses. These limited printing facilities, moreover, according to some persons with whom the Special Rapporteur spoke, were not managed exclusively on a commercial basis, but instead were used to a limited degree in a political way, i.e. by the alleged delayed printing of some newspapers. In general, the Special Rapporteur notes that the high rate of illiteracy, the general state of poverty of the large majority of the population, the lack of transportation and education are all factors impeding the full implementation of the right to freedom of opinion and expression. For these reasons, the

enjoyment of that right cannot be analysed in a legal vacuum. The Special Rapporteur, at a later stage, wishes to consider these structural impediments to the enjoyment of the right to freedom of opinion and expression at a more general level.

85. The Special Rapporteur considers that the lack of debate on the preliminary Constitution of Malawi and the limited general knowledge of its content are factors that hamper the effective protection of the right to freedom of opinion and expression. The Special Rapporteur, after having discussed these matters with interested parties, would venture to suggest that possible contributions to a solution of this problem might include the translation of the Constitution into local languages, as well as education and dissemination projects with the use of university graduates.

86. The Special Rapporteur would like to encourage donor countries represented in Malawi to contribute, financially as well as through offering their expertise, to the undertaking of projects that assist in establishing the wider legal framework needed to channel the executive power in its actions and policies. In this respect, the Special Rapporteur notes it is an essential part of consolidating constitutional government in the country that due attention be given to international human rights instruments and notably to those treaties to which Malawi is a party and which are part of the law of the country as is stipulated in the nation's preliminary Constitution. In general, the international jurisprudence established by the various human rights treaty monitoring bodies should be thoroughly considered in the country's attempt at consolidating its newly found and fragile political process which seeks to establish and sustain democracy and the rule of law. With respect to the protection of the right to freedom of opinion and expression, the Special Rapporteur would like to refer as well to the terms of reference of his mandate as contained in chapter I of this report which can be of assistance in this consolidation effort.

## Other visits

87. In the coming year of his mandate, the Special Rapporteur proposes to visit three countries situated in Asia, Latin America and Eastern Europe respectively. At a later stage, he would like to visit countries in other regions of the world.

88. With respect to the undertaking of further visits in the pursuit of his mandate, the Special Rapporteur would like to remark that such missions can only gain optimal results when they are well organized. The undertaking of such missions requires a planning that goes beyond the mere short term. Such planning, furthermore, requires continuity in the support offered by the Centre for Human Rights. The Special Rapporteur refers in this respect to his considerations presented elsewhere in this report on the as yet still less than appropriate financial and human resources that are needed to fulfil his mandate.

89. The prospects of working with the United Nations Development Programme in carrying out visits are bright. UNDP is institutionally, as well as conceptually, well placed to enable effective and systematic consultation with Governments. The Special Rapporteur would like to consider how to strengthen

support received from UNDP and how to move beyond the level of consultations to the level of real coordination in this extremely sensitive, but very important area of work. An agreed framework has to be put in place to achieve this coordination.

#### E. Cooperation with other human rights procedures

90. Whereas the Special Rapporteur recognizes the importance of cooperating with other human rights procedures, he feels compelled to note that the human resources at the Centre for Human Rights are inadequate to allow for such cooperation to take place in any systematic manner. At present, cooperation is taking place on an ad hoc basis and includes the exchange of information concerning individual cases of allegations of human rights violations.

## F. Other activities

91. The Special Rapporteur has regular contacts with the press in order to make his work known to the general public. During his visit to Malawi he granted an interview to the national radio and during his most recent visit to Geneva to a French radio station.

## G. Resources

92. As stated in his first report, submitted to the Commission on Human Rights in 1994, the Special Rapporteur is deeply concerned at the considerable number of communications he received that allege serious violations of the right to freedom of opinion and expression throughout the world. The cases contained in these communications give evidence of the continuous need for the effective promotion and protection of the right to freedom of opinion and expression. In view of the wealth and complexity of information pertaining to his mandate, as well as of the fact that violations occur in many countries of the world, an objective and even-handed approach requires sufficient financial and human resources to fulfil his mandate.

93. The Special Rapporteur recalls that the Commission on Human Rights, in its resolution 1994/33 of 4 March 1994, requested the Secretary-General. to provide, within existing overall United Nations resources, all the assistance necessary to the Special Rapporteur, in particular by strengthening the human and material resources placed at his disposal. The Special Rapporteur strongly feels that, at a minimum, there should be one Professional staff member in the Centre for Human Rights assisting him on a full-time basis.

94. At this point in time, after a little more than one year of his mandate has elapsed, the Special Rapporteur feels compelled to convey to the Commission on Human Rights at its fifty-first session the somewhat distressing observation that the Centre for Human Rights is still not in a position to free one Professional staff member on a full-time basis for the purpose of assisting him in his work. Moreover, since he began his mandate, the Special Rapporteur has received assistance from three different Professional staff members consecutively, leading to a situation which did not contribute to the necessary continuity in the fulfilment of his mandate. Furthermore, these staff members carry many additional responsibilities, including the assisting

of other Special Rapporteurs. This situation clearly illustrates the well-known fact that the Centre for Human Rights is severely understaffed.

95. With respect to the mandate of this Special Rapporteur and, as he presumes, that of many of his colleagues, the question arises whether the Commission on Human Rights should continue covering new areas by establishing special procedures without apparently being in a position to guarantee the provision of adequate human and financial resources for the unfolding of such activities. Current practice indicates that the existing overall United Nations resources are inadequate. If these resources are not made available to the Special Rapporteur, he will not be able to carry out his work thoroughly and with the necessary degree of efficiency. It is the ultimate concern of the Special Rapporteur that this situation would be not only to the detriment of the effectiveness of his own activities but could also jeopardize the effectiveness of the very important work of the Commission on Human Rights in the field of the promotion and protection of human rights.

IV. COUNTRY SITUATIONS

#### Algeria

96. In a communication dated 22 June 1994, addressed to the Government of Algeria, the Special Rapporteur transmitted the following information:

"It has been reported that Mr. Rebah Zenati, a journalist with the Algerian national television station, was killed on 3 August 1993 by an unidentified attacker, apparently because of a story he wrote in March on an anti-terrorism demonstration. Mr. Zenati had previously received death threats in the mail."

97. In another communication, dated 26 July 1994, the Special Rapporteur transmitted the following information to the Government of Algeria:

"It has been reported that, on 14 February 1994, Abdelaziz Smati, a television producer, was seriously wounded when two men shot him outside his home in a suburb of Algiers. On 28 February 1994, television journalist, Albdelkader Hireche was killed by three gunmen in an eastern suburb of Algiers.

On 1 March 1994, Miloud Zaatar, the Tiaret correspondent for the French-language daily Alger Republicain, was hit by five bullets outside his home. Zaatar was hospitalized and is recovering.

On 5 March 1994, television journalist Hassan Benaouda was shot in the head by unidentified assailants in the Cabash section of Algiers. Benaouda died of his wound one week later.

On 8 March 1994, Abed Charef, a journalist with the French-language weekly La Nation, survived two attempts on his life. A neighbour of Charef was killed in the first attempt, and later that day, gunmen sprayed his car with bullets in front of his child's day care facility. Charef was not in the car, his driver escaped injury.

On 19 March 1994, Yahia Djamel Benzaghou, a journalist with the Prime Minister's press office and formerly a reporter for El Moudjahid and the state agency Algerie Press Service, was gunned down outside his home in Bab El Oued.

Furthermore, on 21 March 1994, several gunmen raided the Algiers office of the independent weekly L'Hebdo Libéré, shot and killed photographer Madjid Yacef, a driver with the paper, and seriously injuring a female employee and two others."

98. On 29 August 1994, the Government of Algeria sent the following observations on the above-mentioned communications and a list of journalists and persons working in the media sector who have been victims of murders perpetrated by terrorists. The list included the names of the seven journalists referred to in the second communication.

"By acceding to all of the international instruments on the promotion and protection of human rights, Algeria has clearly demonstrated its unfailing devotion and commitment to respect for human rights.

Anxious to build a modern, democratic State and convinced that human rights are the mainspring for the achievement of this objective, Algeria is working towards the elimination of extremism and its attendant violence, which are a negation of the most sacred right, the right to life.

With regard to the killings of journalists, particularly that of Mr. Rabah Zenati, a journalist with the Algerian television station, the Algerian Government strongly condemns those acts and is bringing every effort to bear to punish those responsible, in the framework of the law. The journalistic community has already paid heavily for the armed violence linked to religious extremism.

There have been many calls for killings and attempts against the lives of journalists.

Since becoming one of the terrorists' targets, 17 journalists have paid with their lives for their anti-fundamentalist stand and 3 more were the victims of murder attempts.

It should also be noted that the buildings housing the press and television have been subjected to bombings, which, fortunately, resulted only in material damage.

Below is a list of journalists and people working in the information sector who have been the victims of terrorist attacks.

Omar Belhouchet (17 May 1993). Director and manager of the national daily 'El Watan', he was shot at in a murder attempt while leaving his home in Bab Ezzouar (eastern suburbs of Algiers).

Tahar Djaout (26 May 1993). Journalist with the weekly newspaper 'Rupture', a writer and poet, he was the victim of a shooting while leaving his home in Baînem (western suburbs of Algiers). He died of his injuries on 2 June 1993.

Merzak Baghtache (31 July 1993). A journalist and writer, he was the victim of a shooting near his home in Algiers. He has been left with considerable physical and psychological after-effects.

Rabah Zenati (3 August 1993). A journalist with the National Television Corporation (ENTV). Shot to death near his home in Cherarba (eastern suburbs of Algiers).

Abdelhamid Benmennt (9 August 1993). Middle manager at the weekly newspaper 'Algérie Actualité', he was shot to death at his home in Eucalyptus Grove (eastern suburbs of Algiers).

Saïd Bakhtaoui (11 August 1993). Journalist with 'El Mebar', the APUA party newspaper, abducted near his home (eastern suburbs of Algiers), he was shot to death and found dead at Larabaâ.

Djamel Bouhidel (15 September 1993). A photographer with the newspaper 'Nouveau Tell', a regional publication in Bliaa, he was shot to death.

Abderrahmane Chergou (28 September 1993). A journalist and writer with 'Alger Républicain' and 'Hebdo Libéré', former officer of the National Liberation Army, he was stabbed to death in the entrance to his home in Mohammadia (eastern suburbs of Algiers).

Mustapha Abada (14 October 1993). Journalist, former director of the Algerian national television station in 1992, he was shot to death near his home in Alger Plage (eastern suburbs of Algiers).

Ismaïl Yefsah (18 October 1993). A journalist with the national television station, he was shot to death while leaving his home in Bab-Ezzouar (eastern suburbs of Algiers).

Youcef Sebti (28 December 1993). A journalist and contributor to several periodicals, Secretary-General of the 'El Jahaidia' cultural association. His throat was cut in his company apartment located on his work premises.

Aziz Smati (15 February 1994). Radio and television producer. Victim of a shooting near his home at Chéraga (suburb of Algiers). He has had after-effects from this attack (motor handicap).

Abdelkader Hireche (1 February 1994). Journalist with the national television station. Shot to death near his home in Algiers.

Mohamed Hassaine (1 March 1993). Correspondent for the daily newspaper 'Alger Républicain'. He was abducted from his home in Larabaâtach (Blida) and has not been found to date.

> Mouloud Zaatar (1 March 1994). Journalist with the daily newspaper 'Alger Républicain', victim of an attack at Tiaret, he has had serious physical after-effects.

Hassan Benaouda (5 March 1994). Journalist with the national television station, he was the victim of a shooting in Algiers. He died of his injuries on 12 March 1994.

Yahia Benzeghou (19 March 1994). Journalist with 'Algérie Presse Service' and the daily newspaper 'El Moudjahid', head of the communications service attached to the office of the Head of Government, he was shot to death near his home in Algiers.

Madjid Yacef (21 March 1994). Reporter-photographer for 'Hebdo Libéré', he was killed during an attack on the 'Hebdo Libéré' premises by an armed group.

Mohammed Meceffeur (13 April 1994). Journalist with 'El Watan' and 'Directive', he was shot to death at Mostaganem.

Ferhat Cherkit (7 June 1994). Journalist and head of the economy section of the daily newspaper 'El Moudjahid', he was shot to death in Algiers.

Hichem Guenifi (7 June 1994). A trainee technician at the national radio station, he was shot to death near his home at Bachdjarah (eastern suburbs of Algiers).

Yasmina Drici (11 July 1994). Proofreader for the daily newspaper 'Soir d'Algérie', she was abducted by a group of terrorists and later found with her throat cut at Kharouba (Boumerdes).

Mohamed Lamine Legoui (20 July 1994). Correspondent in M'sila for 'Algérie Presse Service', he was shot to death and his throat cut near his home in Bousaada.

Brahim Taouchichet (14 August 1994). Director of the magazine 'Horoscope', he was abducted by a terrorist group."

#### Observations

99. As the communications transmitted to the Government of Algeria and the reply received from it shows, journalists, writers and persons working in the media section are particularly exposed to terrorist attacks from Islamic fundamentalists.

100. The Special Rapporteur is deeply concerned at this situation and hopes that the Government of Algeria will be able to identify the perpetrators of the killings and abductions mentioned in his communication and to provide journalists the protection that they need to continue their work.

#### Bangladesh

101. In a communication dated 27 June 1994, the Special Rapporteur transmitted the following information to the Government of Bangladesh:

"It has been reported that a second 'fatwa' has been issued against feminist writer Taslima Nasreen as a result of a statement made in an interview published in an Indian newspaper. According to Nasreen, she had been misquoted as saying that 'the Koran should be revised thoroughly' with respect to women's rights. Muslim cleric, Moulana Amini, protested against the statement by Nasreen saying that it was more 'filthy' than those made by Salman Rushdie in 'The Satanic Verses'. Furthermore, Amini demanded that she be arrested and executed. An Islamic party leader, Azharul Islam, called Nasreen 'an apostate appointed by imperialist forces to vilify Islam'.

Around 5,000 members of the militant Jamaiat Islami party marched through Dhaka carrying a banner calling for the hanging of anyone who blasphemes Islam and warned that if their calls for the arrest of Nasreen were to be ignored, they would instigate unrest against the Government.

The renewal of threats against Nasreen coincided with the publication into French and English of her novel, Lajja."

102. On 13 July 1994, the Government of Bangladesh sent the following observations on the above-mentioned communication transmitted to it by the Special Rapporteur:

"As regards the statement made by Taslima Nasreen in an interview with a correspondent of the Calcutta-based English daily 'Statesman', the paper in its 9 May 1994 issue quoted her as saying: 'The Koran should be revised thoroughly'. The sweeping remark made by the writer on the Holy Quran was quoted extensively in Bangladesh news media and created deep anguish and consternation among believers, resulting in widespread protest and demand for action under the law. Apparently, the intensity of protest led the writer to modify her statement in a letter to the Editor's column of the 'Statesman', which was published on 11 May, saying: 'I do not hold the view that the Koran should be revised thoroughly'. It is important to note that nowhere in her rejoinder did she claim to have been misquoted.

There is no report to suggest that a 'Muslim cleric' said to be named as Moulana Amini and 'an Islamic Party Leader' identified as Azharul Islam had made such remarks as alleged in the annexure to the Special Rapporteur's letter. It would be appreciated, if the details of identity of these persons and their alleged statements, including respective sources as well as dates and places, could be made available to this Mission.

Regarding demonstrations calling for the 'hanging of anyone who blasphemes Islam' as well as the 'announcement of rewards for killing someone', the position of the Government of the People's Republic of Bangladesh has been adequately reflected in a press note issued on

> 28 June 1994. It noted that the Government had been observing the issuance of threat against the lives of some persons from time to time and announcement of reward for the killers by certain persons and organizations. The press note said that this kind of announcement is a punishable offense in the eyes of the law. It also expressed the Government's hope that all concerned would refrain from making such illegal announcements and show respect for the law, otherwise, the Government would be compelled to take legal action against them.

While on this subject, it may be mentioned that a complaint has already been lodged by a relation of Taslima Nasreen before a court of law in the city of Khulna. It is, therefore, for the court to declare whether there is credible evidence to establish the alleged death threats against her by any individual or any group of individuals.

It may be mentioned that the Constitution of the People's Republic of Bangladesh contains wide-ranging and detailed provisions on Fundamental Rights including, inter alia, those on equality before law; protection of right to life and personal liberty; freedom of thoughts, conscience and speech; and safeguards against discrimination on grounds of religion, race, caste, sex or place of birth. At the same time, the right to freedom of opinion and expression, if exercised by an individual in total disregard for the sentiments and religious feelings of others in a society, may provoke exercise of similar rights. This, in turn, may lead to disruption of law and order. Therefore, the legal system of Bangladesh, like other legal systems, defines the concept of balance between the rights of the individual and those of the society."

#### Observations

103. The Special Rapporteur wishes to express his gratitude for the willingness to cooperate shown by the Government of Bangladesh. However, he notes that in spite of the position taken by the authorities against those who threaten to kill Ms. Nasreen, her life was in danger and she felt compelled to seek asylum in Sweden. The Special Rapporteur remains deeply concerned at the issuance of a warrant of arrest by the Chief Metropolitan Magistrate of Dhaka against Taslima Nasreen under Section 295A of the Penal Code and that she is to be tried on 10 December 1994 in her absence. The Special Rapporteur intends to seek further clarification on this case.

#### China

104. In a communication dated 7 March 1994, the Special Rapporteur transmitted the following message to the Government of China:

"It has been reported that Fu Shenqui was detained on 26 June 1993 for allegedly encouraging political activists to write letters to the Government and stage a hunger-strike in protest against the detention of two dissidents in Shanghai. He was also accused of speaking to foreign journalists about the activities of pro-democracy supporters in Shanghai. He was administratively sentenced without a trial on 4 July 1993 to

three years of 're-education through labour'. According to the source, Fu Shenqui is being detained solely for the expression of his non-violent opinions."

105. On 27 May 1994, the Government of China responded, making the following observations:

"The Chinese Government has mounted a painstaking inquiry into the allegations made in the annex to the communication, and its findings make it plain that Fu Shenqui's committal to re-education through labour had nothing to do with the exercise of the freedom of opinion and expression that China's constitution confers upon its citizens. The facts are as follows:

## A. Basic facts in the case of Fu Shenqui

In 1993, Wang., who suffers from mental disorders, became seriously ill and begun to injure and wound himself, endangering his own and others' safety. In the circumstances, the authorities responsible had him taken to a mental care institution for treatment. Fu, knowing full well that Wang was receiving medical treatment because he was ill, deliberately distorted the facts of the matter as a pretext for instigating a disturbance and causing an incident, thereby severely disrupting public order.

To maintain law and order, in accordance with articles 10 (4) and 13 of the Provisional Methods of Re-education through Labour, the Shanghai Municipal Re-education Through Labour Administrative Committee committed Fu Shenqui to three years re-education through labour on 4 August 1993. On two occasions, 9 August and 19 August 1993, Fu appealed to the Committee to reconsider. In December 1993, the Administrative division of Huangpu District People's Court in Shanghai reviewed the case of Fu Shenqui, in accordance with the law, and on 23 December, it upheld the decision of Re-education Through Labour Committee in every particular, instructing the Dafeng County People's Court in Jiangsu Province to notify Fu of its ruling.

#### B. The Chinese re-education through labour system

The re-education through labour to which Fu was committed is not, under the Chinese legal system, a form of criminal punishment but an administrative measure of mandatory educative reform used by the Chinese Government to prevent and reduce crime and to uphold the social order. Re-education through labour committee in the people's governments of provinces, autonomous regions, directly administered municipalities and large medium-sized cities considered and approve committals. They consist of senior officials from the people's government and the department of public security and of labour. Re-education through labour facilities have been set up locally by the government at each level to take in individuals committed for re-education. The intention is to redeem them, to concentrate on their education, to handle them lawfully, strictly, scientifically and in a civilized manner, while guaranteeing their constitutional and legal rights. If an individual disagrees with

the decision to commit him to re-education through labour he is entitled to apply to the Re-education Through Labour Committee to reconsider, or he may bring suit under the Administrative Suits Act.

#### C. The allegations do not tally with the facts

It will be seen that Fu's committal to re-education through labour was because of his illegal disruption of public order and unrelated to the 'expression of non-violent opinions'. The Shanghai Municipal Re-education Through Labour Administrative Committee's treatment of Fu was in accordance with Chinese law as regards both the facts and the procedure. Fu made full use of his right to appeal and bring suit against the Committee's decision. The Huangpu District People's Court conscientiously heard Fu's administrative suit and rendered its decision in accordance with the law. The allegations in the communication are completely without foundation."

#### Observations

106. The Special Rapporteur wishes to express his appreciation to the Government of China for the information provided on the case of Mr. Fu Shenqui. He is of the opinion that the circumstances under which Mr. Fu was sentenced, as set out in the communication of the Chinese Government, remain somewhat unclear. The Special Rapporteur intends to seek further clarification as to how Mr. Fu Shenqui "distorted the facts of the matter as a pretext for instigating a disturbance and causing an incident, thereby severely disrupting public order". He will then examine the proportionality between the charges brought against Mr. Fu Shenqui and the sanctions applied.

#### India

107. In a communication dated 7 March 1994, the Special Rapporteur transmitted the following allegations to the Government of India:

"On 11 January 1994 police allegedly raided the offices of the Punjab daily Aj Di Awaz (Today's Voice) and arrested Gurdeep Singh, the managing editor, along with seven other staff members of the newspaper (Malkir Singh, Jasbir Singh Khalsa, Jasbir Singh Manowan, Devinder Singh, Amrik Singh, Kuldeep Singh) who were then taken to police premises. The police reportedly denied later that they were holding Gurdeep Singh and Malkir Singh. According to the source, these individuals have been detained solely for the expression of their opinions."

108. On 9 September 1994, the Special Rapporteur received from the Government of India the following comments relating to the above-mentioned allegations:

"The authorities concerned in India have investigated the allegations which have been proved to be deliberately misrepresented and grossly distorted. As would be evident from the brief facts of the case given below, Gurdeep Singh Bhatinda, Jasbir Singh Rode and others were arrested for their involvement in terrorist activities and not for the expression of their opinions. Further, the arrest of Gurdeep Singh and Malkiat Singh have not been denied.

'Aaj Di Awaj', was established in 1985 by some Sikh terrorists and secessionist elements as a mouthpiece of their activities. It never practised bona fide journalism in any form. Its founder and former Editor-in-Chief, Bharpur Singh Balbir was arrested in 1986 in a conspiracy case after the revelation of his close links with some Sikh terrorists in Canada who were conspiring to blow up the Parliament House in New Delhi. One of the trustees of this newspaper, Jasbir Singh Rhode, has a consistent record of publicly encouraging and applauding acts of murder and destruction carried out by Sikh terrorists. The present Editor-in-Chief of 'Aaj Di Awaj', Gurdeep Singh Bhatinda has been acting as a front and mouthpiece for secessionist and terrorist organizations, a number of whom have been given refuge in Pakistan and have been directing murder and arson in India from Pakistan territory. These include Wassan Singh Zaffarwal and Lakhbir Singh Rhode.

Questioning of a Pakistani trained terrorist Nisar Ahmed Shah arrested at Jalandhar revealed the association of Gurdip Singh Bhatinda with a Pakistani Intelligence Agent Abdul Karim Hakim who was responsible for explosions on six trains in December 1993. Reliable information was also received by the authorities concerned that Jasbir Singh Rode and Gurdip Singh Bhatinda, guided by the Pakistan based terrorist leaders Wassan Singh Zafarwal and Lakhbir Singh Rode were planning to carry out acts of terror including attempts on the life of the Chief Minister of Punjab and the premises of the daily 'Aaj Di Awaj' was being used as a hide-out and meeting place of terrorists for planning their activities. Jasbir Singh Rode and his colleagues had also met several times with the underground terrorists Harmik Singh, Jasbir Singh Brahampura and Awtar Singh Brahampur to plan these activities. To fund these activities, Lakhbir Singh Rode and his co-conspirators received large illegal remittances from Pakistan as well as from Sikh extremist groups based in the United Kingdom. In view of the compelling evidence of the association of Gurdip Singh Bhatinda and Jasbir Singh Rode as well as some of their subordinates on the staff of 'Aaj Di Awaj' in planning acts of armed terror, the police searched the premises of the newspaper on 11 January 1994. Criminal charges have been brought against all these eight persons who have been remanded to judicial custody and action is being taken against them under due process of law.

Subsequent to their arrest, the search of a flat in New Delhi rented by a UK-based extremist Shamsher Bhadur Singh Gill Shera led to the recovery of an AK-56 rifle, ammunition, 16 bags of explosives and a large sum of Indian currency. Further investigation in this case revealed that Jasbir Singh Rode was the intermediary in India for carrying out these preparations for premeditated acts of terror under the guidance of Pakistan to use terrorists Wassan Singh Zaffarwal and Lakhbir Singh Rode.

It would, therefore, be amply clear from the foregoing that these arrests had nothing to do with any violation of Right to Freedom of Expression and that they were made due to their active involvement in planning acts

> of armed terror. The question of freedom of opinion and expression is not germane to the present allegations forwarded to the Government of India. The Government of India would also respectfully submit that article 19 of the Covenant on Civil and Political Rights which encapsulates the freedoms to be enjoyed in this respect equally states in subparagraph (iii) that special duties and responsibilities are also involved in the exercise of these rights. Far from respecting these duties and responsibilities, the subjects of the allegations have shown their contempt of human rights through their acts."

#### Observations

109. The Special Rapporteur wishes to express his appreciation to the Government of India for providing information on the case of Punjab Daily Aj Di Awaz (Today's Voice) and persons arrested in that case. He has noted the Government's position that Gurdeep Singh and others were arrested for their involvement in terrorist activities and not for the expression of their opinion. The Special Rapporteur would like to reiterate that there can be no freedom unless thought is free and unrestricted. He has taken cognizance of the fact that the Government of India has endorsed its commitments to honour and respect the right of freedom of expression and opinion. The Special Rapporteur is contented that the Government concerned has shown due respect for fundamental rights. He expects the State to uphold this right. Regarding the acts of terrorism alleged to have been perpetrated by the persons arrested, he is informed that action is being taken against them under due process of the law. The Special Rapporteur hopes for an early disposal of this case. The State may be firm in its belief that persons arrested were fomenting terrorist activities but it should remain equally committed to providing a fair trial to the accused persons.

#### Ethiopia

110. In a communication dated 7 March 1994 addressed to the Government of Ethiopia, the Special Rapporteur transmitted the following information (relating to cases involving the persons Nigusie Ayele Teka, Metsihafe Syrak, Belete Abeba, Tesfaye Birhanu, Girmai Gebre Tsadik, Kidist Belachew, Tefera Asmare, Befekadu Moreda, Tamirat Gebre Giorgis, Girma Lemma, Mintesnot Zena, Kibret Mekonnen, Mesele Addis, Netsanet Tesfaye, Kifle Mulat and Nebiyu Eyassu):

"The above-mentioned persons are journalists for privately owned publications who have allegedly been jailed in the past few months for periods ranging from a few hours to more than 50 days. They were held on charges of incitement under the Ethiopian Press Proclamation, but reports indicate that none of the cases have been prosecuted as of 20 January 1994. According to the source, these journalists are reported to have been detained solely for the expression of their opinions."

111. On 22 March 1994, the Government of Ethiopia sent the following information to the Special Rapporteur:

"The Transitional Period Charter, as the supreme law of the country, has introduced a legal regime which has recognized individual human rights as laid down in the Declaration of Human Rights. As part of the practical measures taken by the Transitional Government to enforce those rights, a Press Law has been issued abolishing censorship and any limitation of a similar nature. The new proclamation has enabled numerous periodic publications to carry out their work without interference. Accordingly, the present political situation of the country is characterized by free expression of ideas and active political participation.

As for the allegation that journalists, editors and publishers are being detained illegally as a campaign against freedom of press, I would like to assure you that no action has been taken against those independent journalists who operate in accordance with the provisions of Proclamation 34/1985 on the freedom of press. However, those who violate the Press Law and other Criminal Laws are brought before justice. This is even more urgently required when their publications contravene the interests of public security, the rights of nations, nationalities, religions and individuals. Therefore, the 18 journalists who are now in detention were arrested on account of violating the Press Law and not solely for expressing their opinions. In this regard, it should also be noted that the accused have the right to defend themselves in accordance with the provisions of the Ethiopian Criminal Procedure Code and article 8 of the Universal Declaration of Human Rights since independent Courts have been established by Proclamation 23/1984. The detainees also have access to defence lawyers of their own choice. The human rights of the detainees are fully respected. In fact, the petitions of some of them for bail are being considered by the Courts. The Transitional Government remains committed to the protection and promotion of human rights.

#### Observations

112. The Special Rapporteur appreciates the reply provided by the Government of Ethiopia and its commitment to protect and promote human rights. This commitment will no doubt be reflected in the Government's actions at the operational level to provide the defendants with all the facilities necessary to defend themselves, in accordance with applicable international standards and provisions of the national law. The Special Rapporteur intends to seek further clarification of these cases.

## Hungary

113. In a communication dated 1 September 1994, the Special Rapporteur transmitted the following allegations to the Government of Hungary:

"On 3 March 1994, 129 journalists of Magyar Radios, the Hungarian national broadcasting company, were dismissed. In addition, 12 journalists of '168 hours', popular weekly political production of Radio Kossuth (one of the three national broadcasting stations), were also dismissed.

Vice President of Hungarian Radio Laszlo Csucs stated that the lay-off was necessary due to budgetary problems, but journalists see it as an attempt to silence government criticism two months before the scheduled

> national elections. Mr. Csucs also stated that this measure was effective 12 April, yet he ordered immediate suspension of those journalists from their jobs in his 4 March announcement.

Allegedly, Mr. Tom Kennedy, an advisor of the Government on media matters, declared that the journalists were fired because they were 'former communist alcoholics'."

114. On 17 October 1994, the Special Rapporteur received from the Government of Hungary the following reply:

"The situation of the 129 journalists of Magyar Radios and the 12 of '168 hours' has already been solved, since all the journalists having not attained the age of retirement established by law, who so desired, had been reinstated with appropriate reimbursement of their salaries. All possible concerns regarding the situation now have been dispelled."

#### Observation

115. The Special Rapporteur appreciates the prompt reply provided by the Government of Hungary. He hopes that the reinstallation of the journalists dismissed together with the allocation to them of appropriate compensation have contributed to the restoration of a climate of confidence in which journalists can carry out their activities without constraints.

#### Republic of Korea

116. In a communication dated 7 March 1994, addressed to the Government of South Korea, the Special Rapporteur transmitted the following allegations concerning Mr. Hwang Sok-yong:

"It has been reported that Hwang Sok-yong, a 50-year-old writer, was arrested upon his arrival at Kimpo Airport in Seoul on 27 April 1993 by the Agency for National Security Planning (ANSP). Reportedly Mr. Hwang Sok-yong has been held by the ANSP for 20 days, during which time he was allegedly subjected to lengthy interrogation, threats and sleep deprivation. He was then transferred to Seoul Detention Centre under the care of the prosecution who interrogated him for a further 30 days before charges were brought under several articles of the National Security Law for forming and participating in an 'anti-State' organization, for visiting North Korea as an 'operational' fee and of forming and participating in Pomminyon (Pan National Alliance for the Reunification of Korea). Hwang Sok-yong was tried and convicted and is currently being held in Seoul Prison. According to the source, Mr. Hwang Sok-yong has been convicted solely for the expression of his non-violent opinions. Specifically, it is alleged that the charges stem from his opinions on the reunification of North and South Korea."

117. In a letter dated 19 April 1994, the Government of Korea informed the Special Rapporteur that it had already submitted its observations on the case of Mr. Hwang Sok-yong to the Working Group on Arbitrary Detention, on 20 October 1993.

## Observations

118. The information concerning Mr. Hwang Sok-yong is to be found in the report of the Working Group on Arbitrary Detention (E/CN.4/1995/31/Add.2, decision No. 30/1994).

#### Tunisia

119. In a communication dated 29 April 1994 addressed to the Government of Tunisia, the Special Rapporteur transmitted the following allegations concerning Mr. Moncef Marzouki, Mr. Abderrahmane Hani and Mr. Ahmed Kahlaoui:

"(1) It was reported that Moncef Marzouki, a doctor and former President of the Tunisian Human Rights League (LTDH), was arrested on 24 March and charged with dissemination and propagation of false reports likely to disturb public order and for slandering the judicial authorities, in accordance with articles 49, 50, 51, 68 and 69 of the Press Code and article 32 of the Penal Code. Mr. Marzouki was also allegedly charged with insulting the authorities in an interview he granted a Spanish newspaper.

According to our source, Mr. Marzouki denies these charges and it is alleged that his arrest is connected with the fact that he sent the press highly critical statements regarding the state of civil liberties in Tunisia. For example, he reportedly described as unacceptable the complete silence of the Tunisian press concerning his candidature for the post of President.

(2) It is reported that Mr. Abderrahmane Hani, a Tunis lawyer who is head of a movement called the Arab 'avant-gardes unionnistes', which is not recognized by the Government, was arrested on 15 February and charged with 'illegally forming a non-recognized political organization and spreading false and defamatory reports'. Before his arrest, Mr. Hani allegedly issued a press release in which he demanded the introduction 'of genuine pluralism that will enable Tunisians to choose their President freely'.

(3) It was reported that Ahmed Kahlaoui, a trade unionist, was arrested in early March for distributing leaflets. He is accused of not respecting the obligation regarding the statutory deposit of publications. The leaflets allegedly dealt with the massacre at Hebron in the occupied West Bank and the international embargo against Iraq."

120. On 24 September 1994, the Government of Tunisia transmitted to the Special Rapporteur the following observations concerning the above-mentioned allegations:

"1. The case of Mr. Moncef Marzouki

First of all, it should be pointed out that Mr. M. Marzouki was released on 13 July 1994 following a decision by the examining magistrate of the Tunis court of first instance. Indeed, Mr. Marzouki was able to leave Tunisia for a business trip abroad.

As to the facts that gave rise to his arrest, Mr. Marzouki was charged with disseminating false reports likely to disturb public order, and slandering the legal system, under articles 50 and 51 of the Press Code.

Mr. Marzouki has not denied the facts, contrary to the allegations which have reached you, and has stated that he did indeed make statements to foreign journalists, though he does not rule out the possibility that the reporter from the Spanish daily Diaro 16 tried to achieve a sensational impact by twisting the statements attributed to him.

In fact, the newspaper Diaro 16, in its 13 May 1994 issue, published an article noting that an unfortunate error had crept into the interview granted by Moncef Marzouki, an error due to the translation from English into French, and then from French into Spanish.

Subsequently, after his lawyer had lodged a request for his temporary release, supported by a disclaimer sent to the newspaper in question on behalf of his client and a copy of the newspaper constituting proof that the disclaimer had been published, the examining magistrate decided on the basis of this new evidence to release Mr. Moncef Marzouki.

As for the allegations that Mr. Marzouki's arrest was connected with the fact that he has sent to the press highly critical statements regarding the state of civil liberties in Tunisia, and that he described as unacceptable the complete silence of the Tunisian press concerning his candidature for the post of President, there are no grounds for making such a surprising and untoward linkage.

In this regard, the Tunisian Government wishes to make it clear that Mr. M. Marzouki's arrest was not connected with his candidature in any way, and that the accusations laid against him cannot be regarded as an obstacle to freedom of opinion and expression, still less to his earlier activities or political opinions. The charges are based on precise facts which constitute offences under Tunisian law.

2. The case of Ahmed Kahlaoui

Mr. Ahmed Kahlaoui was indeed arrested on 4 March 1994 as he was distributing leaflets prepared by him at his home which called for confrontation with all Jews, both in Tunisia and in other Arab countries, and for a boycott of all conferences and scientific meetings in which they participate.

He also argued against any economic or political dealings with Jews, placing special emphasis on the need for the people of Tunisia to take on the Jewish community in Djerba.

Mr. Kahlaoui was brought from custody before the correctional division of the Tunis court of first instance on 8 March 1994, charged with inciting hatred between races, religions and populations and publishing leaflets of a type likely to prejudice public order. His case was registered as No. 11623/494 and set for hearing on 24 March 1994; it was later deferred successively to 31 March 1994 and 14 April 1994.

On 27 June 1994 the fourth division of the Tunis court of first instance heard this case and decided to sentence the accused to two years' imprisonment together with a fine of 1,000 dinars for incitement to racial hatred, eight months' imprisonment for publishing leaflets and a fine of 100 dinars for infringement of the regulations regarding statutory deposit of publications.

Mr. A. Kahlaoui was found guilty on the basis of the above-mentioned facts and offences under articles 12, 44 and 62 of the Press Code and article 52 bis of the Penal Code, which provide for penalties for any person inciting racial or religious hatred and fanaticism by any means whatsoever.

Consequently, Mr. A. Kahlaoui's arrest and conviction cannot in any way be equated with a violation of freedom of opinion and expression - a freedom guaranteed and protected under Tunisian law.

3. The case of Mr. Abderrahmane El Hani

Mr. A. El Hani has been accused of illegally distributing leaflets containing defamatory material likely to jeopardize public order, under articles 49, 50 and 51 of the Press Code, and maintaining in activity a non-recognized party, under articles 8 and 26 of the Act of 3 May 1988.

Mr. El Hani appeared before the correctional division of the Tunis court of first instance, without having been placed in custody.

His case has been registered as No. 21767/494 and is pursuing its normal course. Mr. El Hani remains at liberty.

Consequently, the Tunisian Government wishes to make it clear that the charges brought against Mr. El Hani in no way constitute a violation of his right to freedom of expression or opinion, since they bear no relation to the assertions made to you regarding "a press release in which he demanded the introduction of genuine pluralism that could enable Tunisians to choose their President freely".

#### Observations

121. The Special Rapporteur wishes to express his appreciation to the Government of Tunisia for providing information on cases referred to him. The Government of Tunisia has reaffirmed its firm commitment to respect civil and political rights, including that to express opinions on matters of State, which the Special Rapporteur finds important and worthy of attention. It is this course which should be followed meticulously in the cases referred to. The Special Rapporteur wishes to stress that ideological differences that may exist within a society should not be used as a justification to incite hatred between races, religions and peoples, or to take action against persons expressing views contrary to the establishment. The Special Rapporteur hopes that the Tunisian Government would ensure that this principle will continue to guide them and that the pending cases will be decided rapidly.

## Turkey

122. In three communications dated 7 March, 30 June and 10 August 1994, respectively, the Special Rapporteur transmitted to the Government of Turkey the following allegations he had received concerning the detention of lawyers, police operations against newspapers and the detention and abduction of journalists:

# (1) Cases concerning Husniye Olmez, Meral Danis Bestas, Mesut Bestas, Sebahattin Acar, Baki Demirhan, Sinasi Tur, Arif Altunkalem, Nevzat Kaya

"It has been reported that members of the Bar Association in Diyarbakir named above, were all detained during the week of 15 November and are said to be held at the Gendarmerie Headquarters in Diyarbakir. The lawyers have acted as defence counsel in many political trials before Diyarbakir State Security Court, notably of defendants in PKK trials. According to the source, these individuals are being detained merely for their representation of defendants in PKK trials."

## (2) Cases concerning Iman and Arzu Sahin

"It has been reported that on 7 December 1993 police detained lawyers Iman and Arzu Sahin. It is believed that they may have been transferred to Diyarbakir. The lawyers have acted as defence counsel in many political trials, notably of defendants in PKK. The detention of the lawyers reportedly is on the basis of statements given to the police by a political prisoner in Diyarbakir Prison who had become a police informer. According to the source, the lawyers are being detained merely for their representation of defendants in PKK trials."

#### (3) Case concerning Dogu Perincek

"Dogu Perincek, the former leader of the Turkish Socialist Party, which was closed down in July 1992, was sentenced to two years' imprisonment and a fine of 50 million Turkish lira by the Ankara State Security Court on 15 January 1993. The charge, under article 8 (1) of the Anti-Terror Law, was making 'separatist propaganda' during the election campaign in the autumn of 1991. According to the source, Mr. Perincek is being prosecuted solely for the expression of his non-violent opinions."

# (4) Police operations against the newspaper Ozgur Gundem and detention of its journalists in the following cities and concerning the cases of the following persons:

Istanbul: Gurbetelli Ersoz, editor-in-chief; Fahri Ferda Cetin, editor; Gulten Kisanak, news editor; Muslum Yucel, journalist; Mahmut Dogan, journalist; Ferhat Tugan, journalist; Yurdusev Ozsokmenler, journalist; Nursel Polat, journalist; Dogan Guzel, cartoonist; Ali Riza Halis, administrator; Mehmet Balamir, administrator; Duzgun Deniz, archive manager; Faysal Dagi, research desk manager; Mucahir Kuas, accountant; Huseyin Solgun; Mehtap Gurbuz, sub-editor; Ali Seyhan, cook; Semsettin Ecevit, driver.

Diyarbakir: Hasan Ozgun, representative; M. Sirac Koc, journalist; Neamiye Aslan, journalist; Mehmet Sah Yildiz, journalist; Nuray Tekdag, journalist; Bitan Onen, journalist.

Izmir: Sezai Karakoc, representative, Riza Zingal, news editor; Serdar Caycioglu, journalist; Namik Alkan, journalist; Emin Unay, journalist; Ciller Yesil, journalist; Leyla Akgul, secretary.

Adana: Haci Cetinkaya, representative; Sukru Kaplan, journalist; Ihsan Kurt, journalist; Aslan Sarac, journalist; Beyhan Gunyeli, journalist.

Elazig: Cengiz Tas, representative; Menaf Avci, journalist; Yalcin Sevinc, journalist.

Batman: Slih Dinc.

Mardin: Rezzan Gunes.

"It has been reported that on 9 December 1993 the Turkish police began a series of nationwide police operations against the newspaper Ozgur Gundem. On that date the police allegedly raided the newspaper's office in Diyarbakir and on 10 December the police raided its central office in Istanbul, in which some 110 people were detained and material, including archives and computer disks, seized. Reportedly some 200 police officers raided the main office, and for 24 hours searched the computer files and the premises, detaining all those present and taking them to Istanbul Police Headquarters. By the evening of 11 December, all but 18 had been released. On Saturday 11 December, the newspaper's offices in Izmir, Adana, Elazig, Batman, Mardin, Antop and Van were also raided and its correspondents and staff detained. Nobody was working in the Mardin office when it was searched, but one member of its staff, Rezzan Gunes, was detained when the police raided her home. It is not known whether any of these detainees have been released. According to the source, these individuals are being detained solely for the expression of their non-violent opinions."

#### (5) Cases concerning Kutlu Esendemir and Levent Ozturk

"It has been reported that Kutlu Esendemir and Levent Ozturk, two television journalists who were working on a piece for the private TGRT TV were kidnapped by Kurdistan Workers' Party (PKK) guerrillas on 27 January 1994. The regional PKK command stated that the journalists were taken into custody for not having permission to enter the region and film for their television programme which makes its clear that the PKK ban on Turkish journalists is still in effect.

According to the source, the PKK indicated that Esendemir and Ozturk would not be freed until 'murders in Kurdistan are revealed'."

## (6) Cases concerning 16 journalists of the magazine Alinteri

"According to information received by us, two journalists from the magazine Alinteri in Ankara, Derya Tanrivermis, the head of the office, and Zafer Sakin, a correspondent, have been detained by the police since 7 April 1994, at political police headquarters (Ankara). It is alleged that several repressive measures have already been taken against Alinteri by the Turkish authorities. On 21 February 1993, in particular, the police reportedly searched its offices in Izmir and briefly detained correspondent Halime Özcelik and, on 11 January, five of its distributors were allegedly questioned by the police.

In addition to the two journalists, 14 people who were on Alinteri premises were allegedly arrested by the police."

123. On 21 March 1994, the Government of Turkey transmitted to the Special Rapporteur the following information concerning allegations (1) and (2):

"(a) General information on lawyers who have been detained.

Sixteen lawyers have been subject to investigation on grounds that they had established organic links with the separatist terrorist organization PKK, and that, in this connection, they had:

- Acted as courier between PKK members imprisoned at the Diyarbakir E-Type prison and the terrorists at large,
- Established the Legal Bureau of the said terrorist organization,
- Provided imprisoned PKK terrorist with cyanide poison and weaponry,
- Coordinated activities among the various branches of the PKK and imprisoned terrorists,
- Persuaded terrorist leaders for assassinating a Prosecutor at the State Security Court and thus attempt at intimidating the Courts of Law.

The above listed acts fall within the scope of articles 168 and 169 of the Turkish Penal Code and are qualified as acts of terror and therefore necessitate criminal investigation.

- (b) Specific cases.
- (1) Sabahattin Acar was taken into custody on 15 November 1993, on charges of providing imprisoned terrorists with cyanide and of acting as courier for the terrorist PKK organization. He was released on 10 December 1993.
- (2) Sinasi Tur was detained on 15 November as suspect for acting as courier for the terrorist PKK organization and providing shelter and assistance to terrorists. He was set free on 10 December 1993.

- (3) Baki Demirhan was taken into custody on 16 November 1993 on grounds of handing over a knife to imprisoned terrorists. Following his interrogation, Baki Demirhan was released on 10 December 1993.
- (4) Arif Altunkale, Mesut Bestas and Meral Bestas were detained on 16 November 1993 on charges of acting as messengers for the terrorist PKK organization. They were released on 10 December 1993. Following the appeal of the Diyarbakir Prosecutor's Office, the Court ruled their arrest, in absentia, on 13 December 1993.
- (5) Huseyin Olmez was taken into custody on 16 November 1993 on grounds of acting as courier for the terrorist PKK organization. The court ruled his arrest on 10 December 1993.
- (6) Nevzat Kaya was detained on 18 November 1993, on grounds of acting as courier for the terrorist PKK organization. He was liberated on 10 December 1993.
- (7) Iman Sahin and Arzu Sahin were taken into custody on 7 December 1993 on charges that they acted as couriers for the terrorist PKK organization. The Diyarbakir State Security Court ruled their arrest on 21 December 1993."

124. As for the search conducted by security forces at the offices of the Ozgur Gundem newspaper (allegation No. 4), the following explanations have been provided by the Turkish authorities:

"The freedom of press is guaranteed in Turkey, where the pluralist democratic system is functioning with all its institutions. It is provided in the Constitution that the press is independent and that it is free from censorship. In order to verify the implementation of the above-mentioned constitutional provisions it is sufficient to go through the multitude of daily newspapers which profess a wide spectrum of thoughts and beliefs.

The search, based on a warrant issued by the competent Court, conducted by security forces at the Ozgur Gundem newspaper should not be considered as a hindrance to the freedom of press. Moreover, Ozgur Gundem is still being published.

The testimonies of captured militants of the terrorist PKK organization has led law enforcement officials to suspect a close link between some of the staff of the Ozgur Gundem newspaper and the PKK. Allegations in this respect include reports that some of the staff have been trained at PKK camps, the publication of the paper as per instructions received from PKK leaders, as well as financial support to the newspaper from the terrorist organization and the presence of a variety of PKK documents in the newspaper office premises. Based on these motivations, the Court issued a search warrant, following which the Ozgur Gundem newspaper was searched on 10 December 1993, and 111 persons from the staff of the newspaper were interrogated.

Following the investigation, 92 persons thought to have no connection with the PKK were released. The investigation regarding the remaining 19 persons on grounds of providing assistance and shelter to the terrorist PKK organization was under way on 27 December 1993.

During the search at the Ozgur Gundem offices, two unregistered handguns, three bullet magazines, six bullets, an ERNK (a branch of the terrorist PKK organization) seal, a PKK receipt for 400 million Turkish lira, two bloodstained military identity cards with bullet holes belonging to Muzaffer Ulutas, a gendarme slain by PKK terrorists in Sirnak on 9 March 1993, gas masks, an abundance of injections to stop haemorrhage, menacing letters, photographs of a number of officers and privates abducted by the PKK, and numerous publications on PKK were seized. These objects are currently being examined by the Istanbul State Prosecutor's Office.

It is clear from the information furnished above that the search does not have anything to do with violating the freedom of expression, but with the capture of persons who have committed acts which are termed as crime in the Turkish Penal Code. It should not go unnoticed that the term 'acts' mentioned above, also covers involvement in the slaughtering of innocent civilians, women, children, the elderly, doctors, teachers and engineers."

125. Concerning the case of Mr. Dogu Perincek (allegation No. 3), the Government of Turkey in a communication dated 7 July 1994 stated:

"[he] has been penalized by the Ankara State Security Court for contravening article 8 of Law No. 3713. The sentence was annulled by the High Court of Appeal and the case was sent back to the Ankara State Security Court for a retrial.

Following the second trial, the Court sentenced Dogu Perincek, on the same grounds, to two year's imprisonment and to a fine of 50 million Turkish lira. The defence lawyers have appealed the sentence, which was brought before the High Court of Appeals. Dogu Perincek is currently free.

Article 8 of Law No. 3713 prohibits written and oral propaganda aimed against the unity and territorial integrity of the Republic of Turkey."

126. On 2 September 1994, the Government of Turkey transmitted the following observations on the allegations mentioned above, under (5):

"It has been established that Kutlu Esendemir and Levent Ozturk, both working for the TGRT television network, were abducted by PKK terrorists on 26 January 1994, in the vicinity of the Güclükonak country of the Sirnak province. They remained in the hands of the terrorists until they were set free on 28 April 1994.

The south-eastern region of Turkey has been the scene of a savage terrorist campaign launched by an organization called the PKK. The bloody campaign launched by the PKK has claimed more than 15,000 innocent

lives including women, children and the elderly, since it began in 1984. In 1993 alone, the PKK indiscriminately killed more than 1,200 civilians, mainly of Kurdish origin.

Abduction and arbitrary killings of civilians is a common practice of the PKK which, apart from trying to hinder newspeople from doing their work, as illustrated in this particular case, also exploits freedoms as covers for promoting their sinister designs. The PKK's misuse of the freedom of opinion and expression in an attempt to legitimize its terrorist strategy and to praise the misdeeds and cruelties of its members constitutes a vivid example in this regard."

127. On the allegations mentioned above under (6), the Government of Turkey presented the following comments in a letter dated 6 September 1994:

"Part of the south-eastern region of Turkey has been afflicted for several years by the separatist terrorism of an organization bearing the name PKK. This organization has been denounced and condemned as a terrorist organization by most of the Member Governments of the United Nations.

It is a fact that, as in similar cases observed on an international scale, this terrorist organization uses some of its militants in various areas of society at large, in particular in newspapers and magazines used to further its cause. Most of the latter use journalism as a cover for their main activities, which are either terrorism or propaganda in support of terrorism. Nearly all of these so-called journalists do not meet the requirements for practising the profession and acceding to the status of journalist. This said, I am afraid that some of the names included in the list annexed to your letter fall within this category. Although I understand that, because of the gaps in the communications system of the competent United Nations bodies, it is difficult for you to make a distinction between these people and real journalists, it is difficult for me not to react when I see the name of a journalist such as Mr. Ugur Mucu, whose murderers are alleged to be terrorists belonging to a foreign fundamentalist movement, in the above-mentioned category of cases that are deliberately being used by the terrorist organization through the communications systems as propaganda material.

The PKK's Marxist-Leninist ideology and strategy, with its attendant atheistic propaganda and rejection of all of south-eastern Anatolia's age-old values, has led to a reaction among certain social strata that has in turn produced another terrorist organization, "Hizbullah", whose ideology is religious fundamentalism. Most of the killings or attempted killings of so-called journalists affiliated with daily newspapers such as Ozgur Gundem were perpetrated by members of Hizbullah. The judicial authorities have clarified approximately 70 per cent of these cases.

The Turkish Government also provides information on the newspaper Ozgur Ulke, the successor to Ozgur Gundem. A reading of a single issue of this newspaper is sufficient indication that it is a party organ which is directly dependent on the PKK and takes advantage of freedom of the press in Turkey to incite terrorism and separatism. The PKK leaders

write regularly for this newspaper, whose circulation is between 6,000 and 8,000 copies a day. The letters I am transmitting to you in an annex relating to the counter-truths published in this newspaper on Turkey's relations with the United Nations human rights bodies are only a very small illustration of the systematic disinformation work being carried out by the newspaper.

Freedom of opinion and expression does exist in Turkey, so much so that it is frequently abused by certain circles. It is obviously no easy matter to determine where freedom of expression as a universal standard stops. However, you are no doubt well aware that such a freedom can become an offence when it is knowingly used as a provocation to human rights violations, criminality, armed violence and separatist goals, all the more so in a context where the threat of terrorism brings all its weight to bear. It is true that those responsible for such provocation have been prosecuted and that some of them have been convicted by the Turkish judicial authorities. Some would consider these judicial proceedings to be proof of alleged restrictions on freedom of expression in Turkey, which is in fact exercised very widely, as should be the case in a pluralistic democracy.

However, democracies must also lay down certain conditions for the exercise of freedom of expression if they are to preserve their own values, for their proper functioning and even survival depend on such values. As crucially important as it is to protect these values, it would not be possible to do so without guarantees such as territorial integrity, crime prevention, national security and public safety, to name but a few. These guarantees are recognized in many international instruments. In this connection, article 10, paragraph 2, of the European Convention on Human Rights, to which Turkey is a party as a member of the Council of Europe since 1949, is one of the best examples."

## Observations

128. The Special Rapporteur wishes to express his appreciation to the Government of Turkey for providing information on cases referred to it. From a close reading of the allegations made and the information received from the Government, the Special Rapporteur feels that in the present situation of Turkey, the political process should go hand-in-hand with the law and order approach. The view that a complicated historical process can be resolved by terrorism is erroneous. History has demonstrated that many upheavals accompanied by terrorist acts which looked very formidable at the time did not succeed in the end. Terrorism has proven to be a road to disaster and should be avoided. Nor can a mere law and order approach suffice to meet the situation; a genuine solution involves a greater appreciation of the grievances of the people. It is only by demonstrating moral values and concern for human rights that one gains the approbation of society and thus outflank the anti-social forces. The Special Rapporteur expresses the sincere hope that an effective balance between freedom and authority will be struck. He notes that such a balance implies that persons arrested will be provided with every opportunity to prove their innocence and that the State at the

same time will ensure peace and stability by handling the terrorist acts effectively. In addition, the State should provide journalists the protection they need to pursue their professional responsibilities.

## V. CONCLUSIONS AND RECOMMENDATIONS

129. The Special Rapporteur is compelled to conclude that violations of the right to freedom of opinion and expression have not ceased to occur. In many instances, these violations concur with violations of other human rights, including those related to enforced or involuntary disappearances, extrajudicial, arbitrary or summary executions, torture, religious intolerance, arbitrary detention and the problem of terrorism.

130. Most constitutions no doubt guarantee the fundamental right of free speech. Free expression and freedom of the press have been regarded as freedoms implicit in this larger freedom and are part of it. The press performs a vital service in a democracy by providing a political arena for debate and the exchange of information and ideas. Its institutional needs therefore have to be safeguarded. The free flow of news and information both within and across national boundaries deserves the fullest support.

131. The free press needs help. Journalists must be secure in their pursuits and be given full protection of the law. No doubt such laws exist, but they have to be implemented creatively and imaginatively with a view to advancing the constitutional values and spelling out and strengthening the basic human rights enshrined in them. Advancing the constitutional values and enhancing the protection of people's rights require limiting and structuring the executive and legislative powers.

132. The Special Rapporteur is concerned about the continued intimidation and harassment of writers and journalists in several countries across the world. Often, such harassment is disguised, covert and subtle; occasionally it is blatant and institutionalized. A free media is essential not merely as an instrument of democracy but as a precondition for social stability and equality. Whatever the excesses of an unprofessional media, on balance, freedom tends to smooth out rough edges.

133. Independent press commissions can perform vital functions in guiding and balancing institutions that check the power of both the executive and the media. While freedom is not a privilege but a right, its exercise by the media calls for responsibility. A declared code of conduct for the media is essential for all journalists. Such a code will only work effectively, however, if it is voluntarily adopted by the profession itself.

134. Apart from its function to ensure freedom and protect democracy, a free press functions also as a social and an economic asset. Social scientists have demonstrated how freedom of information can contribute to higher degrees of productivity and motivation for work and to ensuring the quick and fair delivery of public services, especially in times of natural disaster.

135. The Special Rapporteur recognizes that the right to information is vitally important other than as a guarantee of a free press. Governments and private businesses tend to be excessively secretive. While recognizing the

importance of a legally protected right to intellectual property, the Special Rapporteur notes that the denial of the right to information is not in the public interest.

136. The media could consider exposing itself to public criticism through the formal institution of an ombudsman to whom both individuals and organizations could appeal in cases of perceived misuse of the right to freedom of expression. Such an ombudsman could have a purely advisory role, chastising or commending the media in specific cases referred to him.

137. The exercise of freedom carries with it responsibilities and duties. It demands wisdom, sagacity and a sense of responsibility. The exercise of freedom is therefore subject to reasonable conditions and limitations prescribed by law and necessary in a democratic society, but it should always be kept in mind that freedom of expression is the primary freedom and the first condition of liberty. It occupies a preferred position in the hierarchy of liberties, giving succour and protection to other liberties. For these reasons, freedom of the press is indispensable in a democracy.

138. A freedom of such amplitude involves risks of abuse. The point must be made, however, that even in the interests of specific segments of society, any restrictions imposed should be proportionate to the need giving rise to them, proportionate to the harm they seek to prevent. Two competing interests have to be balanced, and that task is to be carried out with statesmanship by the judiciary and executive. The basic rights of free speech and expression should not lightly be allowed to be smothered and curtailed, because they are at the core of all human rights.

139. With respect to all the activities undertaken by the Special Rapporteur in the fulfilment of his mandate, it is of vital importance that he receive public support. Freedom of expression and opinion is a fundamental attribute of a good civil society in which all fundamental commitments require a base of public support if they are to be sustained. Human rights do not prevail unless there is a public function for them. People should be made aware of their value. Their commitment can only be obtained through open public debate and discussion. The logic of the political process of democracy needs the creation of an atmosphere in which attempts to undermine human rights are countered and in which support for human rights is clearly articulated. An enlightened public opinion created through the organization and publicizing of seminars, conferences, brainstorming sessions and other meetings touching on the issue of freedom of expression would strengthen the basis sustaining the work of the Special Rapporteur.

140. The Special Rapporteur recognizes the primordial role that can be played, and that should be played, by non-governmental organizations active in the defence of human rights. Their task is burdensome. No one organization can hope to address these problems alone. The sharing of information and of responsibilities, therefore, becomes necessary. The approach of the Special Rapporteur has been to build a close relationship with NGOs that are active in the area of his concern. He strongly encourages common initiatives among them and with them, not only on pragmatic, but also on moral grounds. There are NGOs that share our fundamental values and which act as watchdogs. The Special Rapporteur is most eager to synchronize his efforts with those NGOs

effectively. Such attempts at synchronization should not be at cross purposes with Governments, but should rather serve the purpose of furthering the cause of freedom of expression on a global scale.

141. The Special Rapporteur cannot be indifferent to the incidents referred to him. Without completing his inquiries with the Governments concerned he cannot form a well-informed opinion. Some of the allegations of violations of the right to freedom of opinion and expression have been pending for months or even years. The Special Rapporteur would risk mortgaging his future if he turned a blind eye to delays in the responses of Governments. Delays win no awards.

142. The Special Rapporteur recognizes that the attitudes of Governments to such cases must, of necessity, remain nuanced. Yet he also notes that despite all these difficulties, Governments have it in their power to respond swiftly and have the capacity to put down those practices from which human rights crusaders derive their raison d'être, strength and appeal. The Special Rapporteur encourages all those seeking to protect the right to freedom of opinion and expression to avoid oversimplifications of complex issues which entail difficult but necessary choices.

143. The judiciary of all countries should be aware that the violation of the right to freedom of opinion and expression leaves no room for impartiality. It is within their competence to order the release of detainees who are held merely for expressing their non-violent opinions.

144. The Special Rapporteur urges all Governments to scrutinize their national legal systems with a view to bringing them into line with international standards governing the right to freedom of opinion and expression.

145. The Special Rapporteur recommends to the Commission on Human Rights to consider the question of financial and human resources in the light of his remarks in chapter III of this report.

146. The Special Rapporteur stands committed to offering his full cooperation in the efforts of Governments and non-governmental organizations to solve the problems in the area of his mandate. Through unity and cooperation in defending and protecting them, the frontiers of human rights, which are the most basic moral values of our present-day civilisation, can be extended.

-----